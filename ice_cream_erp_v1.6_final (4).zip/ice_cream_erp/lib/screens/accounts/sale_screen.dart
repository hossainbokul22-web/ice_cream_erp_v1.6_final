import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/sales_service.dart';
import '../../utils/ui.dart';
import 'invoice_actions.dart';
import 'invoice_list_screen.dart';

class SaleScreen extends ConsumerStatefulWidget {
  const SaleScreen({super.key});

  @override
  ConsumerState<SaleScreen> createState() => _SaleScreenState();
}

class _SaleScreenState extends ConsumerState<SaleScreen> {
  List<Item> _items = [];
  List<Party> _parties = [];
  int? _itemId;
  int? _partyId;
  bool _receivedNow = true;
  bool _loading = true;
  final _qty = TextEditingController();
  final _price = TextEditingController();
  final _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _qty.dispose();
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    final items = await (db.select(db.items)
          ..where((i) => i.itemType.equals('Finished') & i.isActive.equals(true))
          ..orderBy([(i) => OrderingTerm.asc(i.itemName)]))
        .get();
    final parties = await (db.select(db.parties)
          ..where((p) => p.isActive.equals(true) & p.partyType.isIn(['Customer', 'Both']))
          ..orderBy([(p) => OrderingTerm.asc(p.partyName)]))
        .get();
    if (!mounted) return;
    setState(() {
      _items = items;
      _parties = parties;
      _loading = false;
    });
  }

  final List<InvoiceLineInput> _cart = [];

  Item? _item(int id) {
    for (final i in _items) {
      if (i.id == id) return i;
    }
    return null;
  }

  double get _total => _cart.fold<double>(0, (s, l) => s + l.qty * l.price);

  void _addLine() {
    final itemId = _itemId;
    final qty = parseNum(_qty.text);
    final price = parseNum(_price.text);
    if (itemId == null || qty == null || qty <= 0 || price == null || price <= 0) {
      showSnack(context, 'আইটেম, পরিমাণ ও মূল্য দিন');
      return;
    }
    setState(() {
      _cart.add(InvoiceLineInput(itemId, qty, price));
      _itemId = null;
      _qty.clear();
      _price.clear();
    });
  }

  Future<void> _save() async {
    if (_cart.isEmpty) {
      showSnack(context, 'আগে অন্তত একটি আইটেম যোগ করুন');
      return;
    }
    final db = ref.read(databaseProvider);
    int? invId;
    final ok = await runGuarded(context, () async {
      invId = await ref.read(salesServiceProvider).sellInvoice(
            lines: List.of(_cart),
            partyId: _partyId,
            receivedNow: _receivedNow,
            note: _note.text.trim().isEmpty ? null : _note.text.trim(),
          );
    });
    if (!ok || invId == null || !mounted) return;
    final inv = await (db.select(db.saleInvoices)..where((i) => i.id.equals(invId!))).getSingle();
    setState(() {
      _cart.clear();
      _note.clear();
    });
    if (!mounted) return;
    showSnack(context, 'ইনভয়েস ${inv.invoiceNo} তৈরি হয়েছে');
    await invoiceSheet(context, db, inv.id, inv.invoiceNo);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sale (বিক্রয়)'),
        actions: [
          IconButton(
            tooltip: 'ইনভয়েস তালিকা',
            icon: const Icon(Icons.receipt_long),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceListScreen())),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                DropdownButtonFormField<int?>(
                  isExpanded: true,
                  value: _partyId,
                  decoration: const InputDecoration(labelText: 'কাস্টমার (ঐচ্ছিক)'),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('নগদ বিক্রয় (Party নেই)')),
                    ..._parties.map((p) => DropdownMenuItem<int?>(value: p.id, child: Text('${p.partyCode} - ${p.partyName}'))),
                  ],
                  onChanged: (v) => setState(() => _partyId = v),
                ),
                const SizedBox(height: 16),
                const Text('আইটেম যোগ করুন', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                DropdownButtonFormField<int>(
                  isExpanded: true,
                  value: _itemId,
                  decoration: const InputDecoration(labelText: 'Finished আইটেম'),
                  items: _items
                      .map((i) => DropdownMenuItem<int>(value: i.id, child: Text('${i.itemCode} - ${i.itemName} (${i.baseUnit})')))
                      .toList(),
                  onChanged: (v) {
                    setState(() {
                      _itemId = v;
                      final it = v == null ? null : _item(v);
                      if (it != null && it.salesPrice > 0) _price.text = fmtQty(it.salesPrice);
                    });
                  },
                ),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _qty,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'পরিমাণ'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _price,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'একক মূল্য (Tk)'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(onPressed: _addLine, icon: const Icon(Icons.add)),
                ]),
                const SizedBox(height: 12),
                if (_cart.isNotEmpty) ...[
                  for (var i = 0; i < _cart.length; i++)
                    Card(
                      child: ListTile(
                        dense: true,
                        title: Text(_item(_cart[i].itemId)?.itemName ?? 'Item #${_cart[i].itemId}'),
                        subtitle: Text('${fmtQty(_cart[i].qty)} ${_item(_cart[i].itemId)?.baseUnit ?? ''} × ${fmtQty(_cart[i].price)}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(fmtMoney(_cart[i].qty * _cart[i].price), style: const TextStyle(fontWeight: FontWeight.w700)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                            onPressed: () => setState(() => _cart.removeAt(i)),
                          ),
                        ]),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text('মোট: ${fmtMoney(_total)}',
                        textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  ),
                ],
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('টাকা এখনই পাওয়া গেছে'),
                  subtitle: const Text('বন্ধ করলে বাকি (Receivable) হবে, কাস্টমার লাগবে'),
                  value: _receivedNow,
                  onChanged: (v) => setState(() => _receivedNow = v),
                ),
                TextField(controller: _note, decoration: const InputDecoration(labelText: 'নোট (ঐচ্ছিক)')),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.receipt_long),
                  label: const Text('বিক্রয় সংরক্ষণ ও ইনভয়েস'),
                ),
              ],
            ),
    );
  }
}
