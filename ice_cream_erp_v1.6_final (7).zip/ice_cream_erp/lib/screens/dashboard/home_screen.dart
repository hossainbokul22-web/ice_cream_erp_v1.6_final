import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/database_provider.dart';
import '../../services/stock_service.dart';
import '../../utils/ui.dart';

/// Home: galaxy header with today's numbers + soft-serve coloured shortcut tiles.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _Shortcut {
  const _Shortcut(this.icon, this.title, this.sub, this.path, this.top, this.bottom);
  final IconData icon;
  final String title;
  final String sub;
  final String path;
  final Color top;
  final Color bottom;
}

const List<_Shortcut> _shortcuts = [
  _Shortcut(Icons.category_rounded, 'Items', 'আইটেম মাস্টার', '/items', Color(0xFF9D7BFF), Color(0xFF5B2BB8)),
  _Shortcut(Icons.menu_book_rounded, 'Recipes', 'রেসিপি / BOM', '/recipes', Color(0xFFFF8FC0), Color(0xFFEE4C98)),
  _Shortcut(Icons.propane_tank_rounded, 'Tanks', 'ট্যাংক', '/tanks', Color(0xFFA8F5D9), Color(0xFF3FD3A0)),
  _Shortcut(Icons.groups_rounded, 'Parties', 'সাপ্লায়ার / কাস্টমার', '/parties', Color(0xFFFFC565), Color(0xFFE08A2E)),
  _Shortcut(Icons.shopping_cart_rounded, 'Purchase', 'মাল গ্রহণ', '/purchase', Color(0xFF7CC4FF), Color(0xFF2F7DE1)),
  _Shortcut(Icons.point_of_sale_rounded, 'Sale', 'বিক্রয়', '/sale', Color(0xFF8BE59B), Color(0xFF2FAE55)),
  _Shortcut(Icons.inventory_2_rounded, 'Packing', 'কার্টুন এন্ট্রি', '/packing', Color(0xFFB9A2FF), Color(0xFF7B4DD8)),
  _Shortcut(Icons.delete_sweep_rounded, 'Reject / Wastage', 'ক্ষতি ও ফেরত', '/movement', Color(0xFFFF9D8A), Color(0xFFE5484D)),
];

class _HomeScreenState extends ConsumerState<HomeScreen> {
  late Future<DailyInventoryBrief> _future;

  @override
  void initState() {
    super.initState();
    _future = ref.read(stockServiceProvider).dailyInventoryBrief();
  }

  void _reload() {
    setState(() => _future = ref.read(stockServiceProvider).dailyInventoryBrief());
  }

  Widget _pill(String label, String value) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(30),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withAlpha(40)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withAlpha(190))),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF16256B), Color(0xFF4527A8), Color(0xFF7B2FBE)],
        ),
        boxShadow: const [BoxShadow(color: Color(0x445B2BB8), blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: const LinearGradient(colors: [Color(0xFFFF8FC0), Color(0xFFEE4C98)]),
                ),
                child: const Icon(Icons.icecream_rounded, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Ice Cream ERP', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white)),
                    Text('আজকের সারসংক্ষেপ', style: TextStyle(fontSize: 12, color: Colors.white70)),
                  ],
                ),
              ),
              IconButton(onPressed: _reload, icon: const Icon(Icons.refresh_rounded, color: Colors.white)),
            ],
          ),
          const SizedBox(height: 14),
          FutureBuilder<DailyInventoryBrief>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) {
                return Text(friendlyError(snap.error!), style: const TextStyle(color: Colors.white));
              }
              if (!snap.hasData) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Center(child: CircularProgressIndicator(color: Colors.white)),
                );
              }
              final b = snap.data!;
              return Column(
                children: [
                  Row(children: [
                    _pill('RM স্টক মূল্য', fmtMoney(b.rawValue)),
                    _pill('FG স্টক মূল্য', fmtMoney(b.finishedValue)),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    _pill('আজ উৎপাদন', fmtQty(b.finishedProducedToday)),
                    _pill('Low stock', '${b.lowStockCount}'),
                    _pill('Near expiry', '${b.nearExpiryCount}'),
                  ]),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, _Shortcut s) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => context.push(s.path),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE6E0F5)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [s.top, s.bottom],
                  ),
                  boxShadow: [BoxShadow(color: s.bottom.withAlpha(80), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Icon(s.icon, color: Colors.white, size: 24),
              ),
              const SizedBox(height: 8),
              Text(s.title,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF1B1040))),
              Text(s.sub,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 10.5, color: Colors.grey.shade600)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _header(),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 8),
              child: Text('দ্রুত কাজ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF1B1040))),
            ),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 0.92,
              children: [for (final s in _shortcuts) _tile(context, s)],
            ),
          ],
        ),
      ),
    );
  }
}
