import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/stage_service.dart';
import '../../utils/ui.dart';

final stageServiceProvider = Provider<StageService>((ref) => StageService(ref.watch(databaseProvider)));

String _en(String s) => s.runes.every((r) => r < 128) ? s : '(see app)';

/// Standard stage sheet for one batch: Mixing -> Pasteurization -> Homogenization
/// -> Aging -> Freezing -> Packing. Can be hidden, locked, printed.
class StageSheetCard extends ConsumerStatefulWidget {
  const StageSheetCard({super.key, required this.orderId});
  final int orderId;

  @override
  ConsumerState<StageSheetCard> createState() => _StageSheetCardState();
}

class _StageSheetCardState extends ConsumerState<StageSheetCard> {
  bool _open = true;

  Color _color(String? r) => r == 'Pass'
      ? Colors.green
      : r == 'Fail'
          ? Colors.red
          : r == 'Skip'
              ? Colors.blueGrey
              : Colors.orange;

  String _label(String? r) => r == 'Pass'
      ? 'পাস'
      : r == 'Fail'
          ? 'ফেল'
          : r == 'Skip'
              ? 'এড়ানো'
              : 'বাকি';

  Future<void> _edit(StageDef st, StageCheck? cur) async {
    String result = cur?.result ?? 'Pass';
    final temp = TextEditingController(text: cur?.tempValue == null ? '' : fmtQty(cur!.tempValue!));
    final press = TextEditingController(text: cur?.pressureBar == null ? '' : fmtQty(cur!.pressureBar!));
    final dur = TextEditingController(text: cur?.durationMin == null ? '' : fmtQty(cur!.durationMin!));
    final note = TextEditingController(text: cur?.note ?? '');
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: StatefulBuilder(
          builder: (ctx, setS) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(st.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                children: [
                  for (final r in ['Pass', 'Fail', 'Skip'])
                    ChoiceChip(
                      label: Text(_label(r)),
                      selected: result == r,
                      selectedColor: _color(r).withAlpha(60),
                      onSelected: (_) => setS(() => result = r),
                    ),
                ],
              ),
              if (st.hasTemp) ...[
                const SizedBox(height: 8),
                TextField(
                  controller: temp,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(label: Text('তাপমাত্রা °C (ঐচ্ছিক)')),
                ),
              ],
              if (st.hasPressure) ...[
                const SizedBox(height: 8),
                TextField(
                  controller: press,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(label: Text('প্রেশার (bar) (ঐচ্ছিক)')),
                ),
              ],
              const SizedBox(height: 8),
              TextField(
                controller: dur,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('সময় (মিনিট) (ঐচ্ছিক)')),
              ),
              const SizedBox(height: 8),
              TextField(controller: note, decoration: const InputDecoration(label: Text('নোট (ঐচ্ছিক)'))),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () async {
                  final ok = await runGuarded(
                    ctx,
                    () => ref
                        .read(stageServiceProvider)
                        .record(widget.orderId, st.key, result,
                            temp: parseNum(temp.text),
                            pressure: parseNum(press.text),
                            duration: parseNum(dur.text),
                            note: note.text),
                  );
                  if (ok && ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('সেভ'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _print(ProductionOrder o, Recipe? r, List<StageCheck> cs) async {
    final by = {for (final c in cs) c.stage: c};
    final doc = pw.Document();
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (_) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('Batch Stage Sheet', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Text('Order: ${o.orderNo}'),
          pw.Text('Recipe: ${r == null ? '-' : _en(r.recipeCode)}'),
          pw.Text('Target: ${fmtQty(o.targetQty)} ${_en(o.targetUnit)}'),
          pw.Text('Date: ${fmtDate(o.plannedDate ?? o.createdAt)}'),
          pw.Text('Overall: ${StageService.isAllPass(cs) ? 'ALL PASS' : 'INCOMPLETE'}'),
          pw.SizedBox(height: 12),
          pw.TableHelper.fromTextArray(
            headers: ['Stage', 'Result', 'Temp C', 'Press bar', 'Min', 'Time', 'Note'],
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            cellStyle: const pw.TextStyle(fontSize: 10),
            data: [
              for (final s in kStages)
                [
                  s.en,
                  (by[s.key]?.result ?? 'Pending').toUpperCase(),
                  by[s.key]?.tempValue == null ? '' : fmtQty(by[s.key]!.tempValue!),
                  by[s.key]?.pressureBar == null ? '' : fmtQty(by[s.key]!.pressureBar!),
                  by[s.key]?.durationMin == null ? '' : fmtQty(by[s.key]!.durationMin!),
                  by[s.key] == null ? '' : fmtDateTime(by[s.key]!.checkedAt),
                  _en(by[s.key]?.note ?? ''),
                ]
            ],
          ),
          pw.SizedBox(height: 30),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [pw.Text('Operator: ____________'), pw.Text('Supervisor: ____________')],
          ),
        ],
      ),
    ));
    final bytes = await doc.save();
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);
    final svc = ref.watch(stageServiceProvider);
    return StreamBuilder<ProductionOrder>(
      stream: (db.select(db.productionOrders)..where((o) => o.id.equals(widget.orderId))).watchSingle(),
      builder: (context, osnap) {
        final o = osnap.data;
        return StreamBuilder<List<StageCheck>>(
          stream: svc.watch(widget.orderId),
          builder: (context, snap) {
            final cs = snap.data ?? [];
            final by = {for (final c in cs) c.stage: c};
            final allPass = StageService.isAllPass(cs);
            final locked = o?.sheetLocked ?? false;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const SizedBox(width: 6),
                        const Text('ধাপ-সিট', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                        const SizedBox(width: 8),
                        if (allPass)
                          const Chip(
                            avatar: Icon(Icons.check_circle, color: Colors.white, size: 18),
                            label: Text('সব পাস', style: TextStyle(color: Colors.white, fontSize: 12)),
                            backgroundColor: Colors.green,
                            visualDensity: VisualDensity.compact,
                          )
                        else
                          Text('${cs.length}/${kStages.length}', style: const TextStyle(color: Colors.grey)),
                        const Spacer(),
                        IconButton(
                          tooltip: tr(locked ? 'আনলক' : 'লক'),
                          icon: Icon(locked ? Icons.lock : Icons.lock_open),
                          onPressed: () => runGuarded(context, () => svc.setLocked(widget.orderId, !locked),
                              success: locked ? 'আনলক হয়েছে' : 'সিট লক হয়েছে'),
                        ),
                        IconButton(
                          tooltip: tr('প্রিন্ট'),
                          icon: const Icon(Icons.print),
                          onPressed: o == null
                              ? null
                              : () async {
                                  final r = await (db.select(db.recipes)..where((x) => x.id.equals(o.recipeId)))
                                      .getSingleOrNull();
                                  await _print(o, r, cs);
                                },
                        ),
                        IconButton(
                          tooltip: tr(_open ? 'লুকান' : 'দেখান'),
                          icon: Icon(_open ? Icons.expand_less : Icons.expand_more),
                          onPressed: () => setState(() => _open = !_open),
                        ),
                      ],
                    ),
                    if (_open) ...[
                      for (final st in kStages)
                        ListTile(
                          dense: true,
                          leading: Icon(
                            by[st.key] == null ? Icons.radio_button_unchecked : Icons.check_circle,
                            color: _color(by[st.key]?.result),
                          ),
                          title: Text(st.label),
                          subtitle: by[st.key] == null
                              ? null
                              : Text([
                                  fmtDateTime(by[st.key]!.checkedAt),
                                  if (by[st.key]!.tempValue != null) '${fmtQty(by[st.key]!.tempValue!)}°C',
                                  if (by[st.key]!.pressureBar != null) '${fmtQty(by[st.key]!.pressureBar!)} bar',
                                  if (by[st.key]!.durationMin != null) '${fmtQty(by[st.key]!.durationMin!)} মি',
                                  if (by[st.key]!.note != null) by[st.key]!.note!,
                                ].join(' • ')),
                          trailing: Text(_label(by[st.key]?.result),
                              style: TextStyle(color: _color(by[st.key]?.result), fontWeight: FontWeight.w700)),
                          onTap: locked ? () => showSnack(context, 'লক করা আছে') : () => _edit(st, by[st.key]),
                        ),
                      if (!locked && !allPass)
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => runGuarded(context, () => svc.markAllPass(widget.orderId),
                                success: 'বাকি সব ধাপ পাস'),
                            icon: const Icon(Icons.done_all),
                            label: const Text('বাকি সব পাস'),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
