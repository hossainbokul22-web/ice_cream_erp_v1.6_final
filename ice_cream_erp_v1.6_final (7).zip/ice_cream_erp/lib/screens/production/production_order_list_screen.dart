import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Batch, Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';
import '../../services/stage_service.dart';
import '../../providers/settings_provider.dart';
import '../../services/settings_service.dart' show labelOf;
import '../../utils/ui.dart';
import 'create_production_order_screen.dart';
import 'production_order_detail_screen.dart';
import 'capacity_planning_screen.dart';
import 'demand_planning_screen.dart';
import 'mrp_screen.dart';
import 'mps_screen.dart';

class ProductionOrderListScreen extends ConsumerWidget {
  const ProductionOrderListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final sm = ref.watch(settingsMapProvider).valueOrNull;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
      appBar: AppBar(
        title: const Text('Production'),
        bottom: TabBar(tabs: [
          Tab(text: tr(labelOf(sm, 'prod_today', 'আজ'))),
          Tab(text: tr(labelOf(sm, 'prod_plan', 'আগামীকাল / প্ল্যান'))),
          Tab(text: tr(labelOf(sm, 'prod_done', 'শেষ'))),
        ]),
        actions: [
          IconButton(
            tooltip: 'Demand → PO',
            icon: const Icon(Icons.trending_up),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DemandPlanningScreen())),
          ),
          IconButton(
            tooltip: 'Capacity',
            icon: const Icon(Icons.view_timeline_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CapacityPlanningScreen())),
          ),
          IconButton(
            tooltip: 'MRP Shortage',
            icon: const Icon(Icons.playlist_add_check),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MrpScreen())),
          ),
          IconButton(
            tooltip: 'MPS Schedule',
            icon: const Icon(Icons.calendar_month),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MpsScreen())),
          ),
        ],
      ),
      body: StreamBuilder<List<ProductionOrder>>(
        stream: (db.select(db.productionOrders)..orderBy([(o) => OrderingTerm.desc(o.createdAt)])).watch(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final orders = snapshot.data!;
          final now = DateTime.now();
          final today = DateTime(now.year, now.month, now.day);
          bool isFuture(ProductionOrder o) {
            final d = o.plannedDate;
            return o.status == 'Planned' && d != null && DateTime(d.year, d.month, d.day).isAfter(today);
          }

          final plan = orders.where(isFuture).toList();
          final done = orders.where((o) => o.status == 'Completed' || o.status == 'Cancelled').toList();
          final todayList = orders
              .where((o) => !isFuture(o) && o.status != 'Completed' && o.status != 'Cancelled')
              .toList();
          return StreamBuilder<List<StageCheck>>(
            stream: db.select(db.stageChecks).watch(),
            builder: (context, csnap) {
              final all = csnap.data ?? [];
              final passIds = <int>{
                for (final id in {for (final c in all) c.productionOrderId})
                  if (StageService.isAllPass(all.where((c) => c.productionOrderId == id).toList())) id
              };
              return TabBarView(children: [
                _list(context, ref, todayList, passIds, 'আজ কোনো ব্যাচ নেই। + চাপুন ব্যাচ বসাতে।', false),
                _list(context, ref, plan, passIds, 'আগামীকালের কোনো প্ল্যান নেই।', true),
                _list(context, ref, done, passIds, 'শেষ হওয়া কিছু নেই।', false),
              ]);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateProductionOrderScreen()));
        },
        icon: const Icon(Icons.add),
        label: const Text('New Production'),
      ),
      ),
    );
  }

  Widget _list(BuildContext context, WidgetRef ref, List<ProductionOrder> orders, Set<int> passIds,
      String empty, bool isPlan) {
    if (orders.isEmpty) return Center(child: Text(empty));
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 90),
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final o = orders[index];
        Color statusColor;
        switch (o.status) {
          case 'Planned': statusColor = Colors.blue; break;
          case 'Mixing': statusColor = Colors.orange; break;
          case 'Aging': statusColor = Colors.purple; break;
          case 'Freezing': statusColor = Colors.indigo; break;
          case 'Completed': statusColor = Colors.green; break;
          default: statusColor = Colors.grey;
        }
        return Card(
          child: Column(
            children: [
              ListTile(
                title: Row(children: [
                  Text(o.orderNo, style: const TextStyle(fontWeight: FontWeight.bold)),
                  if (passIds.contains(o.id)) ...[
                    const SizedBox(width: 6),
                    const Icon(Icons.verified, color: Colors.green, size: 20),
                  ],
                ]),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Target Mix: ${o.targetQty} ${o.targetUnit}'
                        '${o.shift.isEmpty ? '' : ' • ${o.shift}'}'
                        '${o.plannedDate == null ? '' : ' • ${fmtDate(o.plannedDate)}'}'),
                    if (o.actualOverrun != null) Text('Overrun: ${o.actualOverrun!.toStringAsFixed(1)}%'),
                  ],
                ),
                trailing: Chip(
                  label: Text(o.status, style: const TextStyle(color: Colors.white, fontSize: 11)),
                  backgroundColor: statusColor,
                  visualDensity: VisualDensity.compact,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ProductionOrderDetailScreen(orderId: o.id)),
                ),
              ),
              if (isPlan)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.icon(
                      onPressed: () => runGuarded(
                        context,
                        () => ref.read(productionServiceProvider).startToday(o.id),
                        success: 'আজকের সিটে নেওয়া হয়েছে, কাঁচামাল কাটা হয়েছে',
                      ),
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('আজকের সিটে নিন'),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
