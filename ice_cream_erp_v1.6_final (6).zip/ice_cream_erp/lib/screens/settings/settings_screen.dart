import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../../providers/settings_provider.dart';
import '../../services/settings_service.dart';
import '../../utils/palette.dart';
import '../../utils/ui.dart';

/// Company profile (name, logo, address), auto backup, and editable tab names.
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _name = TextEditingController();
  final _nameEn = TextEditingController();
  final _addr = TextEditingController();
  final _addrEn = TextEditingController();
  final _phone = TextEditingController();
  final Map<String, TextEditingController> _labels = {};
  bool _loaded = false;
  bool _editing = true;
  String _logoB64 = '';
  bool _autoBackup = false;
  String _lastBackup = '';
  int _backupCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final svc = ref.read(settingsServiceProvider);
    final m = await svc.all();
    _name.text = m['company_name'] ?? '';
    _nameEn.text = m['company_name_en'] ?? '';
    _addr.text = m['company_address'] ?? '';
    _addrEn.text = m['company_address_en'] ?? '';
    _phone.text = m['company_phone'] ?? '';
    _logoB64 = m['logo'] ?? '';
    _autoBackup = m['auto_backup'] == '1';
    _lastBackup = m['last_backup'] ?? '';
    for (final g in kLabelGroups) {
      for (final (key, def) in g.$2) {
        _labels[key] = TextEditingController(text: m['label_$key'] ?? '');
      }
    }
    _editing = _name.text.trim().isEmpty;
    try {
      _backupCount = (await ref.read(backupServiceProvider).list()).length;
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _pickLogo() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 512, maxHeight: 512, imageQuality: 85);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      setState(() => _logoB64 = base64Encode(bytes));
    } catch (e) {
      if (mounted) showSnack(context, 'লোগো নেওয়া যায়নি: $e');
    }
  }

  Future<void> _saveCompany() async {
    if (_name.text.trim().isEmpty) {
      showSnack(context, 'কোম্পানির নাম দিন');
      return;
    }
    final svc = ref.read(settingsServiceProvider);
    final ok = await runGuarded(context, () async {
      await svc.setMany({
        'company_name': _name.text.trim(),
        'company_name_en': _nameEn.text.trim(),
        'company_address': _addr.text.trim(),
        'company_address_en': _addrEn.text.trim(),
        'company_phone': _phone.text.trim(),
        'logo': _logoB64,
      });
    }, success: 'কোম্পানির তথ্য সেভ হয়েছে');
    if (ok && mounted) setState(() => _editing = false);
  }

  Future<void> _saveLabels() async {
    final svc = ref.read(settingsServiceProvider);
    await runGuarded(context, () async {
      for (final e in _labels.entries) {
        final v = e.value.text.trim();
        if (v.isEmpty) {
          await svc.remove('label_${e.key}');
        } else {
          await svc.set('label_${e.key}', v);
        }
      }
    }, success: 'নাম সেভ হয়েছে');
  }

  Future<void> _resetLabels() async {
    if (!await confirm(context, 'ডিফল্টে ফিরবেন?', 'সব ট্যাবের নাম আগের নামে ফিরে যাবে।')) return;
    final svc = ref.read(settingsServiceProvider);
    for (final k in _labels.keys) {
      await svc.remove('label_$k');
      _labels[k]!.clear();
    }
    if (mounted) setState(() {});
  }

  Future<void> _toggleBackup(bool v) async {
    setState(() => _autoBackup = v);
    await ref.read(settingsServiceProvider).set('auto_backup', v ? '1' : '0');
    if (v && mounted) {
      // take the first one straight away
      await runGuarded(context, () async {
        await ref.read(backupServiceProvider).autoIfDue();
      }, success: 'অটো ব্যাকআপ চালু');
      await _refreshBackup();
    }
  }

  Future<void> _refreshBackup() async {
    final m = await ref.read(settingsServiceProvider).all();
    int n = _backupCount;
    try {
      n = (await ref.read(backupServiceProvider).list()).length;
    } catch (_) {}
    if (mounted) {
      setState(() {
        _lastBackup = m['last_backup'] ?? '';
        _backupCount = n;
      });
    }
  }

  Future<void> _backupNow() async {
    await runGuarded(context, () async {
      await ref.read(backupServiceProvider).backupNow();
    }, success: 'ব্যাকআপ নেওয়া হয়েছে');
    await _refreshBackup();
  }

  Future<void> _shareLatest() async {
    final files = await ref.read(backupServiceProvider).list();
    if (files.isEmpty) {
      if (mounted) showSnack(context, 'আগে একটা ব্যাকআপ নিন');
      return;
    }
    await Share.shareXFiles([XFile(files.first.path)], text: 'Ice Cream ERP backup');
  }

  Widget _section(Pal pal, String title, IconData icon, List<Widget> children) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: pal.box(r: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Icon(icon, color: pal.accent),
            const SizedBox(width: 8),
            Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: pal.ink)),
          ]),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool multi = false, TextInputType? type, String? hint}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        enabled: _editing,
        minLines: 1,
        maxLines: multi ? 3 : 1,
        keyboardType: type,
        decoration: InputDecoration(labelText: label, hintText: hint),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pal = Pal.of(context);
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final logo = _logoB64.isEmpty ? null : base64Decode(_logoB64);
    final last = DateTime.tryParse(_lastBackup);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section(pal, 'কোম্পানি', Icons.business_rounded, [
            Row(children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: pal.cardHi,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: pal.muted.withAlpha(70)),
                ),
                clipBehavior: Clip.antiAlias,
                child: logo == null
                    ? Icon(Icons.image_outlined, color: pal.muted, size: 32)
                    : Image.memory(logo, fit: BoxFit.cover),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton.icon(
                    onPressed: _editing ? _pickLogo : null,
                    icon: const Icon(Icons.upload_rounded),
                    label: Text(logo == null ? 'লোগো আপলোড' : 'লোগো বদলান'),
                  ),
                  if (logo != null)
                    TextButton(
                      onPressed: _editing ? () => setState(() => _logoB64 = '') : null,
                      child: const Text('মুছুন'),
                    ),
                ]),
              ),
            ]),
            const SizedBox(height: 14),
            _field(_name, 'কোম্পানির নাম *'),
            _field(_nameEn, 'Company name (English, প্রিন্টের জন্য)'),
            _field(_addr, 'ঠিকানা', multi: true),
            _field(_addrEn, 'Address (English, প্রিন্টের জন্য)', multi: true),
            _field(_phone, 'ফোন', type: TextInputType.phone),
            Text('প্রিন্ট (ইনভয়েস/ভাউচার) ইংরেজি অক্ষরে হয়, তাই English নাম ও ঠিকানা দিলে সুন্দর আসবে।',
                style: TextStyle(fontSize: 11, color: pal.muted)),
            const SizedBox(height: 10),
            _editing
                ? FilledButton.icon(onPressed: _saveCompany, icon: const Icon(Icons.save), label: const Text('সেভ করুন'))
                : OutlinedButton.icon(
                    onPressed: () => setState(() => _editing = true),
                    icon: const Icon(Icons.edit),
                    label: const Text('এডিট করুন'),
                  ),
          ]),
          _section(pal, 'অটো ব্যাকআপ', Icons.backup_rounded, [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('প্রতিদিন অটো ব্যাকআপ'),
              subtitle: const Text('অ্যাপ খুললে দিনে একবার, শেষ ৭টা রাখা হয়'),
              value: _autoBackup,
              onChanged: _toggleBackup,
            ),
            Text(
              last == null
                  ? 'এখনো ব্যাকআপ নেওয়া হয়নি'
                  : 'শেষ ব্যাকআপ: ${fmtDateTime(last)} • মোট $_backupCount টি',
              style: TextStyle(color: pal.muted, fontSize: 12),
            ),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              OutlinedButton.icon(onPressed: _backupNow, icon: const Icon(Icons.save_alt), label: const Text('এখনই ব্যাকআপ')),
              OutlinedButton.icon(onPressed: _shareLatest, icon: const Icon(Icons.share), label: const Text('শেষটা শেয়ার')),
            ]),
          ]),
          _section(pal, 'ট্যাব / মেনুর নাম', Icons.edit_note_rounded, [
            Text('খালি রাখলে আগের নামই থাকবে।', style: TextStyle(fontSize: 12, color: pal.muted)),
            const SizedBox(height: 8),
            for (final g in kLabelGroups) ...[
              Padding(
                padding: const EdgeInsets.only(top: 8, bottom: 6),
                child: Text(g.$1, style: TextStyle(fontWeight: FontWeight.w700, color: pal.accent)),
              ),
              for (final (key, def) in g.$2)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: TextField(
                    controller: _labels[key],
                    decoration: InputDecoration(labelText: def, hintText: def),
                  ),
                ),
            ],
            const SizedBox(height: 6),
            Row(children: [
              Expanded(
                child: FilledButton.icon(onPressed: _saveLabels, icon: const Icon(Icons.save), label: const Text('নাম সেভ')),
              ),
              const SizedBox(width: 8),
              OutlinedButton(onPressed: _resetLabels, child: const Text('ডিফল্ট')),
            ]),
          ]),
        ],
      ),
    );
  }
}
