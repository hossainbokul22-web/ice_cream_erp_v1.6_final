import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Control-room (HMI / SCADA) palette.
class Hmi {
  static const bg = Color(0xFF080F16);
  static const panel = Color(0xFF0F1A25);
  static const panelHi = Color(0xFF152433);
  static const line = Color(0xFF22384B);
  static const text = Color(0xFFE6EEF5);
  static const dim = Color(0xFF7D93A6);
  static const cyan = Color(0xFF38E1FF);
  static const amber = Color(0xFFFFB84D);
  static const green = Color(0xFF3DDC84);
  static const red = Color(0xFFFF5C5C);
  static const grey = Color(0xFF52667A);
}

/// Draws one piece of process equipment in a 96 x 96 box.
/// kind: 0 mixing tank, 1 pasteuriser, 2 homogeniser, 3 aging tank, 4 freezer, 5 packing line.
class EquipmentPainter extends CustomPainter {
  EquipmentPainter(this.kind, this.anim, this.active, this.color) : super(repaint: anim);
  final int kind;
  final Animation<double> anim;
  final bool active;
  final Color color;

  double get t => anim.value;

  Paint _stroke(Color c, [double w = 2]) => Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..color = c;

  Paint _fill(Color c) => Paint()
    ..style = PaintingStyle.fill
    ..color = c;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 96, size.height / 96);
    final c = active ? color : color.withAlpha(150);
    if (active) {
      canvas.drawCircle(
        const Offset(48, 48),
        40 + 3 * math.sin(t * 2 * math.pi),
        Paint()
          ..shader = RadialGradient(colors: [color.withAlpha(60), color.withAlpha(0)])
              .createShader(Rect.fromCircle(center: const Offset(48, 48), radius: 46)),
      );
    }
    switch (kind) {
      case 0:
        _mixing(canvas, c);
        break;
      case 1:
        _pasteuriser(canvas, c);
        break;
      case 2:
        _homogeniser(canvas, c);
        break;
      case 3:
        _aging(canvas, c);
        break;
      case 4:
        _freezer(canvas, c);
        break;
      default:
        _packing(canvas, c);
    }
    canvas.restore();
  }

  void _mixing(Canvas canvas, Color c) {
    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(22, 18, 52, 56), const Radius.circular(10));
    // liquid with moving surface
    canvas.save();
    canvas.clipRRect(body);
    final path = Path()..moveTo(22, 90);
    final lvl = 36.0;
    for (double x = 22; x <= 74; x += 2) {
      final y = lvl + (active ? 2.2 * math.sin((x / 9) + t * 2 * math.pi) : 0);
      path.lineTo(x, y);
    }
    path
      ..lineTo(74, 90)
      ..close();
    canvas.drawPath(path, _fill(c.withAlpha(active ? 110 : 60)));
    canvas.restore();
    canvas.drawRRect(body, _stroke(c));
    // motor + shaft + paddles
    canvas.drawRect(const Rect.fromLTWH(40, 4, 16, 9), _stroke(c, 1.6));
    canvas.drawLine(const Offset(48, 13), const Offset(48, 62), _stroke(c, 1.8));
    final a = active ? 15 * math.cos(t * 4 * math.pi) : 12.0;
    canvas.drawLine(Offset(48 - a, 58), Offset(48 + a, 58), _stroke(c, 2.4));
    final b = active ? 11 * math.sin(t * 4 * math.pi) : 8.0;
    canvas.drawLine(Offset(48 - b, 46), Offset(48 + b, 46), _stroke(c, 2));
    canvas.drawLine(const Offset(30, 74), const Offset(26, 86), _stroke(c, 1.6));
    canvas.drawLine(const Offset(66, 74), const Offset(70, 86), _stroke(c, 1.6));
  }

  void _pasteuriser(Canvas canvas, Color c) {
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(12, 28, 72, 44), const Radius.circular(6)), _stroke(c));
    for (var i = 0; i < 7; i++) {
      final x = 22.0 + i * 8.6;
      canvas.drawLine(Offset(x, 33), Offset(x, 67), _stroke(c.withAlpha(i.isEven ? 255 : 140), 1.6));
    }
    canvas.drawLine(const Offset(4, 40), const Offset(12, 40), _stroke(c));
    canvas.drawLine(const Offset(84, 60), const Offset(92, 60), _stroke(c));
    // rising heat waves
    for (var k = 0; k < 3; k++) {
      final ph = (t + k / 3) % 1;
      final y = 26 - ph * 20;
      final x = 30.0 + k * 18;
      final alpha = active ? (255 * (1 - ph)).round() : 40;
      final p = Path()..moveTo(x, y);
      p.quadraticBezierTo(x + 4, y - 4, x, y - 8);
      p.quadraticBezierTo(x - 4, y - 12, x, y - 16);
      canvas.drawPath(p, _stroke(const Color(0xFFFF8A3D).withAlpha(alpha), 2));
    }
    // thermometer
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(46, 74, 4, 14), const Radius.circular(2)), _stroke(c, 1.4));
    canvas.drawCircle(const Offset(48, 90), 3, _fill(active ? const Color(0xFFFF8A3D) : c));
  }

  void _homogeniser(Canvas canvas, Color c) {
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(12, 44, 72, 32), const Radius.circular(6)), _stroke(c));
    for (var i = 0; i < 3; i++) {
      final off = active ? 5 * math.sin(t * 2 * math.pi * 2 + i * 2.1) : 0.0;
      canvas.drawRect(Rect.fromLTWH(20 + i * 22.0, 50 + off, 12, 16), _fill(c.withAlpha(active ? 130 : 70)));
      canvas.drawLine(Offset(26 + i * 22.0, 50 + off), Offset(26 + i * 22.0, 40 + off), _stroke(c, 2));
    }
    // pressure gauge
    const centre = Offset(48, 22);
    canvas.drawCircle(centre, 15, _stroke(c, 1.8));
    canvas.drawArc(Rect.fromCircle(center: centre, radius: 11), math.pi * 0.75, math.pi * 1.5, false, _stroke(c.withAlpha(110), 1.4));
    final f = active ? 0.55 + 0.25 * math.sin(t * 2 * math.pi * 2) : 0.1;
    final ang = math.pi * 0.75 + math.pi * 1.5 * f;
    canvas.drawLine(centre, centre + Offset(math.cos(ang), math.sin(ang)) * 11, _stroke(active ? Hmi.amber : c, 2));
    canvas.drawCircle(centre, 2, _fill(c));
    canvas.drawLine(const Offset(48, 37), const Offset(48, 44), _stroke(c, 1.6));
  }

  void _aging(Canvas canvas, Color c) {
    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(22, 8, 52, 58), const Radius.circular(12));
    final jacket = RRect.fromRectAndRadius(const Rect.fromLTWH(17, 4, 62, 66), const Radius.circular(16));
    canvas.drawRRect(jacket, _stroke(c.withAlpha(90), 1.2));
    canvas.save();
    canvas.clipRRect(body);
    canvas.drawRect(const Rect.fromLTWH(22, 30, 52, 40), _fill(c.withAlpha(active ? 90 : 50)));
    for (var i = 0; i < 6; i++) {
      final ph = (t * 0.6 + i / 6) % 1;
      final x = 28.0 + i * 8;
      final y = 66 - ph * 34;
      canvas.drawCircle(Offset(x, y), 1.6, _fill(Colors.white.withAlpha(active ? 190 : 70)));
    }
    canvas.restore();
    canvas.drawRRect(body, _stroke(c));
    canvas.drawPath(
      Path()
        ..moveTo(26, 66)
        ..lineTo(48, 84)
        ..lineTo(70, 66),
      _stroke(c),
    );
    canvas.drawLine(const Offset(48, 84), const Offset(48, 92), _stroke(c));
  }

  void _freezer(Canvas canvas, Color c) {
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(10, 20, 76, 54), const Radius.circular(8)), _stroke(c));
    canvas.drawLine(const Offset(10, 34), const Offset(86, 34), _stroke(c.withAlpha(120), 1.2));
    const centre = Offset(48, 54);
    final rot = active ? t * math.pi : 0.0;
    for (var i = 0; i < 3; i++) {
      final a = rot + i * math.pi / 3;
      final d = Offset(math.cos(a), math.sin(a)) * 15;
      canvas.drawLine(centre - d, centre + d, _stroke(c, 2));
      final tip = Offset(math.cos(a + math.pi / 2), math.sin(a + math.pi / 2)) * 4;
      canvas.drawLine(centre + d, centre + d * 0.7 + tip, _stroke(c, 1.4));
      canvas.drawLine(centre + d, centre + d * 0.7 - tip, _stroke(c, 1.4));
      canvas.drawLine(centre - d, centre - d * 0.7 + tip, _stroke(c, 1.4));
      canvas.drawLine(centre - d, centre - d * 0.7 - tip, _stroke(c, 1.4));
    }
    canvas.drawLine(const Offset(20, 78), const Offset(20, 88), _stroke(c, 1.6));
    canvas.drawLine(const Offset(76, 78), const Offset(76, 88), _stroke(c, 1.6));
  }

  void _packing(Canvas canvas, Color c) {
    canvas.drawLine(const Offset(6, 70), const Offset(90, 70), _stroke(c, 2));
    for (var i = 0; i < 5; i++) {
      canvas.drawCircle(Offset(12.0 + i * 18, 76), 3.2, _stroke(c, 1.4));
    }
    for (var i = 0; i < 2; i++) {
      final x = 4 + ((active ? t : 0.25) * 90 + i * 46) % 92;
      final r = Rect.fromLTWH(x - 10, 48, 22, 20);
      canvas.drawRect(r, _fill(c.withAlpha(active ? 90 : 50)));
      canvas.drawRect(r, _stroke(c, 1.8));
      canvas.drawLine(Offset(x + 1, 48), Offset(x + 1, 68), _stroke(c.withAlpha(160), 1.2));
    }
    // overhead filler
    canvas.drawRect(const Rect.fromLTWH(34, 12, 28, 14), _stroke(c, 1.6));
    canvas.drawLine(const Offset(48, 26), const Offset(48, 40), _stroke(c, 1.6));
  }

  @override
  bool shouldRepaint(covariant EquipmentPainter old) => true;
}

/// Vertical product pipe between two stations with flowing droplets.
class PipePainter extends CustomPainter {
  PipePainter(this.anim, this.from, this.to, this.flowing) : super(repaint: anim);
  final Animation<double> anim;
  final Color from;
  final Color to;
  final bool flowing;

  @override
  void paint(Canvas canvas, Size size) {
    final x = size.width / 2;
    final rect = Rect.fromLTWH(x - 5, 0, 10, size.height);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(3)),
      Paint()..color = Hmi.line,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect.deflate(1.5), const Radius.circular(2)),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [from.withAlpha(flowing ? 150 : 50), to.withAlpha(flowing ? 150 : 50)],
        ).createShader(rect),
    );
    if (!flowing) return;
    for (var i = 0; i < 3; i++) {
      final ph = (anim.value + i / 3) % 1;
      final y = ph * size.height;
      canvas.drawCircle(
        Offset(x, y),
        2.4,
        Paint()..color = Color.lerp(from, to, ph)!.withAlpha(240),
      );
    }
    // flow chevron
    final cy = size.height / 2;
    canvas.drawPath(
      Path()
        ..moveTo(x - 4, cy - 2)
        ..lineTo(x, cy + 3)
        ..lineTo(x + 4, cy - 2),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = Colors.white.withAlpha(150),
    );
  }

  @override
  bool shouldRepaint(covariant PipePainter old) => true;
}

/// Thin corner brackets for the industrial panel look.
class BracketPainter extends CustomPainter {
  BracketPainter(this.color);
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = color;
    const l = 10.0;
    final w = size.width, h = size.height;
    canvas.drawPath(Path()..moveTo(0, l)..lineTo(0, 0)..lineTo(l, 0), p);
    canvas.drawPath(Path()..moveTo(w - l, 0)..lineTo(w, 0)..lineTo(w, l), p);
    canvas.drawPath(Path()..moveTo(0, h - l)..lineTo(0, h)..lineTo(l, h), p);
    canvas.drawPath(Path()..moveTo(w - l, h)..lineTo(w, h)..lineTo(w, h - l), p);
  }

  @override
  bool shouldRepaint(covariant BracketPainter old) => old.color != color;
}
