import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/auth_provider.dart';
import '../../providers/database_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/audit_service.dart';
import '../../utils/ui.dart';

/// Owner screen: add users with a role and PIN.
class UsersScreen extends ConsumerStatefulWidget {
  const UsersScreen({super.key});

  @override
  ConsumerState<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends ConsumerState<UsersScreen> {
  Future<void> _edit({AppUser? user}) async {
    final db = ref.read(databaseProvider);
    final all = await db.select(db.appUsers).get();
    final noUsersYet = all.isEmpty;
    final name = TextEditingController(text: user?.userName ?? '');
    final pin = TextEditingController();
    String role = user?.role ?? (noUsersYet ? 'Owner' : 'Operator');
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(user == null ? 'New user' : 'Edit user'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (noUsersYet)
                const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text('This first user will be the Owner. After saving, the app will ask for a PIN at every start.',
                      style: TextStyle(fontSize: 12)),
                ),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: role,
                decoration: const InputDecoration(labelText: 'Role'),
                items: [for (final r in kRoles) DropdownMenuItem(value: r, child: Text(r))],
                onChanged: noUsersYet ? null : (v) => setD(() => role = v!),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: pin,
                obscureText: true,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: user == null ? 'PIN (4+ digits)' : 'New PIN (leave blank to keep)'),
              ),
              const SizedBox(height: 8),
              const Text('Owner: everything • Operator: production, packing, temperature • Store: purchase, sale, stock, reports',
                  style: TextStyle(fontSize: 11)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                final n = name.text.trim();
                final p = pin.text.trim();
                if (n.isEmpty) {
                  showSnack(ctx, 'Enter a name');
                  return;
                }
                if (user == null && p.length < 4) {
                  showSnack(ctx, 'PIN must be at least 4 digits');
                  return;
                }
                if (p.isNotEmpty && (p.length < 4 || int.tryParse(p) == null)) {
                  showSnack(ctx, 'PIN must be 4 or more digits');
                  return;
                }
                if (user != null && user.role == 'Owner' && role != 'Owner') {
                  final owners = all.where((u) => u.role == 'Owner' && u.isActive && u.id != user.id).length;
                  if (owners == 0) {
                    showSnack(ctx, 'At least one active Owner is required');
                    return;
                  }
                }
                AppUser? created;
                final ok = await runGuarded(ctx, () async {
                  if (user == null) {
                    final id = await db.into(db.appUsers).insert(AppUsersCompanion.insert(
                          userName: n,
                          pinHash: hashPin(p),
                          role: role,
                        ));
                    created = await (db.select(db.appUsers)..where((u) => u.id.equals(id))).getSingle();
                    await Audit.write(db, 'User added', '$n ($role)');
                  } else {
                    await (db.update(db.appUsers)..where((u) => u.id.equals(user.id))).write(AppUsersCompanion(
                      userName: Value(n),
                      role: Value(role),
                      pinHash: p.isEmpty ? const Value.absent() : Value(hashPin(p)),
                    ));
                    await Audit.write(db, 'User edited', '$n ($role)${p.isEmpty ? '' : ' — PIN changed'}');
                  }
                });
                if (ok && ctx.mounted) {
                  Navigator.pop(ctx);
                  if (noUsersYet && created != null) {
                    try {
                      await ref.read(settingsServiceProvider).set('remember_user', created!.id.toString());
                    } catch (_) {}
                    setSession(ref, created);
                  }
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggle(AppUser u, List<AppUser> all) async {
    if (u.isActive && u.role == 'Owner' && all.where((x) => x.role == 'Owner' && x.isActive && x.id != u.id).isEmpty) {
      showSnack(context, 'At least one active Owner is required');
      return;
    }
    final db = ref.read(databaseProvider);
    await (db.update(db.appUsers)..where((x) => x.id.equals(u.id))).write(AppUsersCompanion(isActive: Value(!u.isActive)));
    await Audit.write(db, u.isActive ? 'User disabled' : 'User enabled', u.userName);
  }

  Future<void> _delete(AppUser u, List<AppUser> all) async {
    final cur = ref.read(currentUserProvider);
    if (cur != null && cur.id == u.id) {
      showSnack(context, 'You cannot delete the user you are logged in as');
      return;
    }
    if (u.role == 'Owner' && all.where((x) => x.role == 'Owner' && x.isActive && x.id != u.id).isEmpty) {
      showSnack(context, 'At least one active Owner is required');
      return;
    }
    if (!await confirm(context, 'Delete user?', '${u.userName} will not be able to log in.')) return;
    final db = ref.read(databaseProvider);
    await (db.delete(db.appUsers)..where((x) => x.id.equals(u.id))).go();
    await Audit.write(db, 'User deleted', u.userName);
  }

  @override
  Widget build(BuildContext context) {
    final users = ref.watch(usersProvider).valueOrNull ?? <AppUser>[];
    final cur = ref.watch(currentUserProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Users & Roles')),
      floatingActionButton: FloatingActionButton(onPressed: () => _edit(), child: const Icon(Icons.person_add_alt_1)),
      body: users.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                    'No users yet — the app opens without a login.\nTap + to add the Owner. After that every start asks for a PIN.',
                    textAlign: TextAlign.center),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                for (final u in users)
                  Card(
                    child: ListTile(
                      leading: CircleAvatar(child: Icon(u.role == 'Owner' ? Icons.verified_user : Icons.person)),
                      title: Text('${u.userName}${cur?.id == u.id ? '  (you)' : ''}'),
                      subtitle: Text('${u.role}${u.isActive ? '' : ' • disabled'}'),
                      onTap: () => _edit(user: u),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Switch(value: u.isActive, onChanged: (_) => _toggle(u, users)),
                        IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () => _delete(u, users)),
                      ]),
                    ),
                  ),
              ],
            ),
    );
  }
}
