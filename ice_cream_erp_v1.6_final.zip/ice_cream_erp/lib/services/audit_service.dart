import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';

/// Writes the audit trail ("who did what"). Never throws: a logging problem must not stop real work.
class Audit {
  /// Name of the person logged in right now ('' when the app runs without users).
  static String user = '';

  static Future<void> write(AppDatabase db, String action, [String detail = '']) async {
    try {
      await db.into(db.auditLogs).insert(AuditLogsCompanion.insert(
            action: action,
            userName: Value(user),
            detail: Value(detail),
          ));
    } catch (_) {}
  }
}

/// Simple PIN scrambling (a convenience lock for the shop floor, not bank-grade security).
String hashPin(String pin) {
  var a = 7;
  var b = 11;
  for (final c in 'ice\u0001$pin\u0002cream'.codeUnits) {
    a = (a * 131 + c) % 1000000007;
    b = (b * 137 + c) % 998244353;
  }
  return '$a-$b';
}

const List<String> kRoles = ['Owner', 'Operator', 'Store'];

const Map<String, Set<String>> _rolePerms = {
  'Operator': {
    'dashboard', 'home', 'production', 'stock', 'quickbatch', 'packing', 'standards',
    'templog', 'tanks', 'freezers', 'movement', 'schedule',
  },
  'Store': {
    'dashboard', 'home', 'stock', 'reports', 'purchase', 'sale', 'items', 'parties',
    'packing', 'movement', 'templog',
  },
};

/// [role] == null means the app is running without users (everything allowed).
bool can(String? role, String feature) {
  if (role == null || role == 'Owner') return true;
  return _rolePerms[role]?.contains(feature) ?? false;
}

/// Which permission a screen path needs (null = no restriction).
String? featureForPath(String path) {
  if (path == '/dashboard') return 'dashboard';
  if (path == '/') return 'home';
  if (path.startsWith('/production')) return 'production';
  if (path.startsWith('/stock')) return 'stock';
  if (path.startsWith('/vouchers')) return 'vouchers';
  if (path.startsWith('/reports')) return 'reports';
  if (path.startsWith('/quick-')) return 'quickbatch';
  const m = {
    '/packing': 'packing',
    '/items': 'items',
    '/recipes': 'recipes',
    '/tanks': 'tanks',
    '/freezers': 'freezers',
    '/standards': 'standards',
    '/parties': 'parties',
    '/purchase': 'purchase',
    '/sale': 'sale',
    '/movement': 'movement',
    '/templog': 'templog',
    '/schedule': 'schedule',
    '/settings': 'settings',
    '/users': 'users',
    '/audit': 'audit',
  };
  return m[path];
}
