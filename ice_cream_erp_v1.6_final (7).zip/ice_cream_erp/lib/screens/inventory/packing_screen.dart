import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/packing_service.dart';
import '../../utils/ui.dart';

final packingServiceProvider =
    Provider<PackingService>((ref) => PackingService(ref.watch(databaseProvider)));

/// Pick a finished product (recipe), enter total cartons -> packaging auto-deducted.
class PackingScreen extends ConsumerStatefulWidget {
  const PackingScreen({super.key});

  @override
  ConsumerState<PackingScreen> createState() => _PackingScreenState();
}

class _PackingScreenState extends ConsumerState<PackingScreen> {
  final _cartons = TextEditingController();
  final _note = TextEditingController();
  final _loose = TextEditingController();
  int? _recipeId;
  int? _orderId;
  String _shift = 'সকাল';
  DateTime _date = DateTime.now();
  int _tick = 0;

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);
    final cartons = parseNum(_cartons.text) ?? 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Packing / কার্টুন এন্ট্রি')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          FutureBuilder<List<Recipe>>(
            future: (db.select(db.recipes)..where((r) => r.isActive.equals(true))).get(),
            builder: (context, snap) {
              final rs = snap.data ?? [];
              return DropdownButtonFormField<int>(
                isExpanded: true,
                value: rs.any((r) => r.id == _recipeId) ? _recipeId : null,
                decoration: const InputDecoration(label: Text('ফিনিশ প্রোডাক্ট (রেসিপি) *')),
                items: rs
                    .map((r) => DropdownMenuItem(
                        value: r.id, child: Text('${r.recipeCode} - ${r.recipeName}', overflow: TextOverflow.ellipsis)))
                    .toList(),
                onChanged: (v) => setState(() {
                  _recipeId = v;
                  _orderId = null;
                }),
              );
            },
          ),
          const SizedBox(height: 10),
          if (_recipeId != null)
            FutureBuilder<List<PackableOrder>>(
              key: ValueKey('po-$_recipeId-$_tick'),
              future: ref.read(packingServiceProvider).packableOrders(_recipeId!),
              builder: (context, snap) {
                final os = snap.data ?? [];
                if (os.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Text(
                        'কোনো Completed ব্যাচ নেই (বা রেসিপিতে ১ কার্টন = পিস × মিলি সেট নেই)। এখন শুধু প্যাকেজিং কাটবে, ফিনিশ স্টক বাড়বে না।',
                        style: TextStyle(color: Colors.orange, fontSize: 12)),
                  );
                }
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: DropdownButtonFormField<int>(
                    isExpanded: true,
                    value: os.any((x) => x.order.id == _orderId) ? _orderId : null,
                    decoration: const InputDecoration(label: Text('কোন ব্যাচের কার্টন? (ফিনিশ স্টকে যোগ হবে)')),
                    items: [
                      for (final x in os)
                        DropdownMenuItem(
                          value: x.order.id,
                          child: Text(
                              '${x.order.orderNo} • ${fmtQty(x.order.actualFinishedQty ?? 0)} L • বাকি ≈ ${fmtQty(x.remaining)} কার্টন',
                              overflow: TextOverflow.ellipsis),
                        ),
                    ],
                    onChanged: (v) => setState(() => _orderId = v),
                  ),
                );
              },
            ),
          TextField(
            controller: _cartons,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(label: Text('মোট কার্টুন *')),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              for (final s in ['সকাল', 'বিকাল', 'রাত'])
                ChoiceChip(label: Text(s), selected: _shift == s, onSelected: (_) => setState(() => _shift = s)),
            ],
          ),
          const SizedBox(height: 8),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: Text('তারিখ: ${fmtDate(_date)}'),
            onTap: () async {
              final d = await showDatePicker(
                  context: context, initialDate: _date, firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (d != null) setState(() => _date = d);
            },
          ),
          TextField(controller: _note, decoration: const InputDecoration(label: Text('নোট (ঐচ্ছিক)'))),
          const SizedBox(height: 12),
          if (_recipeId != null && cartons > 0)
            FutureBuilder<List<PackNeed>>(
              key: ValueKey('$_recipeId-$cartons-$_tick'),
              future: ref.read(packingServiceProvider).preview(_recipeId!, cartons),
              builder: (context, snap) {
                if (!snap.hasData) return const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator());
                final needs = snap.data!;
                if (needs.isEmpty) {
                  return const Text('এই রেসিপিতে প্যাকেজিং তালিকা নেই। রেসিপি এডিটে "Packaging (১ কার্টুনে)" যোগ করুন।',
                      style: TextStyle(color: Colors.red));
                }
                final anyShort = needs.any((n) => n.short);
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('যা কাটা হবে', style: TextStyle(fontWeight: FontWeight.w800)),
                    for (final n in needs)
                      Card(
                        color: n.short ? Colors.red.withAlpha(35) : null,
                        child: ListTile(
                          dense: true,
                          title: Text('${n.item.itemCode} - ${n.item.itemName}'),
                          subtitle: Text('লাগবে ${fmtQty(n.need)} ${n.item.baseUnit} • স্টকে ${fmtQty(n.have)}'),
                          trailing: Icon(n.short ? Icons.warning_amber_rounded : Icons.check_circle,
                              color: n.short ? Colors.red : Colors.green),
                        ),
                      ),
                    if (anyShort)
                      const Padding(
                        padding: EdgeInsets.only(top: 4),
                        child: Text('⚠ কিছু প্যাকেজিং এর স্টক কম। আগে Purchase করুন।', style: TextStyle(color: Colors.red)),
                      ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: anyShort
                          ? null
                          : () async {
                              final ok = await runGuarded(
                                context,
                                () => ref.read(packingServiceProvider).pack(
                                      recipeId: _recipeId!,
                                      cartons: cartons,
                                      loosePcs: parseNum(_loose.text) ?? 0,
                                      orderId: _orderId,
                                      date: _date,
                                      shift: _shift,
                                      note: _note.text.trim().isEmpty ? null : _note.text.trim(),
                                    ),
                                success: _orderId == null ? 'প্যাকিং সেভ হয়েছে, প্যাকেজিং স্টক কমেছে' : 'প্যাকিং সেভ: প্যাকেজিং কমেছে, ফিনিশ কার্টন স্টকে যোগ হয়েছে',
                              );
                              if (ok) {
                                _cartons.clear();
                                _loose.clear();
                                _note.clear();
                                setState(() => _tick++);
                              }
                            },
                      icon: const Icon(Icons.inventory_2_rounded),
                      label: const Text('প্যাকিং সেভ করুন'),
                    ),
                  ],
                );
              },
            ),
          const Divider(height: 32),
          const Text('সাম্প্রতিক প্যাকিং', style: TextStyle(fontWeight: FontWeight.w800)),
          FutureBuilder<List<PackingRun>>(
            key: ValueKey('runs-$_tick'),
            future: (db.select(db.packingRuns)
                  ..orderBy([(r) => OrderingTerm.desc(r.id)])
                  ..limit(30))
                .get(),
            builder: (context, snap) {
              final runs = snap.data ?? [];
              if (runs.isEmpty) return const Padding(padding: EdgeInsets.all(8), child: Text('এখনো কিছু নেই'));
              return FutureBuilder<List<Recipe>>(
                future: db.select(db.recipes).get(),
                builder: (context, rsnap) {
                  final byId = {for (final r in rsnap.data ?? <Recipe>[]) r.id: r};
                  return Column(
                    children: [
                      for (final r in runs)
                        ListTile(
                          dense: true,
                          title: Text(byId[r.recipeId]?.recipeName ?? 'Recipe #${r.recipeId}'),
                          subtitle: Text('${fmtDate(r.runDate)} • ${r.shift}'),
                          trailing: Text('${fmtQty(r.cartons)} কার্টুন', style: const TextStyle(fontWeight: FontWeight.w700)),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
