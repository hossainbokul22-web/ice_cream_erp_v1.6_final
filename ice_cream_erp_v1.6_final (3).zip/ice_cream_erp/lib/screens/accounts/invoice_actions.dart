import 'dart:typed_data';
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../../database/app_database.dart';
import '../../services/invoice_pdf_service.dart';

Future<List<int>> _bytes(AppDatabase db, int invoiceId) async {
  final inv = await (db.select(db.saleInvoices)..where((i) => i.id.equals(invoiceId))).getSingle();
  final lines = await (db.select(db.saleInvoiceLines)..where((l) => l.invoiceId.equals(invoiceId))).get();
  Party? party;
  if (inv.partyId != null) {
    party = await (db.select(db.parties)..where((p) => p.id.equals(inv.partyId!))).getSingleOrNull();
  }
  return InvoicePdfService.build(invoice: inv, lines: lines, party: party);
}

Future<void> printInvoice(AppDatabase db, int invoiceId) async {
  final b = await _bytes(db, invoiceId);
  await Printing.layoutPdf(onLayout: (_) async => Uint8List.fromList(b));
}

Future<void> shareInvoice(AppDatabase db, int invoiceId, String invoiceNo) async {
  final b = await _bytes(db, invoiceId);
  await Printing.sharePdf(bytes: Uint8List.fromList(b), filename: '$invoiceNo.pdf');
}

/// Print / share chooser for one invoice.
Future<void> invoiceSheet(BuildContext context, AppDatabase db, int invoiceId, String invoiceNo) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(title: Text(invoiceNo, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          ListTile(
            leading: const Icon(Icons.print),
            title: const Text('প্রিন্ট করুন'),
            onTap: () async {
              Navigator.pop(ctx);
              await printInvoice(db, invoiceId);
            },
          ),
          ListTile(
            leading: const Icon(Icons.share),
            title: const Text('PDF শেয়ার (WhatsApp ইত্যাদি)'),
            onTap: () async {
              Navigator.pop(ctx);
              await shareInvoice(db, invoiceId, invoiceNo);
            },
          ),
        ],
      ),
    ),
  );
}
