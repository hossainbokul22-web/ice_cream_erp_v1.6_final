import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';

class PackNeed {
  PackNeed(this.item, this.need, this.have);
  final Item item;
  final double need;
  final double have;
  bool get short => have + 0.0001 < need;
}

/// Carton entry -> packaging materials are deducted automatically (FIFO).
class PackingService {
  PackingService(this.db);
  final AppDatabase db;

  double _r(double v) => (v * 10000).round() / 10000;

  Future<List<PackNeed>> preview(int recipeId, double cartons) async {
    final lines = await (db.select(db.recipePackLines)..where((l) => l.recipeId.equals(recipeId))).get();
    final out = <PackNeed>[];
    for (final l in lines) {
      final it = await (db.select(db.items)..where((i) => i.id.equals(l.itemId))).getSingle();
      final bs = await (db.select(db.batches)
            ..where((b) => b.itemId.equals(l.itemId) & b.currentQty.isBiggerThanValue(0)))
          .get();
      final have = bs.fold<double>(0, (a, b) => a + b.currentQty);
      out.add(PackNeed(it, _r(l.qtyPerCarton * cartons), have));
    }
    return out;
  }

  Future<void> pack({
    required int recipeId,
    required double cartons,
    required DateTime date,
    String shift = '',
    String? note,
  }) async {
    if (cartons <= 0) throw StateError('কার্টুন সংখ্যা ০ এর বেশি হতে হবে');
    final needs = await preview(recipeId, cartons);
    if (needs.isEmpty) throw StateError('এই রেসিপিতে প্যাকেজিং তালিকা নেই');
    final shortList = needs.where((n) => n.short).toList();
    if (shortList.isNotEmpty) {
      throw StateError('প্যাকেজিং স্টক কম: ' +
          shortList.map((n) => '${n.item.itemName} (লাগবে ${n.need}, আছে ${n.have})').join(', '));
    }
    await db.transaction(() async {
      final runId = await db.into(db.packingRuns).insert(PackingRunsCompanion.insert(
            recipeId: recipeId,
            cartons: cartons,
            runDate: date,
            shift: Value(shift),
            note: Value(note),
          ));
      for (final n in needs) {
        var remaining = n.need;
        final bs = await (db.select(db.batches)
              ..where((b) => b.itemId.equals(n.item.id) & b.currentQty.isBiggerThanValue(0))
              ..orderBy([(b) => OrderingTerm.asc(b.id)]))
            .get();
        for (final b in bs) {
          if (remaining <= 0.00001) break;
          final take = remaining < b.currentQty ? remaining : b.currentQty;
          await (db.update(db.batches)..where((x) => x.id.equals(b.id)))
              .write(BatchesCompanion(currentQty: Value(_r(b.currentQty - take))));
          await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
                voucherId: Value(runId),
                voucherType: 'Packing',
                itemId: n.item.id,
                batchId: Value(b.id),
                warehouseId: Value(b.warehouseId),
                qtyOut: Value(_r(take)),
                unitCost: Value(b.unitCost),
                transactionDate: date,
                narration: Value('Packing: ${_r(cartons)} কার্টুন'),
              ));
          remaining = _r(remaining - take);
        }
      }
    });
  }
}
