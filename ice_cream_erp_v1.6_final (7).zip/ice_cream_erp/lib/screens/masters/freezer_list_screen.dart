import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/plant_service.dart';
import '../../utils/ui.dart';

/// Freezer master: add one by one or many at once (e.g. 20 freezers).
class FreezerListScreen extends ConsumerWidget {
  const FreezerListScreen({super.key});

  Future<void> _edit(BuildContext context, WidgetRef ref, Freezer? f) async {
    final code = TextEditingController(text: f?.freezerCode ?? '');
    final name = TextEditingController(text: f?.freezerName ?? '');
    final cap = TextEditingController(text: f == null ? '' : fmtQty(f.capacityLiter));
    var active = f?.isActive ?? true;
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(f == null ? 'নতুন ফ্রিজার' : 'ফ্রিজার এডিট'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: code, decoration: const InputDecoration(label: Text('কোড (যেমন F-001)'))),
              TextField(controller: name, decoration: const InputDecoration(label: Text('নাম'))),
              TextField(
                controller: cap,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('ক্ষমতা (লিটার/ব্যাচ)')),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('চালু (Active)'),
                value: active,
                onChanged: (v) => setS(() => active = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('সেভ')),
          ],
        ),
      ),
    );
    if (go != true || !context.mounted) return;
    await runGuarded(context, () => ref.read(plantServiceProvider).saveFreezer(
          id: f?.id,
          code: code.text,
          name: name.text,
          capacity: parseNum(cap.text) ?? 0,
          active: active,
        ));
  }

  Future<void> _bulk(BuildContext context, WidgetRef ref) async {
    final n = TextEditingController(text: '20');
    final cap = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('একসাথে অনেকগুলো ফ্রিজার'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: n,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(label: Text('কয়টা ফ্রিজার যোগ হবে')),
          ),
          TextField(
            controller: cap,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(label: Text('প্রতিটার ক্ষমতা (লিটার/ব্যাচ)')),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('যোগ করুন')),
        ],
      ),
    );
    if (go != true || !context.mounted) return;
    await runGuarded(
      context,
      () async {
        await ref.read(plantServiceProvider).addFreezers((parseNum(n.text) ?? 0).round(), parseNum(cap.text) ?? 0);
      },
      success: 'ফ্রিজার যোগ হয়েছে',
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('ফ্রিজার')),
      floatingActionButton: Column(mainAxisSize: MainAxisSize.min, children: [
        FloatingActionButton.small(
          heroTag: 'frz_bulk',
          onPressed: () => _bulk(context, ref),
          child: const Icon(Icons.playlist_add),
        ),
        const SizedBox(height: 10),
        FloatingActionButton(
          heroTag: 'frz_add',
          onPressed: () => _edit(context, ref, null),
          child: const Icon(Icons.add),
        ),
      ]),
      body: StreamBuilder<List<Freezer>>(
        stream: db.select(db.freezers).watch(),
        builder: (context, snap) {
          final list = [...(snap.data ?? <Freezer>[])]..sort((a, b) => a.freezerCode.compareTo(b.freezerCode));
          if (snap.connectionState == ConnectionState.waiting && list.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (list.isEmpty) {
            return const Center(child: Text('কোনো ফ্রিজার নেই। + চাপুন, অথবা উপরের ছোট বাটনে একসাথে অনেকগুলো যোগ করুন।'));
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 120),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final f = list[i];
              return Card(
                child: ListTile(
                  leading: Icon(Icons.ac_unit_rounded, color: f.isActive ? const Color(0xFF1E6BE0) : Colors.grey),
                  title: Text('${f.freezerCode} • ${f.freezerName}'),
                  subtitle: Text('ক্ষমতা ${fmtQty(f.capacityLiter)} L${f.isActive ? '' : ' • বন্ধ'}'),
                  onTap: () => _edit(context, ref, f),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final sure = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: Text('${f.freezerCode} মুছবেন?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
                            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
                          ],
                        ),
                      );
                      if (sure == true && context.mounted) {
                        await runGuarded(context, () => ref.read(plantServiceProvider).deleteFreezer(f.id));
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
