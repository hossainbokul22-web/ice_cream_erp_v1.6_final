import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/stock_service.dart';
import '../../providers/settings_provider.dart';
import '../../services/settings_service.dart' show labelOf;
import '../../utils/ui.dart';
import 'purchase_receipt_screen.dart';

/// One tab of the stock screen.
class _Cat {
  const _Cat(this.title, this.types, this.inLabel, this.outLabel, {this.purchaseOnly = false, this.salesOnly = false});
  final String title;
  final List<String> types;
  final String inLabel; // 2nd column label
  final String outLabel; // 3rd column label
  final bool purchaseOnly; // "In" = purchases only (raw / packaging)
  final bool salesOnly; // "Out" = sales only (finished goods)
}

const List<_Cat> _cats = [
  _Cat('কাঁচামাল', ['Raw'], 'Purchase', 'Used', purchaseOnly: true),
  _Cat('প্যাকেজিং', ['Packaging'], 'Purchase', 'Used', purchaseOnly: true),
  _Cat('মিক্স', ['Mix', 'Semi'], 'Produced', 'Used'),
  _Cat('ফিনিশ', ['Finished'], 'Produced', 'Sold', salesOnly: true),
];

class _Data {
  _Data(this.rows, this.lines, this.liters);
  final List<StockRow> rows;
  final Map<int, MonthlyStockLine> lines;
  final Map<int, double> liters; // finished itemId -> produced litres (info only)
}

class StockSummaryScreen extends ConsumerStatefulWidget {
  const StockSummaryScreen({super.key});

  @override
  ConsumerState<StockSummaryScreen> createState() => _StockSummaryScreenState();
}

class _StockSummaryScreenState extends ConsumerState<StockSummaryScreen> {
  late DateTimeRange _range;
  late Future<_Data> _future;
  bool _onlyLow = false;
  bool _onlyExpiry = false;

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    _range = DateTimeRange(start: DateTime(n.year, n.month, 1), end: DateTime(n.year, n.month, n.day));
    _future = _load();
  }

  Future<_Data> _load() async {
    final s = ref.read(stockServiceProvider);
    final rows = await s.getStockSummary();
    final lines = await s.stockStatement(
      from: DateTime(_range.start.year, _range.start.month, _range.start.day),
      to: DateTime(_range.end.year, _range.end.month, _range.end.day + 1),
    );
    // Produced litres (information only - never used in stock maths).
    final db = ref.read(databaseProvider);
    final from = DateTime(_range.start.year, _range.start.month, _range.start.day);
    final to = DateTime(_range.end.year, _range.end.month, _range.end.day + 1);
    final orders = await (db.select(db.productionOrders)..where((o) => o.status.equals('Completed'))).get();
    final recs = await db.select(db.recipes).get();
    final fgOf = {for (final r in recs) r.id: r.finishedItemId};
    final liters = <int, double>{};
    for (final o in orders) {
      final e = o.endDate;
      if (e == null || e.isBefore(from) || !e.isBefore(to)) continue;
      final fg = fgOf[o.recipeId];
      if (fg == null) continue;
      liters[fg] = (liters[fg] ?? 0) + (o.actualFinishedQty ?? 0);
    }
    return _Data(rows, {for (final l in lines) l.item.id: l}, liters);
  }

  void _reload() => setState(() => _future = _load());

  void _setRange(DateTime a, DateTime b) {
    _range = DateTimeRange(start: a, end: b);
    _reload();
  }

  Future<void> _pickRange() async {
    final n = DateTime.now();
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(n.year + 1),
      initialDateRange: _range,
    );
    if (r != null) _setRange(r.start, r.end);
  }

  @override
  Widget build(BuildContext context) {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return DefaultTabController(
      length: _cats.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Stock'),
          actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reload)],
          bottom: TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              for (var i = 0; i < _cats.length; i++)
                Tab(text: tr(labelOf(ref.watch(settingsMapProvider).valueOrNull, const ['stock_raw', 'stock_pack', 'stock_mix', 'stock_fin'][i], _cats[i].title))),
            ],
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              child: Wrap(
                spacing: 6,
                runSpacing: 0,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  ActionChip(label: const Text('আজ'), onPressed: () => _setRange(today, today)),
                  ActionChip(
                      label: const Text('এই মাস'),
                      onPressed: () => _setRange(DateTime(n.year, n.month, 1), today)),
                  ActionChip(
                      label: const Text('গত মাস'),
                      onPressed: () => _setRange(DateTime(n.year, n.month - 1, 1), DateTime(n.year, n.month, 0))),
                  ActionChip(avatar: const Icon(Icons.date_range, size: 16), label: const Text('তারিখ'), onPressed: _pickRange),
                  FilterChip(
                      label: const Text('Low'),
                      selected: _onlyLow,
                      onSelected: (v) => setState(() => _onlyLow = v)),
                  FilterChip(
                      label: const Text('Expiry'),
                      selected: _onlyExpiry,
                      onSelected: (v) => setState(() => _onlyExpiry = v)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('সময়কাল: ${fmtDate(_range.start)} → ${fmtDate(_range.end)}',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
              ),
            ),
            Expanded(
              child: FutureBuilder<_Data>(
                future: _future,
                builder: (context, snap) {
                  if (snap.hasError) return Center(child: Text(friendlyError(snap.error!)));
                  if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                  final d = snap.data!;
                  return TabBarView(children: [for (final c in _cats) _tab(c, d)]);
                },
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseReceiptScreen()));
            _reload();
          },
          icon: const Icon(Icons.add_shopping_cart),
          label: const Text('Purchase'),
        ),
      ),
    );
  }

  Widget _tab(_Cat c, _Data d) {
    var rows = d.rows.where((r) => c.types.contains(r.item.itemType)).toList();
    rows = rows.where((r) => d.lines.containsKey(r.item.id) || r.stock > 0).toList();
    if (_onlyLow) rows = rows.where((r) => r.isLow).toList();
    if (_onlyExpiry) rows = rows.where((r) => r.expiredQty > 0 || r.nearExpiryQty > 0).toList();
    if (rows.isEmpty) {
      return const Center(child: Text('এই ক্যাটাগরিতে কিছু নেই'));
    }
    final totalValue = rows.fold<double>(0, (s, r) => s + r.value);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('বর্তমান স্টক মূল্য: ${fmtMoney(totalValue)}', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 90),
            itemCount: rows.length,
            itemBuilder: (context, i) => _card(c, rows[i], d.lines[rows[i].item.id], d.liters[rows[i].item.id]),
          ),
        ),
      ],
    );
  }

  Widget _cell(String label, double v, {Color? color}) {
    return Expanded(
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade700)),
          const SizedBox(height: 2),
          Text(fmtQty(v), style: TextStyle(fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  Widget _card(_Cat c, StockRow row, MonthlyStockLine? line, double? liters) {
    final item = row.item;
    final opening = line?.opening ?? 0.0;
    double inQty = 0.0;
    double outQty = 0.0;
    double other = 0.0;
    if (line != null) {
      inQty = c.purchaseOnly ? line.purchase : line.productionIn + line.purchase;
      outQty = c.salesOnly ? line.sales : line.productionIssue + line.sales;
      other = line.transferNet + line.adjustmentNet;
    }
    final closing = line?.closing ?? row.stock;
    final hasExpired = row.expiredQty > 0;
    final hasNear = row.nearExpiryQty > 0;

    return Card(
      color: hasExpired ? Colors.red.withAlpha(35) : (row.isLow ? Colors.orange.withAlpha(35) : null),
      child: ExpansionTile(
        title: Text('${item.itemCode} - ${item.itemName} (${item.baseUnit})'),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _cell('Opening', opening),
                  _cell(c.inLabel, inQty, color: Colors.green.shade700),
                  _cell(c.outLabel, outQty, color: Colors.red.shade700),
                  _cell('Closing', closing, color: Colors.indigo),
                ],
              ),
              if (c.salesOnly)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('প্রোডিউস লিটার: ${fmtQty(liters ?? 0)} L (শুধু তথ্য)',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                ),
              if (other.abs() > 0.0005)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('অন্যান্য (Transfer/Adjust): ${other > 0 ? '+' : ''}${fmtQty(other)}',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade700)),
                ),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                    'এখন আছে: ${fmtQty(row.stock)} ${item.baseUnit} • ${fmtMoney(row.value)}'
                    '${item.minStock > 0 ? ' • Min ${fmtQty(item.minStock)}' : ''}',
                    style: const TextStyle(fontSize: 12)),
              ),
            ],
          ),
        ),
        trailing: Wrap(
          spacing: 4,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            if (hasExpired) const Icon(Icons.dangerous, color: Colors.red, size: 20),
            if (!hasExpired && hasNear) Icon(Icons.timer, color: Colors.amber.shade800, size: 20),
            if (row.isLow) const Icon(Icons.warning, color: Colors.orange, size: 20),
          ],
        ),
        children: row.batches.isEmpty
            ? [const ListTile(title: Text('কোনো ব্যাচ নেই'))]
            : row.batches.map<Widget>((b) {
                final now = DateTime.now();
                final expired = b.expiryDate != null && b.expiryDate!.isBefore(now);
                final near = !expired &&
                    b.expiryDate != null &&
                    b.expiryDate!.isBefore(now.add(const Duration(days: StockService.nearExpiryDays)));
                return ListTile(
                  dense: true,
                  title: Text('Batch: ${b.batchNo}'),
                  subtitle: Text(
                    'Qty: ${fmtQty(b.currentQty)}  •  Exp: ${fmtDate(b.expiryDate)}'
                    '${expired ? '  (মেয়াদোত্তীর্ণ)' : near ? '  (শীঘ্রই শেষ)' : ''}',
                    style: TextStyle(color: expired ? Colors.red : (near ? Colors.amber.shade900 : null)),
                  ),
                  trailing: Text('Cost ${b.unitCost.toStringAsFixed(2)}'),
                  onLongPress: () => _adjust(b.id, b.batchNo, b.currentQty),
                );
              }).toList(),
      ),
    );
  }

  void _adjust(int batchId, String batchNo, double current) {
    final qty = TextEditingController(text: fmtQty(current));
    final reason = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Stock Adjustment — $batchNo'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: qty,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(label: Text('সঠিক পরিমাণ (গণনা অনুযায়ী)')),
            ),
            const SizedBox(height: 8),
            TextField(controller: reason, decoration: const InputDecoration(label: Text('কারণ * (গলে গেছে / ভেঙেছে / গণনা ভুল…)'))),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              final q = parseNum(qty.text);
              if (q == null) { showSnack(ctx, 'সংখ্যা দিন'); return; }
              final ok = await runGuarded(ctx, () => ref
                  .read(stockServiceProvider)
                  .adjustBatch(batchId: batchId, newQty: q, reason: reason.text));
              if (ok && ctx.mounted) {
                Navigator.pop(ctx);
                _reload();
              }
            },
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
  }
}
