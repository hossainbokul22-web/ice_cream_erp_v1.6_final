import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/app_database.dart';
import '../services/audit_service.dart';
import 'database_provider.dart';

/// All users (live). Empty list = the app runs open, without login.
final usersProvider = StreamProvider<List<AppUser>>((ref) {
  final db = ref.watch(databaseProvider);
  return db.select(db.appUsers).watch();
});

/// The person logged in right now.
final currentUserProvider = StateProvider<AppUser?>((ref) => null);

/// Role of the current user, or null when no login is required.
final roleProvider = Provider<String?>((ref) {
  final users = ref.watch(usersProvider).valueOrNull;
  final cur = ref.watch(currentUserProvider);
  if (users == null || !users.any((u) => u.isActive)) return null;
  return cur?.role;
});

/// Signs in again automatically when "keep me logged in" was ticked at the last login.
final autoLoginProvider = FutureProvider<void>((ref) async {
  final db = ref.watch(databaseProvider);
  final row = await (db.select(db.appSettings)..where((s) => s.settingKey.equals('remember_user'))).getSingleOrNull();
  final id = int.tryParse(row?.settingValue ?? '');
  if (id == null) return;
  final u = await (db.select(db.appUsers)..where((x) => x.id.equals(id) & x.isActive.equals(true))).getSingleOrNull();
  if (u != null) {
    Audit.user = u.userName;
    ref.read(currentUserProvider.notifier).state = u;
  }
});

void setSession(WidgetRef ref, AppUser? u) {
  Audit.user = u?.userName ?? '';
  ref.read(currentUserProvider.notifier).state = u;
}
