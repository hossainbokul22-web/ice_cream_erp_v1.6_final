import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';
import 'stock_service.dart';

/// Litres in ONE carton (pcs x ml / 1000), or null when not set on the recipe.
double? cartonLiters(Recipe r) {
  final p = r.pcsPerCarton;
  final m = r.mlPerPcs;
  if (p == null || m == null || p <= 0 || m <= 0) return null;
  return p * m / 1000;
}

class PackNeed {
  PackNeed(this.item, this.need, this.have);
  final Item item;
  final double need;
  final double have;
  bool get short => have + 0.0001 < need;
}

/// A completed production order whose finished litres can be packed into cartons.
class PackableOrder {
  PackableOrder(this.order, this.expected, this.packed);
  final ProductionOrder order;
  final double expected; // cartons expected from the produced litres
  final double packed; // cartons already packed (loose pcs as fraction)
  double get remaining => expected - packed;
}

/// Carton entry: packaging materials are deducted (FIFO) and finished
/// cartons are added to the finished stock of the chosen production batch.
class PackingService {
  PackingService(this.db);
  final AppDatabase db;

  double _r(double v) => (v * 10000).round() / 10000;

  Future<List<PackableOrder>> packableOrders(int recipeId) async {
    final recipe = await (db.select(db.recipes)..where((r) => r.id.equals(recipeId))).getSingle();
    final cl = cartonLiters(recipe);
    if (cl == null) return [];
    final orders = await (db.select(db.productionOrders)
          ..where((o) => o.recipeId.equals(recipeId) & o.status.equals('Completed'))
          ..orderBy([(o) => OrderingTerm.desc(o.id)]))
        .get();
    final out = <PackableOrder>[];
    for (final o in orders) {
      final liters = o.actualFinishedQty ?? 0;
      final runs = await (db.select(db.packingRuns)..where((r) => r.orderId.equals(o.id))).get();
      final ppc = recipe.pcsPerCarton ?? 1;
      final packed = runs.fold<double>(0, (a, r) => a + r.cartons + r.loosePcs / ppc);
      out.add(PackableOrder(o, liters / cl, packed));
    }
    return out;
  }

  Future<List<PackNeed>> preview(int recipeId, double cartons) async {
    final lines = await (db.select(db.recipePackLines)..where((l) => l.recipeId.equals(recipeId))).get();
    final out = <PackNeed>[];
    for (final l in lines) {
      final it = await (db.select(db.items)..where((i) => i.id.equals(l.itemId))).getSingle();
      final bs = await (db.select(db.batches)
            ..where((b) => b.itemId.equals(l.itemId) & b.currentQty.isBiggerThanValue(0)))
          .get();
      final have = bs.fold<double>(0, (a, b) => a + b.currentQty);
      out.add(PackNeed(it, _r(l.qtyPerCarton * cartons), have));
    }
    return out;
  }

  Future<void> pack({
    required int recipeId,
    required double cartons,
    required DateTime date,
    double loosePcs = 0,
    int? orderId,
    String shift = '',
    String? note,
  }) async {
    if (cartons <= 0) throw StateError('কার্টন সংখ্যা ০ এর বেশি হতে হবে');
    if (loosePcs < 0) throw StateError('খুচরা পিস ঋণাত্মক হতে পারে না');
    final needs = await preview(recipeId, cartons);
    if (needs.isEmpty) throw StateError('এই রেসিপিতে প্যাকেজিং তালিকা নেই');
    final shortList = needs.where((n) => n.short).toList();
    if (shortList.isNotEmpty) {
      throw StateError('প্যাকেজিং স্টক কম: ' +
          shortList.map((n) => '${n.item.itemName} (লাগবে ${n.need}, আছে ${n.have})').join(', '));
    }
    await db.transaction(() async {
      final runId = await db.into(db.packingRuns).insert(PackingRunsCompanion.insert(
            recipeId: recipeId,
            cartons: cartons,
            runDate: date,
            shift: Value(shift),
            note: Value(note),
            orderId: Value(orderId),
            loosePcs: Value(loosePcs),
          ));
      for (final n in needs) {
        var remaining = n.need;
        final bs = await (db.select(db.batches)
              ..where((b) => b.itemId.equals(n.item.id) & b.currentQty.isBiggerThanValue(0))
              ..orderBy([(b) => OrderingTerm.asc(b.id)]))
            .get();
        for (final b in bs) {
          if (remaining <= 0.00001) break;
          final take = remaining < b.currentQty ? remaining : b.currentQty;
          await (db.update(db.batches)..where((x) => x.id.equals(b.id)))
              .write(BatchesCompanion(currentQty: Value(_r(b.currentQty - take))));
          await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
                voucherId: Value(runId),
                voucherType: 'Packing',
                itemId: n.item.id,
                batchId: Value(b.id),
                warehouseId: Value(b.warehouseId),
                qtyOut: Value(_r(take)),
                unitCost: Value(b.unitCost),
                transactionDate: date,
                narration: Value('Packing: ${_r(cartons)} কার্টন'),
              ));
          remaining = _r(remaining - take);
        }
      }

      if (orderId != null) {
        await _addFinished(orderId, runId, cartons, loosePcs, date);
      }
    });
  }

  /// Adds the counted cartons to the finished batch of the production order.
  Future<void> _addFinished(int orderId, int runId, double cartons, double loosePcs, DateTime date) async {
    final order = await (db.select(db.productionOrders)..where((o) => o.id.equals(orderId))).getSingle();
    final recipe = await (db.select(db.recipes)..where((r) => r.id.equals(order.recipeId))).getSingle();
    final cl = cartonLiters(recipe);
    if (cl == null) throw StateError('রেসিপিতে "১ কার্টন = পিস × মিলি" সেট করুন');
    final rec = await (db.select(db.productionReceipts)..where((r) => r.productionOrderId.equals(orderId))).get();
    if (rec.isEmpty) throw StateError('এই অর্ডারের ফিনিশ ব্যাচ পাওয়া যায়নি');
    var batch = await (db.select(db.batches)
          ..where((b) => b.itemId.equals(recipe.finishedItemId) & b.batchNo.equals(rec.first.batchNo)))
        .getSingle();

    // One-time fix: old completions put LITRES into stock as if they were pieces.
    final prior = await (db.select(db.packingRuns)
          ..where((r) => r.orderId.equals(orderId) & r.id.isNotValue(runId)))
        .get();
    final fin = order.actualFinishedQty;
    if (prior.isEmpty && fin != null && batch.currentQty > 0 && (batch.initialQty - fin).abs() < 0.001) {
      await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
            voucherType: 'Adjustment',
            voucherId: Value(orderId),
            itemId: batch.itemId,
            batchId: Value(batch.id),
            warehouseId: Value(batch.warehouseId),
            qtyOut: Value(batch.currentQty),
            unitCost: Value(batch.unitCost),
            transactionDate: date,
            narration: const Value('সংশোধন: পুরনো লিটার-স্টক বাদ, এখন কার্টনে গোনা হবে'),
          ));
      await (db.update(db.batches)..where((b) => b.id.equals(batch.id))).write(BatchesCompanion(
        currentQty: const Value(0),
        initialQty: const Value(0),
        unitCost: Value(_r(batch.unitCost * cl)),
      ));
      batch = await (db.select(db.batches)..where((b) => b.id.equals(batch.id))).getSingle();
    }

    final total = _r(cartons + loosePcs / (recipe.pcsPerCarton ?? 1));
    await (db.update(db.batches)..where((b) => b.id.equals(batch.id))).write(BatchesCompanion(
      currentQty: Value(_r(batch.currentQty + total)),
      initialQty: Value(_r(batch.initialQty + total)),
    ));
    await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
          voucherType: 'ProductionReceipt',
          voucherId: Value(orderId),
          itemId: batch.itemId,
          batchId: Value(batch.id),
          warehouseId: Value(batch.warehouseId),
          qtyIn: Value(total),
          unitCost: Value(batch.unitCost),
          transactionDate: date,
          narration: Value('${order.orderNo} Packing: ${_r(cartons)} কার্টন'
              '${loosePcs > 0 ? ' + ${_r(loosePcs)} পিস' : ''}'),
        ));
    await StockService(db).refreshAverageCost(batch.itemId);
  }
}
