import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';

class StageDef {
  const StageDef(this.key, this.label, this.en, this.hasTemp, {this.hasPressure = false});
  final String key;
  final String label; // Bengali
  final String en; // for printing
  final bool hasTemp;
  final bool hasPressure;
}

const List<StageDef> kStages = [
  StageDef('Mixing', 'মিক্সিং', 'Mixing', false),
  StageDef('Pasteurization', 'পাস্তুরাইজেশন', 'Pasteurization', true),
  StageDef('Homogenization', 'হোমোজেনাইজেশন', 'Homogenization', true, hasPressure: true),
  StageDef('Aging', 'এজিং', 'Aging', true),
  StageDef('Freezing', 'ফ্রিজিং', 'Freezing', true),
  StageDef('Packing', 'প্যাকেজিং', 'Packing', false),
];

class StageService {
  StageService(this.db);
  final AppDatabase db;

  Stream<List<StageCheck>> watch(int orderId) =>
      (db.select(db.stageChecks)..where((c) => c.productionOrderId.equals(orderId))).watch();

  /// All stages decided, none failed, at least one passed.
  static bool isAllPass(List<StageCheck> cs) {
    final by = <String, String>{for (final c in cs) c.stage: c.result};
    if (kStages.any((s) => !by.containsKey(s.key))) return false;
    if (by.values.any((r) => r == 'Fail')) return false;
    return by.values.any((r) => r == 'Pass');
  }

  Future<void> _requireUnlocked(int orderId) async {
    final o = await (db.select(db.productionOrders)..where((x) => x.id.equals(orderId))).getSingle();
    if (o.sheetLocked) throw StateError('ধাপ-সিট লক করা আছে, আগে আনলক করুন');
  }

  Future<void> record(int orderId, String stage, String result,
      {double? temp, double? pressure, double? duration, String? note}) async {
    await db.transaction(() async {
      await _requireUnlocked(orderId);
      await (db.delete(db.stageChecks)
            ..where((c) => c.productionOrderId.equals(orderId) & c.stage.equals(stage)))
          .go();
      await db.into(db.stageChecks).insert(StageChecksCompanion.insert(
            productionOrderId: orderId,
            stage: stage,
            result: result,
            tempValue: Value(temp),
            pressureBar: Value(pressure),
            durationMin: Value(duration),
            note: Value((note == null || note.trim().isEmpty) ? null : note.trim()),
          ));
    });
  }

  /// Marks every still-undecided stage as Pass.
  Future<void> markAllPass(int orderId) async {
    await db.transaction(() async {
      await _requireUnlocked(orderId);
      final have = await (db.select(db.stageChecks)..where((c) => c.productionOrderId.equals(orderId))).get();
      final done = have.map((c) => c.stage).toSet();
      for (final s in kStages) {
        if (done.contains(s.key)) continue;
        await db.into(db.stageChecks)
            .insert(StageChecksCompanion.insert(productionOrderId: orderId, stage: s.key, result: 'Pass'));
      }
    });
  }

  Future<void> setLocked(int orderId, bool lock) async {
    if (lock) {
      final have = await (db.select(db.stageChecks)..where((c) => c.productionOrderId.equals(orderId))).get();
      final done = have.map((c) => c.stage).toSet();
      final missing = kStages.where((s) => !done.contains(s.key)).map((s) => s.label).toList();
      if (missing.isNotEmpty) throw StateError('এই ধাপ বাকি: ${missing.join(', ')}');
    }
    await (db.update(db.productionOrders)..where((o) => o.id.equals(orderId)))
        .write(ProductionOrdersCompanion(sheetLocked: Value(lock)));
  }
}
