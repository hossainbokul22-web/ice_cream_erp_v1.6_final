import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'screens/dashboard/home_screen.dart';
import 'screens/production/production_order_list_screen.dart';
import 'screens/masters/item_list_screen.dart';
import 'screens/masters/recipe_list_screen.dart';
import 'screens/masters/tank_list_screen.dart';
import 'screens/inventory/stock_summary_screen.dart';
import 'screens/accounts/voucher_list_screen.dart';
import 'screens/reports/reports_screen.dart';
import 'screens/parties/party_list_screen.dart';
import 'screens/inventory/purchase_receipt_screen.dart';
import 'screens/accounts/sale_screen.dart';
import 'screens/inventory/stock_movement_screen.dart';
import 'screens/inventory/packing_screen.dart';
import 'utils/palette.dart';
import 'screens/settings/settings_screen.dart';
import 'providers/settings_provider.dart';
import 'services/settings_service.dart' show labelOf;
import 'screens/production/quick_batch_screen.dart';
import 'providers/database_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: IceCreamERPApp()));
}

class IceCreamERPApp extends ConsumerWidget {
  const IceCreamERPApp({super.key});

  ThemeData _theme(Brightness br) {
    final pal = Pal(br == Brightness.dark);
    final scheme = ColorScheme.fromSeed(seedColor: pal.accent, brightness: br).copyWith(
      primary: pal.accent,
      onPrimary: pal.onAccent,
      surface: pal.bg,
      onSurface: pal.ink,
      secondary: pal.dark ? const Color(0xFFD9895B) : const Color(0xFF7C6CF6),
    );
    return ThemeData(
      colorScheme: scheme,
      useMaterial3: true,
      brightness: br,
      scaffoldBackgroundColor: pal.bg,
      canvasColor: pal.bg,
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: pal.bg,
        foregroundColor: pal.ink,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: pal.ink),
      ),
      cardTheme: CardThemeData(
        elevation: pal.dark ? 0 : 3,
        shadowColor: const Color(0x33A3A8BD),
        color: pal.card,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: pal.dark ? BorderSide(color: pal.border) : BorderSide.none,
        ),
      ),
      dialogTheme: DialogThemeData(backgroundColor: pal.card, surfaceTintColor: Colors.transparent),
      bottomSheetTheme: BottomSheetThemeData(backgroundColor: pal.card, surfaceTintColor: Colors.transparent),
      tabBarTheme: TabBarThemeData(
        labelColor: pal.accent,
        unselectedLabelColor: pal.muted,
        indicatorColor: pal.accent,
        dividerColor: Colors.transparent,
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: pal.accent,
        foregroundColor: pal.onAccent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: pal.accent,
          foregroundColor: pal.onAccent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: pal.cardHi,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: pal.dark ? pal.border : const Color(0x22000000)),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        isDense: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final init = ref.watch(appInitProvider);
    final mode = ref.watch(themeModeProvider);
    return init.when(
      loading: () => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: mode,
        home: const Scaffold(body: Center(child: CircularProgressIndicator())),
      ),
      error: (e, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: mode,
        home: Scaffold(
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text('ডাটাবেস চালু করা যায়নি:\n$e', textAlign: TextAlign.center),
            ),
          ),
        ),
      ),
      data: (_) => MaterialApp.router(
        title: 'Ice Cream ERP',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: mode,
        routerConfig: _router,
      ),
    );
  }
}

final GlobalKey<NavigatorState> _rootKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> _shellKey = GlobalKey<NavigatorState>();

final _router = GoRouter(
  navigatorKey: _rootKey,
  initialLocation: '/',
  routes: [
    // Five main tabs share the Galaxy bottom navigation bar.
    ShellRoute(
      navigatorKey: _shellKey,
      builder: (context, state, child) =>
          GalaxyNavShell(location: state.uri.path, child: child),
      routes: [
        GoRoute(path: '/', builder: (context, state) => const HomeScreen()),
        GoRoute(path: '/production', builder: (context, state) => const ProductionOrderListScreen()),
        GoRoute(path: '/stock', builder: (context, state) => const StockSummaryScreen()),
        GoRoute(path: '/vouchers', builder: (context, state) => const VoucherListScreen()),
        GoRoute(path: '/reports', builder: (context, state) => const ReportsScreen()),
      ],
    ),
    // Master screens open full screen (opened from Home tiles).
    GoRoute(path: '/items', parentNavigatorKey: _rootKey, builder: (context, state) => const ItemListScreen()),
    GoRoute(path: '/recipes', parentNavigatorKey: _rootKey, builder: (context, state) => const RecipeListScreen()),
    GoRoute(path: '/tanks', parentNavigatorKey: _rootKey, builder: (context, state) => const TankListScreen()),
    GoRoute(path: '/parties', parentNavigatorKey: _rootKey, builder: (context, state) => const PartyListScreen()),
    GoRoute(path: '/purchase', parentNavigatorKey: _rootKey, builder: (context, state) => const PurchaseReceiptScreen()),
    GoRoute(path: '/sale', parentNavigatorKey: _rootKey, builder: (context, state) => const SaleScreen()),
    GoRoute(path: '/settings', parentNavigatorKey: _rootKey, builder: (context, state) => const SettingsScreen()),
    GoRoute(path: '/quick-batch', parentNavigatorKey: _rootKey, builder: (context, state) => const QuickBatchScreen(isPlan: false)),
    GoRoute(path: '/quick-plan', parentNavigatorKey: _rootKey, builder: (context, state) => const QuickBatchScreen(isPlan: true)),
    GoRoute(path: '/packing', parentNavigatorKey: _rootKey, builder: (context, state) => const PackingScreen()),
    GoRoute(path: '/movement', parentNavigatorKey: _rootKey, builder: (context, state) => const StockMovementScreen()),
  ],
);

// ============================ GALAXY NAVIGATION ============================

class _NavTab {
  const _NavTab(this.path, this.label, this.icon);
  final String path;
  final String label;
  final IconData icon;
}

class GalaxyNavShell extends ConsumerWidget {
  const GalaxyNavShell({super.key, required this.location, required this.child});

  final String location;
  final Widget child;

  static const List<_NavTab> _tabs = [
    _NavTab('/', 'Home', Icons.home_rounded),
    _NavTab('/production', 'Production', Icons.precision_manufacturing),
    _NavTab('/stock', 'Stock', Icons.inventory_2),
    _NavTab('/vouchers', 'Vouchers', Icons.receipt_long),
    _NavTab('/reports', 'Reports', Icons.assessment),
  ];

  int get _index {
    for (var i = _tabs.length - 1; i > 0; i--) {
      if (location.startsWith(_tabs[i].path)) return i;
    }
    return 0;
  }

  static const List<String> _keys = ['nav_home', 'nav_production', 'nav_stock', 'nav_vouchers', 'nav_reports'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = _index;
    final sm = ref.watch(settingsMapProvider).valueOrNull;
    final tabs = [
      for (var i = 0; i < _tabs.length; i++) _NavTab(_tabs[i].path, labelOf(sm, _keys[i], _tabs[i].label), _tabs[i].icon),
    ];
    return PopScope(
      canPop: index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) context.go('/');
      },
      child: Scaffold(
        body: child,
        bottomNavigationBar: _GalaxyBar(
          index: index,
          tabs: tabs,
          onTap: (i) => context.go(_tabs[i].path),
        ),
      ),
    );
  }
}

class _GalaxyBar extends StatelessWidget {
  const _GalaxyBar({
    required this.index,
    required this.tabs,
    required this.onTap,
  });

  final int index;
  final List<_NavTab> tabs;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final pal = Pal.of(context);
    final bottomInset = MediaQuery.of(context).padding.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(8, 8, 8, 8 + bottomInset),
      decoration: BoxDecoration(
        color: pal.dark ? const Color(0xFF1D150D) : const Color(0xFFEDEFF6),
        border: Border(top: BorderSide(color: pal.dark ? pal.border : const Color(0x14000000))),
        boxShadow: pal.dark
            ? null
            : const [BoxShadow(color: Color(0x33A3A8BD), blurRadius: 16, offset: Offset(0, -4))],
      ),
      child: Row(
        children: [
          for (var i = 0; i < tabs.length; i++) Expanded(child: _item(context, pal, i)),
        ],
      ),
    );
  }

  Widget _item(BuildContext context, Pal pal, int i) {
    final selected = i == index;
    final idle = pal.muted;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => onTap(i),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: selected ? (pal.dark ? const Color(0xFFF1E6D0) : pal.accent) : Colors.transparent,
              boxShadow: selected
                  ? [BoxShadow(color: pal.accent.withAlpha(pal.dark ? 60 : 90), blurRadius: 14)]
                  : const [],
            ),
            child: Icon(
              tabs[i].icon,
              size: 22,
              color: selected ? (pal.dark ? const Color(0xFF2A1D0C) : Colors.white) : idle,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            tabs[i].label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? pal.ink : idle,
            ),
          ),
        ],
      ),
    );
  }
}

// Small fixed "stars" scattered behind the tabs.
class _StarsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rnd = math.Random(7);
    final paint = Paint();
    for (var i = 0; i < 28; i++) {
      final dx = rnd.nextDouble() * size.width;
      final dy = rnd.nextDouble() * size.height;
      final r = 0.4 + rnd.nextDouble() * 0.9;
      paint.color = Colors.white.withAlpha(60 + rnd.nextInt(140));
      canvas.drawCircle(Offset(dx, dy), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
