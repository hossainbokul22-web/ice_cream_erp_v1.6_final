import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../utils/ui.dart';

class _Entry {
  _Entry(this.date, this.type, this.itemName, this.unit, this.qty, this.note);
  final DateTime date;
  final String type;
  final String itemName;
  final String unit;
  final double qty;
  final String note;
}

/// Daily Reject / Wastage / Return entry (stock movement on a batch).
class StockMovementScreen extends ConsumerStatefulWidget {
  const StockMovementScreen({super.key});

  @override
  ConsumerState<StockMovementScreen> createState() => _StockMovementScreenState();
}

class _StockMovementScreenState extends ConsumerState<StockMovementScreen> {
  static const _types = ['Reject', 'Wastage', 'Return'];

  List<Item> _items = [];
  List<Batch> _batches = [];
  List<_Entry> _recent = [];
  String _type = 'Wastage';
  int? _itemId;
  int? _batchId;
  DateTime _date = DateTime.now();
  bool _loading = true;
  bool _saving = false;
  final _qty = TextEditingController();
  final _reason = TextEditingController();

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _qty.dispose();
    _reason.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    final db = ref.read(databaseProvider);
    final items = await (db.select(db.items)
          ..where((i) => i.isActive.equals(true))
          ..orderBy([(i) => OrderingTerm.asc(i.itemType), (i) => OrderingTerm.asc(i.itemCode)]))
        .get();
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
    await _loadRecent();
  }

  Future<void> _loadBatches() async {
    final id = _itemId;
    if (id == null) {
      setState(() => _batches = []);
      return;
    }
    final db = ref.read(databaseProvider);
    final bs = await (db.select(db.batches)
          ..where((b) => b.itemId.equals(id))
          ..orderBy([(b) => OrderingTerm.asc(b.expiryDate), (b) => OrderingTerm.asc(b.id)]))
        .get();
    if (!mounted) return;
    setState(() {
      _batches = bs;
      _batchId = null;
    });
  }

  Future<void> _loadRecent() async {
    final db = ref.read(databaseProvider);
    final rows = await (db.select(db.stockLedger)
          ..where((l) => l.voucherType.isIn(_types))
          ..orderBy([(l) => OrderingTerm.desc(l.transactionDate), (l) => OrderingTerm.desc(l.id)])
          ..limit(40))
        .get();
    final byId = {for (final i in _items) i.id: i};
    final list = <_Entry>[];
    for (final l in rows) {
      final it = byId[l.itemId];
      list.add(_Entry(
        l.transactionDate,
        l.voucherType,
        it == null ? '#${l.itemId}' : '${it.itemCode} - ${it.itemName}',
        it?.baseUnit ?? '',
        l.qtyOut > 0 ? l.qtyOut : l.qtyIn,
        l.narration ?? '',
      ));
    }
    if (!mounted) return;
    setState(() => _recent = list);
  }

  Future<void> _save() async {
    final batchId = _batchId;
    final qty = parseNum(_qty.text);
    if (batchId == null) {
      showSnack(context, 'আইটেম ও Batch সিলেক্ট করুন');
      return;
    }
    if (qty == null || qty <= 0) {
      showSnack(context, 'পরিমাণ ০ এর বেশি দিন');
      return;
    }
    if (_reason.text.trim().isEmpty) {
      showSnack(context, 'কারণ লিখুন');
      return;
    }
    setState(() => _saving = true);
    final stock = ref.read(stockServiceProvider);
    final ok = await runGuarded(
      context,
      () => _type == 'Return'
          ? stock.recordReturn(batchId: batchId, qty: qty, reason: _reason.text, date: _date)
          : stock.recordStockOut(batchId: batchId, qty: qty, movementType: _type, reason: _reason.text, date: _date),
      success: '$_type সংরক্ষিত',
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok) {
      _qty.clear();
      _reason.clear();
      await _loadBatches();
      await _loadRecent();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Reject / Wastage / Return')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 'Reject', label: Text('Reject')),
              ButtonSegment(value: 'Wastage', label: Text('Wastage')),
              ButtonSegment(value: 'Return', label: Text('Return')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() => _type = s.first),
          ),
          const SizedBox(height: 4),
          Text(
            _type == 'Return' ? 'Return: Batch এ স্টক ফেরত যোগ হবে' : '$_type: Batch থেকে স্টক কমবে',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            isExpanded: true,
            value: _itemId,
            decoration: const InputDecoration(labelText: 'Item *'),
            items: _items
                .map((i) => DropdownMenuItem<int>(
                    value: i.id,
                    child: Text('${i.itemType} • ${i.itemCode} - ${i.itemName}', overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) {
              setState(() => _itemId = v);
              _loadBatches();
            },
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            isExpanded: true,
            value: _batchId,
            decoration: const InputDecoration(labelText: 'Batch *'),
            items: _batches
                .map((b) => DropdownMenuItem<int>(
                    value: b.id,
                    child: Text('${b.batchNo} • আছে ${fmtQty(b.currentQty)} • Exp ${fmtDate(b.expiryDate)}',
                        overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) => setState(() => _batchId = v),
          ),
          if (_itemId != null && _batches.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text('এই আইটেমের কোনো Batch নেই।', style: TextStyle(color: Colors.red, fontSize: 12)),
            ),
          const SizedBox(height: 10),
          TextField(
            controller: _qty,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(label: Text('পরিমাণ *')),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _reason,
            decoration: const InputDecoration(label: Text('কারণ * (গলে গেছে / ভেঙেছে / মান খারাপ…)')),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            icon: const Icon(Icons.event),
            label: Text('তারিখ: ${fmtDate(_date)}'),
            onPressed: () async {
              final d = await pickDate(context, _date, last: DateTime.now());
              if (d != null) setState(() => _date = d);
            },
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: const Icon(Icons.check),
            label: Text('$_type সংরক্ষণ'),
          ),
          const SizedBox(height: 20),
          const Text('সাম্প্রতিক এন্ট্রি', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          if (_recent.isEmpty) const Text('এখনও কোনো এন্ট্রি নেই।'),
          for (final e in _recent)
            Card(
              child: ListTile(
                dense: true,
                leading: Icon(
                  e.type == 'Return' ? Icons.undo : (e.type == 'Reject' ? Icons.block : Icons.delete_outline),
                  color: e.type == 'Return' ? Colors.green.shade700 : Colors.red.shade700,
                ),
                title: Text(e.itemName),
                subtitle: Text('${fmtDate(e.date)} • ${e.type}\n${e.note}'),
                isThreeLine: true,
                trailing: Text('${e.type == 'Return' ? '+' : '-'}${fmtQty(e.qty)} ${e.unit}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
        ],
      ),
    );
  }
}
