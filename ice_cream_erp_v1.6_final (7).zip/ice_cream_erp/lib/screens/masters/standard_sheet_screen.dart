import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/plant_service.dart';
import '../../utils/ui.dart';

/// Standard process sheet: temperature / pressure / time for each step.
/// "সব রেসিপির ডিফল্ট" applies to every recipe that has no own sheet.
class StandardSheetScreen extends ConsumerStatefulWidget {
  const StandardSheetScreen({super.key});

  @override
  ConsumerState<StandardSheetScreen> createState() => _StandardSheetScreenState();
}

class _StandardSheetScreenState extends ConsumerState<StandardSheetScreen> {
  List<Recipe> _recipes = [];
  int? _scope; // null = default for all recipes
  bool _editing = false;
  bool _inherited = false;
  bool _loading = true;

  // per stage: tempMin, tempMax, pressMin, pressMax, minutes, note
  final Map<String, List<TextEditingController>> _c = {
    for (final s in kStdStages) s.key: List.generate(6, (_) => TextEditingController()),
  };

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    for (final l in _c.values) {
      for (final c in l) {
        c.dispose();
      }
    }
    super.dispose();
  }

  String _f(double? v) => v == null ? '' : fmtQty(v);

  Future<void> _init() async {
    final db = ref.read(databaseProvider);
    _recipes = await (db.select(db.recipes)
          ..where((r) => r.isActive.equals(true))
          ..orderBy([(r) => OrderingTerm.asc(r.recipeCode)]))
        .get();
    await _load();
  }

  Future<void> _load() async {
    final svc = ref.read(plantServiceProvider);
    var rows = await svc.standardsFor(_scope);
    var inherited = false;
    if (_scope != null && rows.isEmpty) {
      rows = await svc.standardsFor(null);
      inherited = true;
    }
    for (final s in kStdStages) {
      StageStandard? r;
      for (final x in rows) {
        if (x.stage == s.key) r = x;
      }
      final c = _c[s.key]!;
      c[0].text = _f(r?.tempMin);
      c[1].text = _f(r?.tempMax);
      c[2].text = _f(r?.pressureMin);
      c[3].text = _f(r?.pressureMax);
      c[4].text = _f(r?.durationMin);
      c[5].text = r?.note ?? '';
    }
    if (!mounted) return;
    setState(() {
      _inherited = inherited;
      _editing = rows.isEmpty;
      _loading = false;
    });
  }

  Future<void> _save() async {
    final svc = ref.read(plantServiceProvider);
    final ok = await runGuarded(context, () async {
      for (final s in kStdStages) {
        final c = _c[s.key]!;
        await svc.saveStandard(
          recipeId: _scope,
          stage: s.key,
          tempMin: s.temp ? parseNum(c[0].text) : null,
          tempMax: s.temp ? parseNum(c[1].text) : null,
          pressureMin: s.pressure ? parseNum(c[2].text) : null,
          pressureMax: s.pressure ? parseNum(c[3].text) : null,
          durationMin: parseNum(c[4].text),
          note: c[5].text,
        );
      }
    }, success: 'স্ট্যান্ডার্ড সিট সেভ হয়েছে');
    if (ok) await _load();
  }

  Future<void> _resetToDefault() async {
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ডিফল্টে ফিরবেন?'),
        content: const Text('এই রেসিপির নিজস্ব সিট মুছে যাবে, সব রেসিপির ডিফল্ট সিট ব্যবহার হবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ')),
        ],
      ),
    );
    if (sure != true) return;
    final svc = ref.read(plantServiceProvider);
    final ok = await runGuarded(context, () async {
      for (final s in kStdStages) {
        await svc.clearStandard(_scope, s.key);
      }
    }, success: 'ডিফল্টে ফেরা হয়েছে');
    if (ok) await _load();
  }

  Widget _num(TextEditingController c, String label, String unit) {
    return SizedBox(
      width: 112,
      child: TextField(
        controller: c,
        enabled: _editing,
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        decoration: InputDecoration(labelText: label, suffixText: unit, isDense: true),
      ),
    );
  }

  Widget _stageCard(StdStage s) {
    final c = _c[s.key]!;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(s.bn, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (s.temp) _num(c[0], 'তাপ সর্বনিম্ন', '°C'),
              if (s.temp) _num(c[1], 'তাপ সর্বোচ্চ', '°C'),
              if (s.pressure) _num(c[2], 'প্রেশার সর্বনিম্ন', 'bar'),
              if (s.pressure) _num(c[3], 'প্রেশার সর্বোচ্চ', 'bar'),
              _num(c[4], 'সময়', 'মিনিট'),
            ]),
            const SizedBox(height: 8),
            TextField(
              controller: c[5],
              enabled: _editing,
              decoration: const InputDecoration(label: Text('নোট (ঐচ্ছিক)'), isDense: true),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('স্ট্যান্ডার্ড সিট')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 40),
              children: [
                DropdownButtonFormField<int?>(
                  value: _scope,
                  isExpanded: true,
                  decoration: const InputDecoration(label: Text('কোন সিট?')),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('সব রেসিপির ডিফল্ট')),
                    ..._recipes.map((r) => DropdownMenuItem<int?>(
                        value: r.id, child: Text('${r.recipeCode} • ${r.recipeName}', overflow: TextOverflow.ellipsis))),
                  ],
                  onChanged: (v) async {
                    setState(() {
                      _scope = v;
                      _loading = true;
                    });
                    await _load();
                  },
                ),
                const SizedBox(height: 6),
                Text(
                  _scope == null
                      ? 'যে রেসিপির নিজস্ব সিট নেই, সেগুলো এই ডিফল্ট সিট ব্যবহার করবে।'
                      : (_inherited
                          ? 'এই রেসিপির নিজস্ব সিট নেই — নিচে ডিফল্ট সিটের মান দেখাচ্ছে। এডিট করে সেভ করলে এই রেসিপির নিজস্ব সিট হবে।'
                          : 'এই রেসিপির নিজস্ব সিট (ডিফল্টের চেয়ে অগ্রাধিকার পায়)।'),
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 10),
                for (final s in kStdStages) _stageCard(s),
                if (_editing)
                  Row(children: [
                    Expanded(
                      child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('সেভ')),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(onPressed: _load, child: const Text('বাতিল')),
                  ])
                else
                  FilledButton.tonalIcon(
                    onPressed: () => setState(() => _editing = true),
                    icon: const Icon(Icons.edit),
                    label: const Text('এডিট'),
                  ),
                if (_scope != null && !_inherited && !_editing)
                  TextButton(onPressed: _resetToDefault, child: const Text('এই রেসিপির সিট মুছে ডিফল্টে ফিরুন')),
              ],
            ),
    );
  }
}
