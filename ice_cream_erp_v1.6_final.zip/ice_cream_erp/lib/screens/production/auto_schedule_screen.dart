import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/audit_service.dart';
import '../../services/scheduler_service.dart';
import '../../utils/ui.dart';

String _hm(DateTime? d) {
  if (d == null) return '—';
  String p(int v) => v.toString().padLeft(2, '0');
  return '${p(d.hour)}:${p(d.minute)}';
}

/// Suggests which mixing tank, aging tank and freezer each batch should use and when,
/// based on the aging time, tank / freezer capacity and flavor changeovers.
class AutoScheduleScreen extends ConsumerStatefulWidget {
  const AutoScheduleScreen({super.key});

  @override
  ConsumerState<AutoScheduleScreen> createState() => _AutoScheduleScreenState();
}

class _AutoScheduleScreenState extends ConsumerState<AutoScheduleScreen> {
  List<Recipe> _recipes = [];
  List<Tank> _mix = [];
  List<Tank> _age = [];
  List<Freezer> _frz = [];
  bool _loaded = false;
  bool _saving = false;

  DateTime _day = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _time = const TimeOfDay(hour: 8, minute: 0);
  final _changeover = TextEditingController(text: '15');
  final _batches = TextEditingController(text: '1');
  int? _recipeId;
  final List<SchedRequest> _reqs = [];
  List<SchedRow>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _changeover.dispose();
    _batches.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    final rec = await (db.select(db.recipes)
          ..where((r) => r.isActive.equals(true) & r.approvalStatus.equals('Approved'))
          ..orderBy([(r) => OrderingTerm.asc(r.recipeName)]))
        .get();
    final tanks = await (db.select(db.tanks)..orderBy([(t) => OrderingTerm.asc(t.tankCode)])).get();
    final fz = await (db.select(db.freezers)
          ..where((f) => f.isActive.equals(true))
          ..orderBy([(f) => OrderingTerm.asc(f.freezerCode)]))
        .get();
    if (!mounted) return;
    setState(() {
      _recipes = rec;
      _mix = tanks.where((t) => t.tankType == 'Mixing').toList();
      _age = tanks.where((t) => t.tankType == 'Aging').toList();
      _frz = fz;
      _recipeId = rec.isEmpty ? null : rec.first.id;
      _loaded = true;
    });
  }

  DateTime get _start => DateTime(_day.year, _day.month, _day.day, _time.hour, _time.minute);

  void _addReq() {
    final n = int.tryParse(_batches.text.trim());
    if (_recipeId == null || n == null || n <= 0) {
      showSnack(context, 'Choose a recipe and the number of batches');
      return;
    }
    final r = _recipes.firstWhere((x) => x.id == _recipeId);
    setState(() {
      final ex = _reqs.where((q) => q.recipe.id == r.id).toList();
      if (ex.isNotEmpty) {
        ex.first.batches += n;
      } else {
        _reqs.add(SchedRequest(r, n));
      }
      _rows = null;
    });
  }

  void _plan() {
    if (_reqs.isEmpty) {
      showSnack(context, 'Add at least one recipe first');
      return;
    }
    if (_mix.isEmpty || _age.isEmpty || _frz.isEmpty) {
      showSnack(context, 'Add mixing tanks, aging tanks and freezers first (Home → Tanks / Freezers)');
      return;
    }
    final co = int.tryParse(_changeover.text.trim()) ?? 15;
    setState(() {
      _rows = SchedulerService.plan(
        start: _start,
        requests: _reqs,
        mixTanks: _mix,
        ageTanks: _age,
        freezers: _frz,
        changeoverMin: co < 0 ? 0 : co,
      );
    });
  }

  Future<void> _create() async {
    final rows = _rows;
    if (rows == null) return;
    final good = rows.where((r) => r.ok).toList();
    if (good.isEmpty) {
      showSnack(context, 'Nothing to create');
      return;
    }
    if (!await confirm(context, 'Create ${good.length} planned batches?',
        'They are saved as planned orders with the suggested tanks. Stock is not deducted until the batch is started.')) {
      return;
    }
    final svc = ref.read(productionServiceProvider);
    final db = ref.read(databaseProvider);
    setState(() => _saving = true);
    var made = 0;
    final errors = <String>[];
    for (final r in good) {
      try {
        await svc.createProductionOrder(
          recipeId: r.recipe.id,
          targetMixQty: r.liters,
          mixingTankId: r.mixTank?.id,
          agingTankId: r.ageTank?.id,
          plannedDate: r.mixStart,
          sourceType: 'AutoPlan',
          notes: 'Auto plan: start ${_hm(r.mixStart)}, freezer ${r.freezer?.freezerCode ?? '-'} at ${_hm(r.freezeStart)}',
        );
        made++;
      } catch (e) {
        errors.add('${r.recipe.recipeName}: ${friendlyError(e)}');
      }
    }
    await Audit.write(db, 'Auto schedule', '$made planned batches created for ${fmtDate(_start)}');
    if (!mounted) return;
    setState(() => _saving = false);
    if (errors.isEmpty) {
      showSnack(context, '$made planned batches created');
      Navigator.pop(context);
    } else {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('$made created, ${errors.length} failed'),
          content: SingleChildScrollView(child: Text(errors.join('\n\n'))),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final rows = _rows;
    DateTime? lastFinish;
    if (rows != null) {
      for (final r in rows) {
        if (r.finish != null && (lastFinish == null || r.finish!.isAfter(lastFinish))) lastFinish = r.finish;
      }
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Auto Schedule')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('Resources: ${_mix.length} mixing tanks • ${_age.length} aging tanks • ${_frz.length} freezers',
                    style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.event),
                      label: Text('Day: ${fmtDate(_day)}'),
                      onPressed: () async {
                        final d = await pickDate(context, _day, first: DateTime.now().subtract(const Duration(days: 1)));
                        if (d != null) setState(() {
                          _day = d;
                          _rows = null;
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.schedule),
                      label: Text('Start: ${_time.format(context)}'),
                      onPressed: () async {
                        final t = await showTimePicker(context: context, initialTime: _time);
                        if (t != null) setState(() {
                          _time = t;
                          _rows = null;
                        });
                      },
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                TextField(
                  controller: _changeover,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Flavor changeover / cleaning gap (minutes)',
                      helperText: 'Added when a different flavor uses the same tank or freezer'),
                ),
              ]),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('What do you want to make?', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    flex: 3,
                    child: DropdownButtonFormField<int>(
                      isExpanded: true,
                      value: _recipeId,
                      decoration: const InputDecoration(labelText: 'Recipe'),
                      items: [for (final r in _recipes) DropdownMenuItem(value: r.id, child: Text(r.recipeName, overflow: TextOverflow.ellipsis))],
                      onChanged: (v) => setState(() => _recipeId = v),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: TextField(
                      controller: _batches,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Batches'),
                    ),
                  ),
                  IconButton(onPressed: _addReq, icon: const Icon(Icons.add_circle, size: 30)),
                ]),
                for (final q in _reqs)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text(q.recipe.recipeName),
                    subtitle: Text('${q.batches} batch × ${fmtQty(q.recipe.baseQty)} L'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => setState(() {
                        _reqs.remove(q);
                        _rows = null;
                      }),
                    ),
                  ),
                const SizedBox(height: 8),
                FilledButton.icon(onPressed: _plan, icon: const Icon(Icons.auto_awesome), label: const Text('Make schedule')),
              ]),
            ),
          ),
          if (rows != null) ...[
            const SizedBox(height: 4),
            Text(
                '${rows.where((r) => r.ok).length} of ${rows.length} batches scheduled'
                '${lastFinish == null ? '' : ' • all finished by ${fmtDateTime(lastFinish)}'}',
                style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            for (var i = 0; i < rows.length; i++) _rowCard(i, rows[i]),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _saving ? null : _create,
              icon: const Icon(Icons.playlist_add_check),
              label: const Text('Create these as planned batches'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _rowCard(int i, SchedRow r) {
    return Card(
      color: r.problem != null ? const Color(0xFFD94B4B).withAlpha(35) : null,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('#${i + 1}  ${r.recipe.recipeName} • ${fmtQty(r.liters)} L', style: const TextStyle(fontWeight: FontWeight.w800)),
          if (r.mixStart != null) ...[
            const SizedBox(height: 4),
            Text('Mixing ${r.mixTank?.tankCode ?? '-'} • ${_hm(r.mixStart)} → ${_hm(r.agingStart)}', style: const TextStyle(fontSize: 12.5)),
            Text('Aging ${r.ageTank?.tankCode ?? '-'} • ${_hm(r.agingStart)} → ${_hm(r.agingEnd)}', style: const TextStyle(fontSize: 12.5)),
            if (r.freezer != null)
              Text('Freezer ${r.freezer!.freezerCode} • ${_hm(r.freezeStart)} → ${_hm(r.freezeEnd)}', style: const TextStyle(fontSize: 12.5)),
            if (r.finish != null) Text('Hardening + packing done by ${fmtDateTime(r.finish)}', style: const TextStyle(fontSize: 12.5)),
          ],
          if (r.problem != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('⚠ ${r.problem}', style: const TextStyle(color: Color(0xFFD94B4B), fontWeight: FontWeight.w700)),
            ),
        ]),
      ),
    );
  }
}
