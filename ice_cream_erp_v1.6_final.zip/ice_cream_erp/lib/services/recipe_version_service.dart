import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';
import 'audit_service.dart';

/// Keeps a readable text snapshot of a recipe every time its content changes.
class RecipeVersionService {
  static String _f(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  static Future<String> _build(AppDatabase db, Recipe r) async {
    final lines = await (db.select(db.recipeLines)
          ..where((l) => l.recipeId.equals(r.id))
          ..orderBy([(l) => OrderingTerm.asc(l.sequence), (l) => OrderingTerm.asc(l.id)]))
        .get();
    final packs = await (db.select(db.recipePackLines)..where((l) => l.recipeId.equals(r.id))).get();
    final items = await db.select(db.items).get();
    final byId = {for (final i in items) i.id: i};
    String nm(int id) => byId[id] == null ? 'Item #$id' : '${byId[id]!.itemCode} ${byId[id]!.itemName}';
    final b = StringBuffer();
    b.writeln('Recipe: ${r.recipeCode} ${r.recipeName}');
    b.writeln('Batch: ${_f(r.baseQty)} L');
    b.writeln('Density: ${_f(r.density)} kg/L');
    b.writeln('Target overrun: ${_f(r.targetOverrun)}%');
    b.writeln('Expected yield: ${_f(r.expectedYield)}%');
    b.writeln('Aging: ${_f(r.agingHours)} h');
    b.writeln('Carton: ${r.pcsPerCarton == null ? '-' : _f(r.pcsPerCarton!)} pcs x ${r.mlPerPcs == null ? '-' : _f(r.mlPerPcs!)} ml');
    b.writeln('Stage minutes: ${r.stageMins ?? '-'}');
    b.writeln('-- Ingredients');
    for (final l in lines) {
      b.writeln('${nm(l.itemId)}: ${_f(l.qty)} ${l.unit} (wastage ${_f(l.wastagePercent)}%)');
    }
    b.writeln('-- Packaging per carton');
    for (final p in packs) {
      b.writeln('${nm(p.itemId)}: ${_f(p.qtyPerCarton)}');
    }
    return b.toString().trimRight();
  }

  /// Saves a new version only if the content differs from the latest one.
  static Future<void> snapshot(AppDatabase db, int recipeId, String reason) async {
    try {
      final r = await (db.select(db.recipes)..where((x) => x.id.equals(recipeId))).getSingleOrNull();
      if (r == null) return;
      final text = await _build(db, r);
      final last = await (db.select(db.recipeVersions)
            ..where((v) => v.recipeId.equals(recipeId))
            ..orderBy([(v) => OrderingTerm.desc(v.versionNo)])
            ..limit(1))
          .getSingleOrNull();
      if (last != null && last.snapshot == text) return;
      final n = (last?.versionNo ?? 0) + 1;
      await db.into(db.recipeVersions).insert(RecipeVersionsCompanion.insert(
            recipeId: recipeId,
            versionNo: n,
            userName: Value(Audit.user),
            reason: Value(reason),
            snapshot: text,
          ));
      await (db.update(db.recipes)..where((x) => x.id.equals(recipeId))).write(RecipesCompanion(version: Value(n)));
      await Audit.write(db, 'Recipe version', '${r.recipeCode} v$n — $reason');
    } catch (_) {}
  }
}
