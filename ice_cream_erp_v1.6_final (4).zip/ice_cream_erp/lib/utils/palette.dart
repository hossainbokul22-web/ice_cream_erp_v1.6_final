import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Light = soft neumorphic (grey-lavender, indigo accent).
/// Dark  = warm bronze glass (espresso brown, gold accent).
class Pal {
  const Pal(this.dark);
  final bool dark;
  static Pal of(BuildContext c) => Pal(Theme.of(c).brightness == Brightness.dark);

  Color get bg => dark ? const Color(0xFF16100A) : const Color(0xFFE8EAF1);
  Color get card => dark ? const Color(0xFF2A2016) : const Color(0xFFEDEFF6);
  Color get cardHi => dark ? const Color(0xFF362A1C) : const Color(0xFFF4F5FA);
  Color get ink => dark ? const Color(0xFFF3E9D8) : const Color(0xFF262A3D);
  Color get muted => dark ? const Color(0xFFA89880) : const Color(0xFF7C8096);
  Color get accent => dark ? const Color(0xFFE9B96A) : const Color(0xFF5B4DF0);
  Color get onAccent => dark ? const Color(0xFF2A1D0C) : Colors.white;
  Color get border => dark ? const Color(0xFF4A3820) : const Color(0x00000000);
  Color get good => dark ? const Color(0xFF8BD39A) : const Color(0xFF3DB45A);
  Color get warn => dark ? const Color(0xFFF2B35E) : const Color(0xFFE8912D);
  Color get bad => dark ? const Color(0xFFFF8A7A) : const Color(0xFFE5484D);

  /// Neumorphic raised shadow (light) / soft glow (dark).
  List<BoxShadow> get raised => dark
      ? const [BoxShadow(color: Color(0x66000000), blurRadius: 14, offset: Offset(0, 6))]
      : const [
          BoxShadow(color: Color(0xFFFFFFFF), blurRadius: 12, offset: Offset(-5, -5)),
          BoxShadow(color: Color(0x33A3A8BD), blurRadius: 14, offset: Offset(6, 6)),
        ];

  BoxDecoration box({double r = 20, Color? color}) => BoxDecoration(
        color: color ?? card,
        borderRadius: BorderRadius.circular(r),
        border: dark ? Border.all(color: border) : null,
        boxShadow: raised,
      );
}

/// null = follow the phone's setting.
final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.system);
