import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';
import '../../providers/settings_provider.dart';
import '../../services/settings_service.dart' show labelOf;
import '../../utils/ui.dart';

const _tankTabs = [
  ['Mixing', 'মিক্সিং ট্যাংক'],
  ['Aging', 'এজিং ট্যাংক'],
  ['Storage', 'স্টোরেজ'],
];

class TankListScreen extends ConsumerWidget {
  const TankListScreen({super.key});

  Widget _list(BuildContext context, WidgetRef ref, List<Tank> all, String type) {
    final tanks = all.where((t) => t.tankType == type).toList()
      ..sort((a, b) => a.tankCode.compareTo(b.tankCode));
    if (tanks.isEmpty) {
      return const Center(child: Text('এই ধরনের ট্যাংক নেই। + চাপুন নতুন যোগ করতে।'));
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 80),
      itemCount: tanks.length,
      itemBuilder: (context, index) {
              final tank = tanks[index];
              final fillPercent = tank.capacityLiter > 0 ? (tank.currentQty / tank.capacityLiter) * 100 : 0.0;
              Color statusColor = tank.status == 'Empty' ? Colors.green : (tank.status == 'InUse' ? Colors.orange : Colors.blue);

              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('${tank.tankCode} - ${tank.tankName}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Chip(
                            label: Text(tank.status, style: const TextStyle(fontSize: 11, color: Colors.white)),
                            backgroundColor: statusColor,
                            visualDensity: VisualDensity.compact,
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text('Type: ${tank.tankType}  •  Capacity: ${tank.capacityLiter} L'),
                      Text('Current: ${tank.currentQty.toStringAsFixed(1)} L'),
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: (fillPercent / 100).clamp(0.0, 1.0).toDouble(),
                        backgroundColor: Colors.grey.withAlpha(50),
                        color: statusColor,
                        minHeight: 8,
                      ),
                      const SizedBox(height: 4),
                      Text('${fillPercent.toStringAsFixed(1)}% filled', style: const TextStyle(fontSize: 12)),
                      if (tank.status == 'Cleaning')
                        Align(
                          alignment: Alignment.centerRight,
                          child: FilledButton.tonalIcon(
                            onPressed: () => runGuarded(
                              context,
                              () => ref.read(productionServiceProvider).markTankClean(tank.id),
                              success: '${tank.tankCode} পরিষ্কার — ব্যবহারযোগ্য',
                            ),
                            icon: const Icon(Icons.cleaning_services),
                            label: const Text('পরিষ্কার সম্পন্ন (CIP)'),
                          ),
                        ),
                    ],
                  ),
                ),
              );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final sm = ref.watch(settingsMapProvider).valueOrNull;

    return DefaultTabController(
      length: _tankTabs.length,
      child: Builder(builder: (context) {
        void add() => _showTankForm(context, ref, type: _tankTabs[DefaultTabController.of(context).index][0]);
        return Scaffold(
          appBar: AppBar(
            title: const Text('Tanks'),
            bottom: TabBar(tabs: [for (final t in _tankTabs) Tab(text: tr(labelOf(sm, 'tank_${t[0].toLowerCase()}', t[1])))]),
          ),
          body: StreamBuilder<List<Tank>>(
            stream: db.select(db.tanks).watch(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final tanks = snapshot.data!;
              return TabBarView(
                children: [for (final t in _tankTabs) _list(context, ref, tanks, t[0])],
              );
            },
          ),
          floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.add)),
        );
      }),
    );
  }

  void _showTankForm(BuildContext context, WidgetRef ref, {String type = 'Mixing'}) {
    final codeCtrl = TextEditingController();
    final nameCtrl = TextEditingController();
    final capacityCtrl = TextEditingController(text: '1000');
    String tankType = type;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: StatefulBuilder(
            builder: (context, setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('নতুন ট্যাংক', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextField(controller: codeCtrl, decoration: const InputDecoration(labelText: 'Tank Code')),
                  const SizedBox(height: 8),
                  TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tank Name')),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: tankType,
                    decoration: const InputDecoration(labelText: 'Type'),
                    items: ['Mixing', 'Aging', 'Storage'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => tankType = v!),
                  ),
                  const SizedBox(height: 8),
                  TextField(controller: capacityCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Capacity (Liter)')),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () async {
                      final code = codeCtrl.text.trim();
                      final name = nameCtrl.text.trim();
                      final cap = parseNum(capacityCtrl.text);
                      if (code.isEmpty || name.isEmpty) {
                        showSnack(ctx, 'Code ও Name দিন');
                        return;
                      }
                      if (cap == null || cap <= 0) {
                        showSnack(ctx, 'Capacity ০ এর বেশি হতে হবে');
                        return;
                      }
                      final db = ref.read(databaseProvider);
                      final ok = await runGuarded(ctx, () async {
                        await db.into(db.tanks).insert(TanksCompanion.insert(
                              tankCode: code,
                              tankName: name,
                              tankType: tankType,
                              capacityLiter: cap,
                            ));
                      });
                      if (ok && ctx.mounted) Navigator.pop(ctx);
                    },
                    child: const Text('সেভ করুন'),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}
