import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/stage_service.dart';
import '../../utils/ui.dart';
import 'process_painters.dart';

class _Data {
  _Data({
    required this.orders,
    required this.recipes,
    required this.checks,
    required this.tanks,
    required this.cartons,
    required this.kBatches,
    required this.kRunning,
    required this.kDone,
    required this.kAllPass,
  });
  final List<ProductionOrder> orders;
  final Map<int, Recipe> recipes;
  final Map<String, StageCheck> checks; // selected order, by stage key
  final List<Tank> tanks;
  final double cartons;
  final int kBatches, kRunning, kDone, kAllPass;
}

const _stageColors = <String, Color>{
  'Mixing': Color(0xFF38E1FF),
  'Pasteurization': Color(0xFFFF8A3D),
  'Homogenization': Color(0xFFB28CFF),
  'Aging': Color(0xFF4DA3FF),
  'Freezing': Color(0xFF7FEFFF),
  'Packing': Color(0xFF3DDC84),
};

/// Control-room dashboard: live process diagram of the selected batch.
class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _anim;
  final List<StreamSubscription<dynamic>> _subs = [];
  Timer? _debounce;
  _Data? _d;
  int? _sel;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat();
    final db = ref.read(databaseProvider);
    _subs.add(db.select(db.productionOrders).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.stageChecks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.tanks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.packingRuns).watch().listen((_) => _schedule()));
  }

  @override
  void dispose() {
    _debounce?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _anim.dispose();
    super.dispose();
  }

  void _schedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 150), _load);
  }

  Future<void> _load() async {
    if (_busy || !mounted) return;
    _busy = true;
    try {
      final db = ref.read(databaseProvider);
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final end = start.add(const Duration(days: 1));
      final all = await (db.select(db.productionOrders)
            ..orderBy([(o) => OrderingTerm.desc(o.id)])
            ..limit(80))
          .get();
      bool isRunning(ProductionOrder o) => o.status == 'Mixing' || o.status == 'Aging' || o.status == 'Freezing';
      bool isToday(ProductionOrder o) {
        final d = o.plannedDate ?? o.createdAt;
        return !d.isBefore(start) && d.isBefore(end);
      }

      var list = all.where((o) => o.status != 'Cancelled' && (isRunning(o) || isToday(o))).toList();
      if (list.isEmpty) list = all.where((o) => o.status != 'Cancelled').take(3).toList();

      final recs = await db.select(db.recipes).get();
      final tanks = await (db.select(db.tanks)..orderBy([(t) => OrderingTerm.asc(t.tankCode)])).get();

      int? sel = _sel;
      if (sel == null || !list.any((o) => o.id == sel)) {
        final run = list.where(isRunning).toList();
        sel = run.isNotEmpty ? run.first.id : (list.isNotEmpty ? list.first.id : null);
      }

      final ids = list.map((o) => o.id).toList();
      final allChecks = ids.isEmpty
          ? <StageCheck>[]
          : await (db.select(db.stageChecks)..where((c) => c.productionOrderId.isIn(ids))).get();
      var allPass = 0;
      for (final id in ids) {
        if (StageService.isAllPass(allChecks.where((c) => c.productionOrderId == id).toList())) allPass++;
      }

      final checks = <String, StageCheck>{
        for (final c in allChecks.where((c) => c.productionOrderId == sel)) c.stage: c,
      };
      var cartons = 0.0;
      if (sel != null) {
        final runs = await (db.select(db.packingRuns)..where((r) => r.orderId.equals(sel!))).get();
        cartons = runs.fold<double>(0, (s, r) => s + r.cartons);
      }

      if (!mounted) return;
      setState(() {
        _sel = sel;
        _d = _Data(
          orders: list,
          recipes: {for (final r in recs) r.id: r},
          checks: checks,
          tanks: tanks,
          cartons: cartons,
          kBatches: list.where(isToday).length,
          kRunning: list.where(isRunning).length,
          kDone: list.where((o) => o.status == 'Completed').length,
          kAllPass: allPass,
        );
      });
    } finally {
      _busy = false;
    }
  }

  Future<void> _refresh() async {
    try {
      await _load();
    } catch (_) {}
  }

  // ---------- helpers ----------
  static String _dur(double? m) {
    if (m == null) return '—';
    if (m >= 60) {
      final h = (m / 60).floor();
      final mm = (m - h * 60).round();
      return '$h:${mm.toString().padLeft(2, '0')} ঘ';
    }
    return '${fmtQty(m)} মি';
  }

  static String _hm(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  Widget _led(Color c, {bool pulse = false}) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        final glow = pulse ? 0.5 + 0.5 * (1 - (_anim.value * 2 - 1).abs()) : 0.6;
        return Container(
          width: 11,
          height: 11,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: c,
            boxShadow: [BoxShadow(color: c.withAlpha((200 * glow).round()), blurRadius: 8, spreadRadius: 1)],
          ),
        );
      },
    );
  }

  Widget _kpi(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.fromLTRB(10, 9, 8, 9),
        decoration: BoxDecoration(
          color: Hmi.panel,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Hmi.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, size: 13, color: color),
              const SizedBox(width: 4),
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10, color: Hmi.dim)),
              ),
            ]),
            const SizedBox(height: 3),
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color, fontFeatures: const [FontFeature.tabularFigures()])),
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, String value, String unit, Color color) {
    return Container(
      margin: const EdgeInsets.only(right: 6, bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Hmi.bg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Hmi.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 9, letterSpacing: .6, color: Hmi.dim)),
          const SizedBox(height: 2),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(value,
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: value == '—' ? Hmi.grey : color,
                      fontFeatures: const [FontFeature.tabularFigures()])),
              if (unit.isNotEmpty && value != '—')
                Padding(
                  padding: const EdgeInsets.only(left: 3, bottom: 2),
                  child: Text(unit, style: const TextStyle(fontSize: 10, color: Hmi.dim)),
                ),
            ],
          ),
        ],
      ),
    );
  }

  /// status: 0 wait, 1 running, 2 pass, 3 fail, 4 skip
  int _statusOf(int i, ProductionOrder? o, Map<String, StageCheck> checks) {
    final st = kStages[i];
    final c = checks[st.key];
    if (c != null) {
      return c.result == 'Pass' ? 2 : (c.result == 'Fail' ? 3 : 4);
    }
    if (o == null || o.status == 'Planned' || o.status == 'Cancelled') return 0;
    for (var k = 0; k < i; k++) {
      if (!checks.containsKey(kStages[k].key)) {
        // an earlier stage is still open -> this one waits unless the order status moved on
        final s = o.status;
        if (st.key == 'Aging' && s == 'Aging') return 1;
        if (st.key == 'Freezing' && s == 'Freezing') return 1;
        return 0;
      }
    }
    return 1;
  }

  Widget _station(int i, ProductionOrder? o, _Data d) {
    final st = kStages[i];
    final color = _stageColors[st.key]!;
    final status = _statusOf(i, o, d.checks);
    final c = d.checks[st.key];
    final active = status == 1;
    final ledColor = status == 2
        ? Hmi.green
        : status == 3
            ? Hmi.red
            : status == 1
                ? Hmi.amber
                : Hmi.grey;
    final label = ['অপেক্ষা', 'চলছে', 'পাস', 'ফেল', 'এড়ানো'][status];
    final en = ['WAIT', 'RUNNING', 'PASS', 'FAIL', 'SKIP'][status];

    final metrics = <Widget>[];
    switch (st.key) {
      case 'Mixing':
        metrics.add(_metric('সময়', _dur(c?.durationMin), '', color));
        metrics.add(_metric('পরিমাণ', o == null ? '—' : fmtQty(o.targetQty), 'L', color));
        break;
      case 'Pasteurization':
        metrics.add(_metric('তাপমাত্রা', c?.tempValue == null ? '—' : fmtQty(c!.tempValue!), '°C', color));
        metrics.add(_metric('সময়', _dur(c?.durationMin), '', color));
        break;
      case 'Homogenization':
        metrics.add(_metric('প্রেশার', c?.pressureBar == null ? '—' : fmtQty(c!.pressureBar!), 'bar', color));
        metrics.add(_metric('তাপমাত্রা', c?.tempValue == null ? '—' : fmtQty(c!.tempValue!), '°C', color));
        metrics.add(_metric('সময়', _dur(c?.durationMin), '', color));
        break;
      case 'Aging':
        metrics.add(_metric('তাপমাত্রা', c?.tempValue == null ? '—' : fmtQty(c!.tempValue!), '°C', color));
        var ageMin = c?.durationMin;
        if (ageMin == null && o?.agingStartedAt != null && o!.status == 'Aging') {
          ageMin = DateTime.now().difference(o.agingStartedAt!).inMinutes.toDouble();
        }
        metrics.add(_metric('সময়', _dur(ageMin), '', color));
        break;
      case 'Freezing':
        metrics.add(_metric('তাপমাত্রা', c?.tempValue == null ? '—' : fmtQty(c!.tempValue!), '°C', color));
        metrics.add(_metric('সময়', _dur(c?.durationMin), '', color));
        break;
      default:
        metrics.add(_metric('কার্টন', d.cartons > 0 ? fmtQty(d.cartons) : '—', 'ctn', color));
        metrics.add(_metric('সময়', _dur(c?.durationMin), '', color));
    }

    return Container(
      decoration: BoxDecoration(
        color: Hmi.panel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: active ? color.withAlpha(200) : Hmi.line, width: active ? 1.4 : 1),
        boxShadow: active ? [BoxShadow(color: color.withAlpha(60), blurRadius: 16)] : null,
      ),
      child: CustomPaint(
        foregroundPainter: BracketPainter(active ? color : Hmi.grey.withAlpha(150)),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 84,
                height: 84,
                child: CustomPaint(painter: EquipmentPainter(i, _anim, active || status == 2, color)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text('0${i + 1}', style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w800, letterSpacing: 1)),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(st.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Hmi.text)),
                      ),
                      _led(ledColor, pulse: active),
                      const SizedBox(width: 5),
                      Text(en, style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, letterSpacing: .8, color: ledColor)),
                    ]),
                    const SizedBox(height: 2),
                    Text(
                      '${st.en} • $label${c == null ? '' : ' • ${_hm(c.checkedAt)}'}',
                      style: const TextStyle(fontSize: 10.5, color: Hmi.dim),
                    ),
                    const SizedBox(height: 8),
                    Wrap(children: metrics),
                    if (c?.note != null)
                      Text(c!.note!, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: Hmi.dim)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pipe(int i, ProductionOrder? o, _Data d) {
    final a = _stageColors[kStages[i].key]!;
    final b = _stageColors[kStages[i + 1].key]!;
    final flowing = _statusOf(i, o, d.checks) == 1 || (_statusOf(i, o, d.checks) == 2 && _statusOf(i + 1, o, d.checks) == 1);
    return SizedBox(
      height: 26,
      child: Row(children: [
        const SizedBox(width: 10),
        SizedBox(width: 84, child: CustomPaint(painter: PipePainter(_anim, a, b, flowing))),
      ]),
    );
  }

  Widget _batchHeader(ProductionOrder? o, _Data d) {
    if (o == null) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Hmi.panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: Hmi.line)),
        child: const Text('কোনো ব্যাচ নেই। Home থেকে "আজকের ব্যাচ" বসান, ডায়াগ্রামে লাইভ দেখা যাবে।',
            style: TextStyle(color: Hmi.dim)),
      );
    }
    final r = d.recipes[o.recipeId];
    var done = 0;
    for (final s in kStages) {
      if (d.checks.containsKey(s.key)) done++;
    }
    final allPass = StageService.isAllPass(d.checks.values.toList());
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Hmi.panelHi, Hmi.panel]),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Hmi.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text(o.orderNo, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Hmi.text, letterSpacing: .5)),
            ),
            if (allPass) const Icon(Icons.verified, color: Hmi.green, size: 20),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: Hmi.cyan.withAlpha(30), borderRadius: BorderRadius.circular(8), border: Border.all(color: Hmi.cyan.withAlpha(120))),
              child: Text(o.status.toUpperCase(), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Hmi.cyan, letterSpacing: .8)),
            ),
          ]),
          const SizedBox(height: 2),
          Text(
            '${r?.recipeName ?? 'Recipe #${o.recipeId}'} • ${fmtQty(o.targetQty)} ${o.targetUnit}'
            '${o.shift.isEmpty ? '' : ' • ${o.shift}'}',
            style: const TextStyle(fontSize: 12, color: Hmi.dim),
          ),
          const SizedBox(height: 10),
          Row(children: [
            for (var i = 0; i < kStages.length; i++)
              Expanded(
                child: Container(
                  height: 6,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: (d.checks[kStages[i].key]?.result == 'Fail')
                        ? Hmi.red
                        : d.checks.containsKey(kStages[i].key)
                            ? Hmi.green
                            : (_statusOf(i, o, d.checks) == 1 ? Hmi.amber : Hmi.line),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 4),
          Text('$done / ${kStages.length} ধাপ সম্পন্ন', style: const TextStyle(fontSize: 10.5, color: Hmi.dim)),
        ],
      ),
    );
  }

  Widget _tankCard(Tank t) {
    final pct = t.capacityLiter > 0 ? (t.currentQty / t.capacityLiter).clamp(0.0, 1.0).toDouble() : 0.0;
    final col = t.tankType == 'Aging' ? const Color(0xFF4DA3FF) : (t.tankType == 'Mixing' ? Hmi.cyan : Hmi.green);
    final led = t.status == 'InUse' ? Hmi.amber : (t.status == 'Cleaning' ? Hmi.cyan : Hmi.green);
    return Container(
      width: (MediaQuery.of(context).size.width - 16 * 2 - 8) / 2,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Hmi.panel, borderRadius: BorderRadius.circular(12), border: Border.all(color: Hmi.line)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(child: Text(t.tankCode, style: const TextStyle(fontWeight: FontWeight.w800, color: Hmi.text, fontSize: 13))),
            _led(led, pulse: t.status == 'InUse'),
          ]),
          Text('${t.tankType} • ${t.status}', style: const TextStyle(fontSize: 10, color: Hmi.dim)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: Stack(children: [
              Container(height: 10, color: Hmi.line),
              AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                height: 10,
                width: ((MediaQuery.of(context).size.width - 16 * 2 - 8) / 2 - 20) * pct,
                color: col,
              ),
            ]),
          ),
          const SizedBox(height: 4),
          Text('${fmtQty(t.currentQty)} / ${fmtQty(t.capacityLiter)} L • ${(pct * 100).round()}%',
              style: const TextStyle(fontSize: 10.5, color: Hmi.dim)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final co = ref.watch(companyProvider);
    final d = _d;
    if (d == null) {
      _schedule();
      return const Scaffold(backgroundColor: Hmi.bg, body: Center(child: CircularProgressIndicator()));
    }
    ProductionOrder? sel;
    for (final o in d.orders) {
      if (o.id == _sel) sel = o;
    }
    return Scaffold(
      backgroundColor: Hmi.bg,
      body: SafeArea(
        child: RefreshIndicator(
          color: Hmi.cyan,
          backgroundColor: Hmi.panel,
          onRefresh: _refresh,
          child: ScrollConfiguration(
            behavior: ScrollConfiguration.of(context).copyWith(overscroll: false),
            child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
            padding: const EdgeInsets.all(16),
            child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                const Icon(Icons.account_tree_rounded, color: Hmi.cyan, size: 22),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(co.shownName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Hmi.text)),
                      const Text('PROCESS CONTROL • প্রোডাকশন ড্যাশবোর্ড',
                          style: TextStyle(fontSize: 10, letterSpacing: 1, color: Hmi.dim)),
                    ],
                  ),
                ),
                _led(Hmi.green, pulse: true),
                const SizedBox(width: 6),
                const Text('LIVE', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, color: Hmi.green)),
                const _LiveClock(),
              ]),
              const SizedBox(height: 14),
              Row(children: [
                _kpi('আজকের ব্যাচ', '${d.kBatches}', Hmi.cyan, Icons.layers_rounded),
                _kpi('চলমান', '${d.kRunning}', Hmi.amber, Icons.sync_rounded),
                _kpi('সম্পন্ন', '${d.kDone}', Hmi.green, Icons.check_circle_rounded),
                _kpi('সব পাস', '${d.kAllPass}', const Color(0xFFB28CFF), Icons.verified_rounded),
              ]),
              const SizedBox(height: 14),
              if (d.orders.length > 1)
                SizedBox(
                  height: 38,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final o in d.orders)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text('${o.orderNo} • ${d.recipes[o.recipeId]?.recipeName ?? ''}',
                                style: TextStyle(fontSize: 11.5, color: o.id == _sel ? Hmi.bg : Hmi.text, fontWeight: FontWeight.w700)),
                            selected: o.id == _sel,
                            selectedColor: Hmi.cyan,
                            backgroundColor: Hmi.panel,
                            side: const BorderSide(color: Hmi.line),
                            onSelected: (_) {
                              setState(() => _sel = o.id);
                              _load();
                            },
                          ),
                        ),
                    ],
                  ),
                ),
              if (d.orders.length > 1) const SizedBox(height: 12),
              _batchHeader(sel, d),
              const SizedBox(height: 14),
              for (var i = 0; i < kStages.length; i++) ...[
                RepaintBoundary(child: _station(i, sel, d)),
                if (i < kStages.length - 1) _pipe(i, sel, d),
              ],
              const SizedBox(height: 18),
              const Text('ট্যাংক লেভেল', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Hmi.text)),
              const SizedBox(height: 8),
              if (d.tanks.isEmpty)
                const Text('কোনো ট্যাংক নেই', style: TextStyle(color: Hmi.dim))
              else
                Wrap(spacing: 8, runSpacing: 8, children: [for (final t in d.tanks) _tankCard(t)]),
              const SizedBox(height: 20),
            ],
            ),
          ),
          ),
        ),
      ),
    );
  }
}


class _LiveClock extends StatefulWidget {
  const _LiveClock();
  @override
  State<_LiveClock> createState() => _LiveClockState();
}

class _LiveClockState extends State<_LiveClock> {
  Timer? _t;
  DateTime _now = DateTime.now();
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  String _p(int v) => v.toString().padLeft(2, '0');
  @override
  Widget build(BuildContext context) {
    final n = _now;
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Text('${_p(n.hour)}:${_p(n.minute)}:${_p(n.second)}',
          style: const TextStyle(fontSize: 13, color: Hmi.text, fontWeight: FontWeight.w700, fontFeatures: [FontFeature.tabularFigures()])),
    );
  }
}
