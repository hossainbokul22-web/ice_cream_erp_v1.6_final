import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'i18n_dict.dart';

/// Language helper. The whole UI text is written in Bengali; when English is
/// selected every Bengali phrase is translated through [kBnEn] at display time.
class I18n {
  static bool english = true;

  static final RegExp _bn = RegExp(r'[\u0980-\u09FF]');
  static final Map<String, String> _cache = {};
  static RegExp? _re;
  static Map<String, String>? _map;

  static void _init() {
    if (_re != null) return;
    final map = <String, String>{};
    final alts = <String>[];
    final sorted = [...kBnEn]..sort((a, b) => b[0].length.compareTo(a[0].length));
    for (final p in sorted) {
      if (map.containsKey(p[0])) continue;
      map[p[0]] = p[1];
      var s = RegExp.escape(p[0]);
      if (_bn.hasMatch(p[0][0])) s = r'(?<![\u0980-\u09FF])' + s;
      if (_bn.hasMatch(p[0][p[0].length - 1])) s = s + r'(?![\u0980-\u09FF])';
      alts.add(s);
    }
    _map = map;
    _re = RegExp(alts.join('|'));
  }

  static const _digitsBn = '০১২৩৪৫৬৭৮৯';

  static String tr(String s) {
    if (!english || s.isEmpty || !_bn.hasMatch(s)) return s;
    final hit = _cache[s];
    if (hit != null) return hit;
    _init();
    var out = s.replaceAllMapped(_re!, (mt) => _map![mt.group(0)] ?? mt.group(0)!);
    final b = StringBuffer();
    for (final ch in out.split('')) {
      final i = _digitsBn.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    out = b.toString();
    if (_cache.length > 4000) _cache.clear();
    _cache[s] = out;
    return out;
  }
}

/// Shorthand for non-Text strings (labelText, tooltip ...).
String tr(String s) => I18n.tr(s);

/// Put once above the app; widgets that call [LangScope.of] rebuild on a language change.
class LangScope extends InheritedWidget {
  const LangScope({super.key, required this.english, required super.child});
  final bool english;

  static bool of(BuildContext context) {
    final s = context.dependOnInheritedWidgetOfExactType<LangScope>();
    return s?.english ?? I18n.english;
  }

  @override
  bool updateShouldNotify(LangScope old) => old.english != english;
}

/// Drop-in replacement for Flutter's Text that translates its data.
class Text extends StatelessWidget {
  const Text(
    this.data, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.textScaler,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
  });

  final String data;
  final TextStyle? style;
  final StrutStyle? strutStyle;
  final TextAlign? textAlign;
  final TextDirection? textDirection;
  final Locale? locale;
  final bool? softWrap;
  final TextOverflow? overflow;
  final TextScaler? textScaler;
  final int? maxLines;
  final String? semanticsLabel;
  final TextWidthBasis? textWidthBasis;
  final TextHeightBehavior? textHeightBehavior;
  final Color? selectionColor;

  @override
  Widget build(BuildContext context) {
    LangScope.of(context);
    return m.Text(
      I18n.tr(data),
      style: style,
      strutStyle: strutStyle,
      textAlign: textAlign,
      textDirection: textDirection,
      locale: locale,
      softWrap: softWrap,
      overflow: overflow,
      textScaler: textScaler,
      maxLines: maxLines,
      semanticsLabel: semanticsLabel,
      textWidthBasis: textWidthBasis,
      textHeightBehavior: textHeightBehavior,
      selectionColor: selectionColor,
    );
  }
}
