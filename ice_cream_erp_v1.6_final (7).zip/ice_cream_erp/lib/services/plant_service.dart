import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/app_database.dart';
import '../providers/database_provider.dart';

/// Stages that can carry a standard (temperature / pressure / time).
class StdStage {
  const StdStage(this.key, this.bn, {this.temp = false, this.pressure = false});
  final String key;
  final String bn;
  final bool temp;
  final bool pressure;
}

const List<StdStage> kStdStages = [
  StdStage('Mixing', 'মিক্সিং'),
  StdStage('Pasteurization', 'পাস্তুরাইজেশন', temp: true),
  StdStage('Homogenization', 'হোমোজেনাইজেশন', temp: true, pressure: true),
  StdStage('Aging', 'এজিং', temp: true),
  StdStage('Freezing', 'ফ্রিজিং', temp: true),
  StdStage('Hardening', 'হার্ডেনিং', temp: true),
  StdStage('Packing', 'প্যাকেজিং'),
];

final plantServiceProvider = Provider<PlantService>((ref) => PlantService(ref.watch(databaseProvider)));

class PlantService {
  PlantService(this.db);
  final AppDatabase db;

  // ---------- standard sheet ----------
  Future<List<StageStandard>> standardsFor(int? recipeId) {
    final q = db.select(db.stageStandards);
    if (recipeId == null) {
      q.where((s) => s.recipeId.isNull());
    } else {
      q.where((s) => s.recipeId.equals(recipeId));
    }
    return q.get();
  }

  Future<void> saveStandard({
    required int? recipeId,
    required String stage,
    double? tempMin,
    double? tempMax,
    double? pressureMin,
    double? pressureMax,
    double? durationMin,
    String? note,
  }) async {
    if (tempMin != null && tempMax != null && tempMin > tempMax) {
      throw ArgumentError('তাপমাত্রা: সর্বনিম্ন সর্বোচ্চের চেয়ে বেশি হতে পারে না');
    }
    if (pressureMin != null && pressureMax != null && pressureMin > pressureMax) {
      throw ArgumentError('প্রেশার: সর্বনিম্ন সর্বোচ্চের চেয়ে বেশি হতে পারে না');
    }
    if (durationMin != null && durationMin <= 0) throw ArgumentError('সময় ০ এর বেশি হতে হবে');
    await db.transaction(() async {
      await clearStandard(recipeId, stage);
      final allEmpty = tempMin == null &&
          tempMax == null &&
          pressureMin == null &&
          pressureMax == null &&
          durationMin == null &&
          (note == null || note.trim().isEmpty);
      if (allEmpty) return;
      await db.into(db.stageStandards).insert(StageStandardsCompanion.insert(
            recipeId: Value(recipeId),
            stage: stage,
            tempMin: Value(tempMin),
            tempMax: Value(tempMax),
            pressureMin: Value(pressureMin),
            pressureMax: Value(pressureMax),
            durationMin: Value(durationMin),
            note: Value(note == null || note.trim().isEmpty ? null : note.trim()),
          ));
    });
  }

  Future<void> clearStandard(int? recipeId, String stage) {
    final d = db.delete(db.stageStandards);
    if (recipeId == null) {
      d.where((s) => s.recipeId.isNull() & s.stage.equals(stage));
    } else {
      d.where((s) => s.recipeId.equals(recipeId) & s.stage.equals(stage));
    }
    return d.go();
  }

  // ---------- freezers ----------
  Future<void> saveFreezer({int? id, required String code, required String name, required double capacity, bool active = true}) async {
    final c = code.trim();
    if (c.isEmpty) throw ArgumentError('ফ্রিজার কোড দিন');
    if (capacity < 0) throw ArgumentError('ক্ষমতা ঠিকভাবে দিন');
    final dup = await (db.select(db.freezers)..where((f) => f.freezerCode.equals(c))).get();
    if (dup.any((f) => f.id != id)) throw ArgumentError('এই কোড আগে থেকেই আছে');
    final n = name.trim().isEmpty ? c : name.trim();
    if (id == null) {
      await db.into(db.freezers).insert(FreezersCompanion.insert(
            freezerCode: c,
            freezerName: n,
            capacityLiter: Value(capacity),
            isActive: Value(active),
          ));
    } else {
      await (db.update(db.freezers)..where((f) => f.id.equals(id))).write(FreezersCompanion(
        freezerCode: Value(c),
        freezerName: Value(n),
        capacityLiter: Value(capacity),
        isActive: Value(active),
      ));
    }
  }

  /// Adds [count] freezers named F-001.. continuing after the highest existing number.
  Future<int> addFreezers(int count, double capacity) async {
    if (count <= 0 || count > 200) throw ArgumentError('১ থেকে ২০০ এর মধ্যে দিন');
    final all = await db.select(db.freezers).get();
    var maxN = 0;
    for (final f in all) {
      final m = RegExp(r'^F-(\d+)$').firstMatch(f.freezerCode);
      if (m != null) {
        final n = int.parse(m.group(1)!);
        if (n > maxN) maxN = n;
      }
    }
    await db.transaction(() async {
      for (var i = 1; i <= count; i++) {
        final code = 'F-${(maxN + i).toString().padLeft(3, '0')}';
        await db.into(db.freezers).insert(FreezersCompanion.insert(
              freezerCode: code,
              freezerName: 'Freezer ${maxN + i}',
              capacityLiter: Value(capacity),
            ));
      }
    });
    return count;
  }

  Future<void> deleteFreezer(int id) async {
    final used = await (db.select(db.productionOrders)..where((o) => o.freezerId.equals(id))).get();
    if (used.isNotEmpty) {
      await (db.update(db.freezers)..where((f) => f.id.equals(id))).write(const FreezersCompanion(isActive: Value(false)));
      throw StateError('এই ফ্রিজার আগের ব্যাচে ব্যবহার হয়েছে, তাই মুছে না ফেলে বন্ধ (inactive) করা হলো');
    }
    await (db.delete(db.freezers)..where((f) => f.id.equals(id))).go();
  }
}
