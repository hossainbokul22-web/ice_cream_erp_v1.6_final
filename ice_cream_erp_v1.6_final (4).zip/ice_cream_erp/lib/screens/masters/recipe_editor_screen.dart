import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/production_math.dart';
import '../../utils/ui.dart';
import 'item_list_screen.dart' show kUnits;

/// Create / edit a recipe header and its ingredient lines.
class RecipeEditorScreen extends ConsumerStatefulWidget {
  const RecipeEditorScreen({super.key, this.recipeId});
  final int? recipeId;

  @override
  ConsumerState<RecipeEditorScreen> createState() => _RecipeEditorScreenState();
}

class _RecipeEditorScreenState extends ConsumerState<RecipeEditorScreen> {
  final _code = TextEditingController();
  final _name = TextEditingController();
  final _baseQty = TextEditingController(text: '1000');
  final _batchKg = TextEditingController();
  final _density = TextEditingController(text: '1.03');
  final _pcs = TextEditingController();
  final _ml = TextEditingController();
  final _overrun = TextEditingController(text: '100');
  final _yield = TextEditingController(text: '98');
  final _aging = TextEditingController(text: '4');
  // Dashboard timings (minutes): mixing, pasteur, homog, aging, freezing, hardening, packing
  final List<TextEditingController> _tm = List.generate(7, (_) => TextEditingController());
  int? _finishedItemId;
  int? _id;
  bool _active = true;
  bool _loaded = false;

  List<Item> _items = [];

  @override
  void initState() {
    super.initState();
    _id = widget.recipeId;
    _load();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    _items = await (db.select(db.items)
          ..where((i) => i.isActive.equals(true))
          ..orderBy([(i) => OrderingTerm.asc(i.itemCode)]))
        .get();
    if (_id != null) {
      final r = await (db.select(db.recipes)..where((x) => x.id.equals(_id!))).getSingle();
      _code.text = r.recipeCode;
      _name.text = r.recipeName;
      _baseQty.text = r.baseQty.toString();
      _batchKg.text = r.batchKg == null ? '' : fmtQty(r.batchKg!);
      _density.text = r.density.toString();
      _pcs.text = r.pcsPerCarton == null ? '' : fmtQty(r.pcsPerCarton!);
      _ml.text = r.mlPerPcs == null ? '' : fmtQty(r.mlPerPcs!);
      _overrun.text = r.targetOverrun.toString();
      _yield.text = r.expectedYield.toString();
      _aging.text = r.agingHours.toString();
      final parts = (r.stageMins ?? '').split(',');
      for (var i = 0; i < 7; i++) {
        _tm[i].text = i < parts.length ? parts[i].trim() : '';
      }
      _finishedItemId = r.finishedItemId;
      _active = r.isActive;
    } else {
      final all = await db.select(db.recipes).get();
      var maxN = 0;
      for (final r in all) {
        final m = RegExp(r'^RCP-(\d+)$').firstMatch(r.recipeCode);
        if (m != null) {
          final n = int.parse(m.group(1)!);
          if (n > maxN) maxN = n;
        }
      }
      _code.text = 'RCP-${(maxN + 1).toString().padLeft(3, '0')}';
    }
    if (mounted) setState(() => _loaded = true);
  }

  List<Item> get _finishedChoices =>
      _items.where((i) => i.itemType == 'Finished' || i.itemType == 'Semi' || i.itemType == 'Mix').toList();

  Future<void> _saveHeader() async {
    final code = _code.text.trim();
    final name = _name.text.trim();
    final base = parseNum(_baseQty.text);
    final kg = parseNum(_batchKg.text);
    final den = parseNum(_density.text);
    final pcs = parseNum(_pcs.text);
    final ml = parseNum(_ml.text);
    final over = parseNum(_overrun.text);
    final yld = parseNum(_yield.text);
    final aging = parseNum(_aging.text);
    final stageMins = _tm.map((c) => c.text.trim()).join(',');
    if (code.isEmpty || name.isEmpty) { showSnack(context, 'Code ও Name দিন'); return; }
    if (_finishedItemId == null) { showSnack(context, 'Finished Item সিলেক্ট করুন'); return; }
    if (den == null || den <= 0) { showSnack(context, 'ঘনত্ব (kg/L) ০ এর বেশি হতে হবে'); return; }
    if (base == null || base <= 0) { showSnack(context, 'Base Qty ০ এর বেশি হতে হবে'); return; }
    if (over == null || over < 0 || over > 300) { showSnack(context, 'Overrun ০–৩০০% এর মধ্যে দিন'); return; }
    if (yld == null || yld <= 0 || yld > 100) { showSnack(context, 'Yield ০–১০০% এর মধ্যে দিন'); return; }
    if (aging == null || aging < 0) { showSnack(context, 'Aging ঘণ্টা ঠিকভাবে দিন'); return; }

    final db = ref.read(databaseProvider);
    final ok = await runGuarded(context, () async {
      if (_id == null) {
        _id = await db.into(db.recipes).insert(RecipesCompanion.insert(
              recipeCode: code,
              recipeName: name,
              finishedItemId: _finishedItemId!,
              baseQty: base,
              baseUnit: 'L',
              batchKg: Value(kg),
              density: Value(den),
              pcsPerCarton: Value(pcs),
              mlPerPcs: Value(ml),
              targetOverrun: Value(over),
              expectedYield: Value(yld),
              agingHours: Value(aging),
              stageMins: Value(stageMins),
            ));
      } else {
        await (db.update(db.recipes)..where((r) => r.id.equals(_id!))).write(RecipesCompanion(
          recipeCode: Value(code),
          recipeName: Value(name),
          finishedItemId: Value(_finishedItemId!),
          baseQty: Value(base),
          batchKg: Value(kg),
          density: Value(den),
          pcsPerCarton: Value(pcs),
          mlPerPcs: Value(ml),
          targetOverrun: Value(over),
          expectedYield: Value(yld),
          agingHours: Value(aging),
          stageMins: Value(stageMins),
          isActive: Value(_active),
        ));
      }
      if (pcs != null && pcs > 0 && ml != null && ml > 0) {
        await (db.update(db.items)..where((i) => i.id.equals(_finishedItemId!)))
            .write(const ItemsCompanion(baseUnit: Value('Carton')));
      }
    }, success: 'রেসিপি সেভ হয়েছে');
    if (ok && mounted) setState(() {});
  }

  Future<void> _addLine() async {
    if (_id == null) { showSnack(context, 'আগে রেসিপি হেডার সেভ করুন'); return; }
    final db = ref.read(databaseProvider);
    final choices = _items.where((i) => i.itemType != 'Finished').toList();
    if (choices.isEmpty) { showSnack(context, 'আগে Item Master এ কাঁচামাল যোগ করুন'); return; }

    Item sel = choices.first;
    String unit = sel.baseUnit;
    final qty = TextEditingController();
    final waste = TextEditingController(text: '0');

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('ইনগ্রিডিয়েন্ট যোগ'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  isExpanded: true,
                  value: sel.id,
                  decoration: const InputDecoration(labelText: 'Item'),
                  items: choices
                      .map((i) => DropdownMenuItem(value: i.id, child: Text('${i.itemCode} - ${i.itemName}', overflow: TextOverflow.ellipsis)))
                      .toList(),
                  onChanged: (v) => setD(() {
                    sel = choices.firstWhere((i) => i.id == v);
                    unit = sel.baseUnit;
                  }),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: qty,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(label: Text('Qty (Base Qty এর জন্য)')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: DropdownButtonFormField<String>(
                      value: unit,
                      decoration: const InputDecoration(labelText: 'Unit'),
                      items: {...kUnits, unit}.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                      onChanged: (v) => setD(() => unit = v!),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                TextField(
                  controller: waste,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Wastage %'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
            FilledButton(
              onPressed: () async {
                final q = parseNum(qty.text);
                final w = parseNum(waste.text) ?? 0;
                if (q == null || q <= 0) { showSnack(ctx, 'Qty ০ এর বেশি হতে হবে'); return; }
                if (w < 0 || w > 50) { showSnack(ctx, 'Wastage ০–৫০% এর মধ্যে দিন'); return; }
                final ok = await runGuarded(ctx, () async {
                  // Reject units that cannot be converted to the item's base unit.
                  final rows = await (db.select(db.unitConversions)
                        ..where((c) => c.itemId.equals(sel.id)))
                      .get();
                  convertQty(1, unit, sel.baseUnit, factors: {
                    for (final r in rows) '${r.fromUnit}>${r.toUnit}': r.conversionFactor
                  });
                  final dup = await (db.select(db.recipeLines)
                        ..where((l) => l.recipeId.equals(_id!) & l.itemId.equals(sel.id)))
                      .get();
                  if (dup.isNotEmpty) {
                    throw ArgumentError('${sel.itemName} আগেই যোগ করা আছে — আগেরটি মুছে/এডিট করুন');
                  }
                  final count = (await (db.select(db.recipeLines)..where((l) => l.recipeId.equals(_id!))).get()).length;
                  await db.into(db.recipeLines).insert(RecipeLinesCompanion.insert(
                        recipeId: _id!,
                        itemId: sel.id,
                        qty: q,
                        unit: unit,
                        wastagePercent: Value(w),
                        sequence: Value(count + 1),
                      ));
                });
                if (ok && ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('যোগ করুন'),
            ),
          ],
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _addPackLine() async {
    final db = ref.read(databaseProvider);
    final packItems = _items.where((i) => i.itemType == 'Packaging').toList();
    if (packItems.isEmpty) {
      showSnack(context, 'আগে Item Master এ Packaging টাইপের আইটেম যোগ করুন');
      return;
    }
    int? itemId;
    final qtyCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Packaging (১ কার্টুনে)'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                isExpanded: true,
                value: itemId,
                decoration: const InputDecoration(labelText: 'Packaging Item'),
                items: packItems
                    .map((i) => DropdownMenuItem(value: i.id, child: Text('${i.itemCode} - ${i.itemName}', overflow: TextOverflow.ellipsis)))
                    .toList(),
                onChanged: (v) => setD(() => itemId = v),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: qtyCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('১ কার্টুনে কত')),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
            FilledButton(
              onPressed: () async {
                final q = parseNum(qtyCtrl.text);
                if (itemId == null || q == null || q <= 0) {
                  showSnack(ctx, 'আইটেম ও পরিমাণ দিন');
                  return;
                }
                await db.into(db.recipePackLines).insert(
                    RecipePackLinesCompanion.insert(recipeId: _id!, itemId: itemId!, qtyPerCarton: q));
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('যোগ করুন'),
            ),
          ],
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _deletePackLine(RecipePackLine l) async {
    if (!await confirm(context, 'মুছবেন?', 'এই প্যাকেজিং রেসিপি থেকে সরানো হবে।')) return;
    final db = ref.read(databaseProvider);
    await (db.delete(db.recipePackLines)..where((x) => x.id.equals(l.id))).go();
    if (mounted) setState(() {});
  }

  Future<void> _deleteLine(RecipeLine l) async {
    if (!await confirm(context, 'মুছবেন?', 'এই ইনগ্রিডিয়েন্টটি রেসিপি থেকে সরানো হবে।')) return;
    final db = ref.read(databaseProvider);
    await (db.delete(db.recipeLines)..where((x) => x.id.equals(l.id))).go();
    if (mounted) setState(() {});
  }

  /// Cost estimate using each item's current average cost.
  Widget _costSummary(List<RecipeLine> lines) {
    final base = parseNum(_baseQty.text) ?? 0;
    final over = parseNum(_overrun.text) ?? 0;
    final byId = {for (final i in _items) i.id: i};
    var total = 0.0;
    var unknown = false;
    for (final l in lines) {
      final it = byId[l.itemId];
      if (it == null) continue;
      try {
        final q = convertQty(l.qty * (1 + l.wastagePercent / 100), l.unit, it.baseUnit);
        total += q * it.standardCost;
      } on UnitConversionException {
        unknown = true;
      }
    }
    final finished = base * (1 + over / 100);
    return Card(
      color: Colors.indigo.withAlpha(35),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('আনুমানিক খরচ (বর্তমান Avg cost অনুযায়ী)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Mix খরচ: ${fmtMoney(total)}  (প্রতি লিটার ${base > 0 ? fmtMoney(total / base) : '—'})'),
          Text('প্রত্যাশিত Finished: ${fmtQty(finished)} L  →  প্রতি লিটার ${finished > 0 ? fmtMoney(total / finished) : '—'}'),
          if (unknown) const Text('⚠ কিছু ইউনিট কনভার্ট হয়নি, হিসাব অসম্পূর্ণ', style: TextStyle(color: Colors.red, fontSize: 12)),
          const Text('শুধু কাঁচামাল; Labour/Overhead আলাদা যোগ হয়।', style: TextStyle(fontSize: 11, color: Colors.grey)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final byId = {for (final i in _items) i.id: i};

    return Scaffold(
      appBar: AppBar(title: Text(_id == null ? 'নতুন রেসিপি' : 'রেসিপি: ${_code.text}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _code,
            readOnly: true,
            decoration: const InputDecoration(label: Text('Recipe Code (অটো)'), suffixIcon: Icon(Icons.lock_outline, size: 18)),
          ),
          const SizedBox(height: 8),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Recipe Name *')),
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            isExpanded: true,
            value: _finishedChoices.any((i) => i.id == _finishedItemId) ? _finishedItemId : null,
            decoration: const InputDecoration(
                labelText: 'Finished Item *', helper: Text('Item Master এ Type = Finished/Semi/Mix হতে হবে')),
            items: _finishedChoices
                .map((i) => DropdownMenuItem(value: i.id, child: Text('${i.itemCode} - ${i.itemName}', overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) => setState(() => _finishedItemId = v),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _batchKg,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('১ ব্যাচ = কেজি')),
                onChanged: (v) {
                  final kg = parseNum(v);
                  final d = parseNum(_density.text);
                  if (kg != null && d != null && d > 0) _baseQty.text = fmtQty(kg / d);
                  setState(() {});
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _density,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('ঘনত্ব (kg/L)')),
                onChanged: (v) {
                  final kg = parseNum(_batchKg.text);
                  final d = parseNum(v);
                  if (kg != null && d != null && d > 0) _baseQty.text = fmtQty(kg / d);
                  setState(() {});
                },
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _baseQty,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('১ ব্যাচ = লিটার (Base Mix Qty)')),
                onChanged: (v) {
                  final l = parseNum(v);
                  final d = parseNum(_density.text);
                  if (l != null && d != null && d > 0) _batchKg.text = fmtQty(l * d);
                  setState(() {});
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _overrun,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Target Overrun %'),
                onChanged: (_) => setState(() {}),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _pcs,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('১ কার্টন = কত পিস')),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _ml,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('১ পিস = কত মিলি')),
                onChanged: (_) => setState(() {}),
              ),
            ),
          ]),
          Builder(builder: (context) {
            final p = parseNum(_pcs.text) ?? 0;
            final m = parseNum(_ml.text) ?? 0;
            if (p <= 0 || m <= 0) {
              return const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text('ফিনিশ কার্টন হিসাবের জন্য পিস ও মিলি দিন।', style: TextStyle(fontSize: 12, color: Colors.grey)),
              );
            }
            return Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('১ কার্টন = ${fmtQty(p)} × ${fmtQty(m)} মিলি = ${fmtQty(p * m / 1000)} লিটার',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            );
          }),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _yield,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Expected Yield %'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _aging,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(label: Text('Min Aging (ঘণ্টা)')),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          const Text('ড্যাসবোর্ড অ্যানিমেশন সময় (মিনিট)', style: TextStyle(fontWeight: FontWeight.w800)),
          const Text('ফাঁকা রাখলে ডিফল্ট: ৫, ১, ৫, এজিং ঘণ্টা×৬০, ৮, ১২০, ৩০',
              style: TextStyle(fontSize: 11)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in const [
              [0, 'মিক্সিং'],
              [1, 'পাস্তুরাইজেশন'],
              [2, 'হোমোজেনাইজেশন'],
              [3, 'এজিং'],
              [4, 'ফ্রিজিং'],
              [5, 'হার্ডেনিং'],
              [6, 'প্যাকেজিং'],
            ])
              SizedBox(
                width: 104,
                child: TextField(
                  controller: _tm[e[0] as int],
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: e[1] as String, isDense: true),
                ),
              ),
          ]),
          if (_id != null)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Active'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _saveHeader,
            icon: const Icon(Icons.save),
            label: const Text('হেডার সেভ করুন'),
          ),
          const Divider(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Ingredients', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              OutlinedButton.icon(
                onPressed: _addLine,
                icon: const Icon(Icons.add),
                label: const Text('যোগ করুন'),
              ),
            ],
          ),
          if (_id == null)
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('হেডার সেভ করার পর ইনগ্রিডিয়েন্ট যোগ করা যাবে।', style: TextStyle(color: Colors.grey)),
            )
          else
            StreamBuilder<List<RecipeLine>>(
              stream: (db.select(db.recipeLines)
                    ..where((l) => l.recipeId.equals(_id!))
                    ..orderBy([(l) => OrderingTerm.asc(l.sequence), (l) => OrderingTerm.asc(l.id)]))
                  .watch(),
              builder: (context, snap) {
                final lines = snap.data ?? [];
                if (lines.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('এখনো কোনো ইনগ্রিডিয়েন্ট নেই — Production Order বানাতে অন্তত একটি দরকার।',
                        style: TextStyle(color: Colors.red)),
                  );
                }
                return Column(
                  children: [
                    ...lines.map((l) {
                      final it = byId[l.itemId];
                      return Card(
                        child: ListTile(
                          dense: true,
                          title: Text(it == null ? 'Item #${l.itemId}' : '${it.itemCode} - ${it.itemName}'),
                          subtitle: Text('${fmtQty(l.qty)} ${l.unit}  •  Wastage ${fmtQty(l.wastagePercent)}%'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                            onPressed: () => _deleteLine(l),
                          ),
                        ),
                      );
                    }),
                    _costSummary(lines),
                  ],
                );
              },
            ),
          if (_id != null) ...[
            const Divider(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Packaging (১ কার্টুনে)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                OutlinedButton.icon(
                  onPressed: _addPackLine,
                  icon: const Icon(Icons.add),
                  label: const Text('যোগ করুন'),
                ),
              ],
            ),
            StreamBuilder<List<RecipePackLine>>(
              stream: (db.select(db.recipePackLines)..where((l) => l.recipeId.equals(_id!))).watch(),
              builder: (context, snap) {
                final pl = snap.data ?? [];
                if (pl.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('কার্টুন প্যাকিংয়ে কী কী লাগে তা যোগ করুন (কাপ, ঢাকনা, বক্স ইত্যাদি)।',
                        style: TextStyle(color: Colors.grey)),
                  );
                }
                return Column(
                  children: [
                    for (final l in pl)
                      Card(
                        child: ListTile(
                          dense: true,
                          title: Text(byId[l.itemId] == null
                              ? 'Item #${l.itemId}'
                              : '${byId[l.itemId]!.itemCode} - ${byId[l.itemId]!.itemName}'),
                          subtitle: Text('১ কার্টুনে ${fmtQty(l.qtyPerCarton)} ${byId[l.itemId]?.baseUnit ?? ''}'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                            onPressed: () => _deletePackLine(l),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}
