import 'package:drift/drift.dart' hide Batch, Column;
import '../database/app_database.dart';
import 'accounting_service.dart';
import 'production_math.dart';
import 'stock_service.dart';

class SaleResult {
  SaleResult(this.voucherId, this.revenue, this.cost);
  final int voucherId;
  final double revenue;
  final double cost;
  double get margin => round2(revenue - cost);
}

/// Sells stock (FEFO, never expired batches) and books the Sales voucher atomically.
class SalesService {
  SalesService(this.db);
  final AppDatabase db;

  Future<SaleResult> sell({
    required int itemId,
    required double qty,
    required double unitPrice,
    int? partyId,
    bool receivedNow = true,
    DateTime? date,
    String? narration,
  }) async {
    if (qty <= 0) throw ArgumentError('পরিমাণ ০ এর বেশি হতে হবে');
    if (unitPrice <= 0) throw ArgumentError('বিক্রয় মূল্য ০ এর বেশি হতে হবে');
    final stock = StockService(db);
    final when = date ?? DateTime.now();

    return db.transaction(() async {
      final item = await (db.select(db.items)..where((i) => i.id.equals(itemId))).getSingleOrNull();
      if (item == null) throw ArgumentError('আইটেম পাওয়া যায়নি');

      final allocs = await stock.planIssue(item, qty, now: when);
      final revenue = round2(qty * unitPrice);
      final cost = round2(allocs.fold<double>(0, (s, a) => s + a.qty * a.unitCost));

      final voucherId = await AccountingService(db).createSalesVoucher(
        amount: revenue,
        partyId: partyId,
        receivedNow: receivedNow,
        date: when,
        narration: narration ?? 'Sale: ${item.itemName} $qty ${item.baseUnit}',
      );
      await stock.applyIssue(
        itemId: itemId,
        allocations: allocs,
        voucherType: 'Sales',
        voucherId: voucherId,
        narration: narration ?? 'Sale',
        when: when,
      );
      return SaleResult(voucherId, revenue, cost);
    });
  }

  /// One invoice with many lines. All-or-nothing: stock short on any line cancels everything.
  Future<int> sellInvoice({
    required List<InvoiceLineInput> lines,
    int? partyId,
    bool receivedNow = true,
    DateTime? date,
    String? note,
  }) async {
    if (lines.isEmpty) throw ArgumentError('কমপক্ষে একটি আইটেম যোগ করুন');
    for (final l in lines) {
      if (l.qty <= 0) throw ArgumentError('পরিমাণ ০ এর বেশি হতে হবে');
      if (l.price <= 0) throw ArgumentError('মূল্য ০ এর বেশি হতে হবে');
    }
    final stock = StockService(db);
    final when = date ?? DateTime.now();

    return db.transaction(() async {
      final total = round2(lines.fold<double>(0, (s, l) => s + l.qty * l.price));
      final y = when.year.toString();
      final m = when.month.toString().padLeft(2, '0');
      final prefix = 'INV-$y$m-';
      final existing = await (db.select(db.saleInvoices)..where((i) => i.invoiceNo.like('$prefix%'))).get();
      var n = existing.length + 1;
      var no = '$prefix${n.toString().padLeft(4, '0')}';
      while (existing.any((e) => e.invoiceNo == no)) {
        n++;
        no = '$prefix${n.toString().padLeft(4, '0')}';
      }

      final voucherId = await AccountingService(db).createSalesVoucher(
        amount: total,
        partyId: partyId,
        receivedNow: receivedNow,
        date: when,
        narration: 'Invoice $no',
      );
      final invId = await db.into(db.saleInvoices).insert(SaleInvoicesCompanion.insert(
            invoiceNo: no,
            invoiceDate: when,
            total: total,
            partyId: Value(partyId),
            receivedNow: Value(receivedNow),
            note: Value(note),
            voucherId: Value(voucherId),
          ));
      for (final l in lines) {
        final item = await (db.select(db.items)..where((i) => i.id.equals(l.itemId))).getSingle();
        final allocs = await stock.planIssue(item, l.qty, now: when);
        await stock.applyIssue(
          itemId: l.itemId,
          allocations: allocs,
          voucherType: 'Sales',
          voucherId: voucherId,
          narration: 'Invoice $no',
          when: when,
        );
        await db.into(db.saleInvoiceLines).insert(SaleInvoiceLinesCompanion.insert(
              invoiceId: invId,
              itemId: l.itemId,
              itemName: item.itemName,
              unit: item.baseUnit,
              qty: l.qty,
              unitPrice: l.price,
              amount: round2(l.qty * l.price),
            ));
      }
      return invId;
    });
  }
}

class InvoiceLineInput {
  InvoiceLineInput(this.itemId, this.qty, this.price);
  final int itemId;
  final double qty;
  final double price;
}
