import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../database/app_database.dart';

/// Printable A4 sales invoice. Text is Latin (the PDF engine has no Bengali shaping);
/// non-Latin names fall back to their code.
class InvoicePdfService {
  static final _date = DateFormat('dd-MMM-yyyy');
  static final _num = NumberFormat('#,##0.##');

  static String _a(String? s, [String fallback = '']) {
    if (s == null || s.trim().isEmpty) return fallback;
    return s.runes.every((r) => r < 128) ? s : fallback;
  }

  static Future<Uint8List> build({
    required SaleInvoice invoice,
    required List<SaleInvoiceLine> lines,
    Party? party,
    String company = 'Ice Cream Factory',
  }) async {
    final doc = pw.Document();
    final bold = pw.TextStyle(fontWeight: pw.FontWeight.bold);
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text(company, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
              pw.Text('Sales Invoice', style: const pw.TextStyle(fontSize: 12, color: PdfColors.grey700)),
            ]),
            pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
              pw.Text('Invoice No: ${invoice.invoiceNo}', style: bold),
              pw.Text('Date: ${_date.format(invoice.invoiceDate)}'),
              pw.Text(invoice.receivedNow ? 'Status: PAID' : 'Status: DUE', style: bold),
            ]),
          ],
        ),
        pw.Divider(),
        pw.Text('Bill To', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        pw.Text(
          party == null
              ? 'Cash Sale'
              : _a(party.partyName, party.partyCode),
          style: bold,
        ),
        if (party != null && _a(party.phone).isNotEmpty) pw.Text('Phone: ${party.phone}'),
        if (party != null && _a(party.address).isNotEmpty) pw.Text(_a(party.address)),
        pw.SizedBox(height: 14),
        pw.TableHelper.fromTextArray(
          headers: ['SL', 'Item', 'Qty', 'Unit', 'Rate (Tk)', 'Amount (Tk)'],
          headerStyle: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
          cellStyle: const pw.TextStyle(fontSize: 10),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
          cellAlignments: {
            0: pw.Alignment.center,
            1: pw.Alignment.centerLeft,
            2: pw.Alignment.centerRight,
            3: pw.Alignment.center,
            4: pw.Alignment.centerRight,
            5: pw.Alignment.centerRight,
          },
          data: [
            for (var i = 0; i < lines.length; i++)
              [
                '${i + 1}',
                _a(lines[i].itemName, 'Item #${lines[i].itemId}'),
                _num.format(lines[i].qty),
                lines[i].unit,
                _num.format(lines[i].unitPrice),
                _num.format(lines[i].amount),
              ]
          ],
        ),
        pw.SizedBox(height: 10),
        pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600)),
            child: pw.Text('Total: ${_num.format(invoice.total)} Tk',
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          ),
        ),
        if (_a(invoice.note).isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 8), child: pw.Text('Note: ${_a(invoice.note)}')),
        pw.SizedBox(height: 50),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [pw.Text('Received by: ____________'), pw.Text('Authorized signature: ____________')],
        ),
        pw.SizedBox(height: 18),
        pw.Center(child: pw.Text('Thank you for your business', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700))),
      ],
    ));
    return doc.save();
  }
}
