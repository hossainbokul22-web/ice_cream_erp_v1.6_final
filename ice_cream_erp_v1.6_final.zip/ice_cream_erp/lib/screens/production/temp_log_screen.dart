import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/alarm_service.dart';
import '../../services/audit_service.dart';
import '../../utils/ui.dart';

/// Default allowed range (min, max) in °C per kind of place.
const Map<String, (double, double)> kTempDefaults = {
  'Batch Freezer': (-9.0, -3.0),
  'Aging Tank': (2.0, 8.0),
  'Hardening Room': (-45.0, -25.0),
  'Cold Storage': (-30.0, -18.0),
  'Display Freezer': (-25.0, -15.0),
};

/// Latest reading of each place in the last 24 h that is OUT of range (resolved ones disappear).
final tempAlertsProvider = StreamProvider<List<TempLog>>((ref) {
  final db = ref.watch(databaseProvider);
  final since = DateTime.now().subtract(const Duration(hours: 24));
  return (db.select(db.tempLogs)
        ..where((t) => t.loggedAt.isBiggerOrEqualValue(since))
        ..orderBy([(t) => OrderingTerm.desc(t.loggedAt), (t) => OrderingTerm.desc(t.id)]))
      .watch()
      .map((rows) {
    final seen = <String>{};
    final bad = <TempLog>[];
    for (final r in rows) {
      if (seen.add(r.location) && !r.isOk) bad.add(r);
    }
    return bad;
  });
});

/// Red banner (Dashboard) when a place was last measured outside its limit.
class TempAlertBanner extends ConsumerWidget {
  const TempAlertBanner({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bad = ref.watch(tempAlertsProvider).valueOrNull ?? <TempLog>[];
    if (bad.isEmpty) return const SizedBox.shrink();
    final first = bad.first;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => context.push('/templog'),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFD94B4B),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(children: [
            const Icon(Icons.thermostat_rounded, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Temperature alert: ${first.location} ${fmtQty(first.tempC)}°C (limit ${fmtQty(first.minC)} to ${fmtQty(first.maxC)})'
                '${bad.length > 1 ? '  +${bad.length - 1} more' : ''}',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5),
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white),
          ]),
        ),
      ),
    );
  }
}

class _Loc {
  const _Loc(this.name, this.kind);
  final String name;
  final String kind;
}

/// Manual temperature log with limits and an alert when a reading is out of range.
class TempLogScreen extends ConsumerStatefulWidget {
  const TempLogScreen({super.key});

  @override
  ConsumerState<TempLogScreen> createState() => _TempLogScreenState();
}

class _TempLogScreenState extends ConsumerState<TempLogScreen> {
  List<_Loc> _locs = [];
  int _sel = 0;
  final _temp = TextEditingController();
  final _min = TextEditingController();
  final _max = TextEditingController();
  final _note = TextEditingController();
  DateTime _day = DateTime.now();
  List<TempLog> _rows = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _temp.dispose();
    _min.dispose();
    _max.dispose();
    _note.dispose();
    super.dispose();
  }

  void _applyLimits() {
    if (_locs.isEmpty) return;
    final d = kTempDefaults[_locs[_sel].kind] ?? (-30.0, 10.0);
    _min.text = fmtQty(d.$1);
    _max.text = fmtQty(d.$2);
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    if (_locs.isEmpty) {
      final fz = await (db.select(db.freezers)
            ..where((f) => f.isActive.equals(true))
            ..orderBy([(f) => OrderingTerm.asc(f.freezerCode)]))
          .get();
      final tk = await (db.select(db.tanks)
            ..where((t) => t.tankType.equals('Aging'))
            ..orderBy([(t) => OrderingTerm.asc(t.tankCode)]))
          .get();
      _locs = [
        for (final f in fz) _Loc('Freezer ${f.freezerCode}', 'Batch Freezer'),
        for (final t in tk) _Loc('Aging ${t.tankCode}', 'Aging Tank'),
        const _Loc('Hardening Room', 'Hardening Room'),
        const _Loc('Cold Storage', 'Cold Storage'),
        const _Loc('Display Freezer', 'Display Freezer'),
      ];
      _applyLimits();
    }
    final start = DateTime(_day.year, _day.month, _day.day);
    final rows = await (db.select(db.tempLogs)
          ..where((t) => t.loggedAt.isBiggerOrEqualValue(start) & t.loggedAt.isSmallerThanValue(start.add(const Duration(days: 1))))
          ..orderBy([(t) => OrderingTerm.desc(t.loggedAt)]))
        .get();
    if (mounted) {
      setState(() {
        _rows = rows;
        _loaded = true;
      });
    }
  }

  Future<void> _save() async {
    final t = parseNum(_temp.text);
    final mn = parseNum(_min.text);
    final mx = parseNum(_max.text);
    if (t == null) {
      showSnack(context, 'Enter the temperature');
      return;
    }
    if (mn == null || mx == null || mn > mx) {
      showSnack(context, 'Set the limits correctly (min must not be above max)');
      return;
    }
    final loc = _locs[_sel];
    final ok = t >= mn && t <= mx;
    final db = ref.read(databaseProvider);
    final done = await runGuarded(context, () async {
      await db.into(db.tempLogs).insert(TempLogsCompanion.insert(
            location: loc.name,
            kind: loc.kind,
            tempC: t,
            minC: mn,
            maxC: mx,
            isOk: Value(ok),
            userName: Value(Audit.user),
            note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
          ));
      await Audit.write(db, ok ? 'Temperature logged' : 'TEMPERATURE ALERT',
          '${loc.name} ${fmtQty(t)}°C (limit ${fmtQty(mn)} to ${fmtQty(mx)})');
    });
    if (!done || !mounted) return;
    _temp.clear();
    _note.clear();
    if (!ok) {
      AlarmService.ring();
      showSnack(context, 'ALERT: ${loc.name} is ${fmtQty(t)}°C — outside ${fmtQty(mn)} to ${fmtQty(mx)}');
    } else {
      showSnack(context, 'Saved — within limit');
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Temperature Log'), actions: [
        IconButton(
          icon: const Icon(Icons.calendar_today),
          onPressed: () async {
            final d = await pickDate(context, _day, last: DateTime.now());
            if (d != null) {
              _day = d;
              await _load();
            }
          },
        ),
      ]),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('New reading', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                const SizedBox(height: 8),
                DropdownButtonFormField<int>(
                  isExpanded: true,
                  value: _sel,
                  decoration: const InputDecoration(labelText: 'Where?'),
                  items: [for (var i = 0; i < _locs.length; i++) DropdownMenuItem(value: i, child: Text(_locs[i].name))],
                  onChanged: (v) => setState(() {
                    _sel = v ?? 0;
                    _applyLimits();
                  }),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _temp,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: const InputDecoration(labelText: 'Temperature (°C)'),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _min,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                      decoration: const InputDecoration(labelText: 'Limit min °C'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _max,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                      decoration: const InputDecoration(labelText: 'Limit max °C'),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                TextField(controller: _note, decoration: const InputDecoration(labelText: 'Note (optional)')),
                const SizedBox(height: 10),
                FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save reading')),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text('Readings on ${fmtDate(_day)}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 4),
          if (_rows.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('No readings on this day')),
          for (final r in _rows)
            Card(
              color: r.isOk ? null : const Color(0xFFD94B4B).withAlpha(40),
              child: ListTile(
                dense: true,
                leading: Icon(r.isOk ? Icons.check_circle : Icons.warning_amber_rounded,
                    color: r.isOk ? Colors.green : const Color(0xFFD94B4B)),
                title: Text('${r.location}: ${fmtQty(r.tempC)}°C'),
                subtitle: Text('${fmtDateTime(r.loggedAt)} • limit ${fmtQty(r.minC)} to ${fmtQty(r.maxC)}'
                    '${r.userName.isEmpty ? '' : ' • ${r.userName}'}${r.note == null ? '' : ' • ${r.note}'}'),
              ),
            ),
        ],
      ),
    );
  }
}
