import 'package:flutter/material.dart';

const Color _pipeBase = Color(0xFFA9BBD0);
const Color _pipeInner = Color(0xFFE6EEF7);
const Color _fluid = Color(0xFF2D7BF0);
const Color _vOpen = Color(0xFF2EA86B);
const Color _vShut = Color(0xFFD94B4B);
const Color _vReady = Color(0xFFE59A12);

void _pipe(Canvas canvas, Offset a, Offset b, bool active, double phase) {
  final base = Paint()
    ..color = _pipeBase
    ..style = PaintingStyle.stroke
    ..strokeWidth = 7
    ..strokeCap = StrokeCap.butt;
  canvas.drawLine(a, b, base);
  final inner = Paint()
    ..color = active ? _fluid : _pipeInner
    ..style = PaintingStyle.stroke
    ..strokeWidth = 3.4
    ..strokeCap = StrokeCap.butt;
  canvas.drawLine(a, b, inner);
  if (active) {
    final len = (b - a).distance;
    if (len < 1) return;
    final dir = (b - a) / len;
    const gap = 11.0;
    final dot = Paint()..color = Colors.white;
    var t = (phase * gap) % gap;
    while (t < len) {
      canvas.drawCircle(a + dir * t, 1.6, dot);
      t += gap;
    }
  }
}

/// Gate valve glyph on a vertical pipe: bow-tie + stem + hand-wheel.
void _valve(Canvas canvas, Offset c, Color col) {
  final fill = Paint()..color = col;
  final edge = Paint()
    ..color = Colors.white
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.2;
  final top = Path()
    ..moveTo(c.dx - 7, c.dy - 7)
    ..lineTo(c.dx + 7, c.dy - 7)
    ..lineTo(c.dx, c.dy)
    ..close();
  final bot = Path()
    ..moveTo(c.dx - 7, c.dy + 7)
    ..lineTo(c.dx + 7, c.dy + 7)
    ..lineTo(c.dx, c.dy)
    ..close();
  canvas.drawPath(top, fill);
  canvas.drawPath(bot, fill);
  canvas.drawPath(top, edge);
  canvas.drawPath(bot, edge);
  final stem = Paint()
    ..color = const Color(0xFF34475E)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2;
  canvas.drawLine(c, Offset(c.dx + 10, c.dy), stem);
  canvas.drawLine(Offset(c.dx + 10, c.dy - 4), Offset(c.dx + 10, c.dy + 4), stem);
}

/// One tank's pipe segment: header pipe + drop with a valve.
/// [feed] true = header is above the tank (inlet); false = header below (outlet collector).
class PipeCellPainter extends CustomPainter {
  PipeCellPainter(
    this.anim, {
    required this.feed,
    required this.open,
    required this.ready,
    required this.headerOn,
    required this.first,
    required this.last,
  }) : super(repaint: anim);

  final Animation<double> anim;
  final bool feed;
  final bool open;
  final bool ready;
  final bool headerOn;
  final bool first;
  final bool last;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;
    final hy = feed ? 4.0 : h - 4.0;
    final phase = anim.value;
    final x0 = first ? cx : 0.0;
    final x1 = last ? cx : w;
    _pipe(canvas, Offset(x0, hy), Offset(x1, hy), headerOn, phase);
    if (feed) {
      _pipe(canvas, Offset(cx, hy), Offset(cx, h), open, phase);
    } else {
      _pipe(canvas, Offset(cx, 0), Offset(cx, hy), open, phase);
    }
    final vy = feed ? h * 0.52 : h * 0.46;
    _valve(canvas, Offset(cx, vy), open ? _vOpen : (ready ? _vReady : _vShut));
  }

  @override
  bool shouldRepaint(PipeCellPainter o) =>
      o.feed != feed || o.open != open || o.ready != ready || o.headerOn != headerOn || o.first != first || o.last != last;
}

/// Plain vertical connecting pipe (centre of the row), optionally flowing.
class StemPainter extends CustomPainter {
  StemPainter(this.anim, this.active) : super(repaint: anim);
  final Animation<double> anim;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    _pipe(canvas, Offset(cx, -4), Offset(cx, size.height + 4), active, anim.value);
  }

  @override
  bool shouldRepaint(StemPainter o) => o.active != active;
}

/// Small pipe stub with a valve (used above each freezer).
class ValveStubPainter extends CustomPainter {
  ValveStubPainter(this.anim, this.open) : super(repaint: anim);
  final Animation<double> anim;
  final bool open;

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    _pipe(canvas, Offset(cx, 0), Offset(cx, size.height), open, anim.value);
    _valve(canvas, Offset(cx, size.height / 2), open ? _vOpen : _vShut);
  }

  @override
  bool shouldRepaint(ValveStubPainter o) => o.open != open;
}
