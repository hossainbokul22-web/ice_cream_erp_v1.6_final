import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../utils/ui.dart';

/// Who did what and when (latest 500 entries).
class AuditLogScreen extends ConsumerStatefulWidget {
  const AuditLogScreen({super.key});

  @override
  ConsumerState<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _AuditLogScreenState extends ConsumerState<AuditLogScreen> {
  List<AuditLog> _rows = [];
  bool _loading = true;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    final rows = await (db.select(db.auditLogs)
          ..orderBy([(a) => OrderingTerm.desc(a.id)])
          ..limit(500))
        .get();
    if (mounted) {
      setState(() {
        _rows = rows;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _q.toLowerCase();
    final shown = q.isEmpty
        ? _rows
        : _rows.where((a) => '${a.userName} ${a.action} ${a.detail}'.toLowerCase().contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Audit Log'), actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                child: TextField(
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search user / action / detail'),
                  onChanged: (v) => setState(() => _q = v),
                ),
              ),
              Expanded(
                child: shown.isEmpty
                    ? const Center(child: Text('No entries'))
                    : ListView.builder(
                        itemCount: shown.length,
                        itemBuilder: (ctx, i) {
                          final a = shown[i];
                          return ListTile(
                            dense: true,
                            title: Text('${a.action}${a.detail.isEmpty ? '' : ' — ${a.detail}'}'),
                            subtitle: Text('${fmtDateTime(a.at)} • ${a.userName.isEmpty ? '(no login)' : a.userName}'),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}
