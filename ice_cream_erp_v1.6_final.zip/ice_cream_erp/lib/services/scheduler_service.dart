import '../database/app_database.dart';

class SchedRequest {
  SchedRequest(this.recipe, this.batches);
  final Recipe recipe;
  int batches;
}

class SchedRow {
  SchedRow({
    required this.recipe,
    required this.liters,
    this.mixTank,
    this.ageTank,
    this.freezer,
    this.mixStart,
    this.agingStart,
    this.agingEnd,
    this.freezeStart,
    this.freezeEnd,
    this.finish,
    this.problem,
  });
  final Recipe recipe;
  final double liters;
  final Tank? mixTank;
  final Tank? ageTank;
  final Freezer? freezer;
  final DateTime? mixStart;
  final DateTime? agingStart;
  final DateTime? agingEnd;
  final DateTime? freezeStart;
  final DateTime? freezeEnd;
  final DateTime? finish;
  final String? problem;

  bool get ok => problem == null && mixStart != null;
}

class _Res {
  _Res(this.free);
  DateTime free;
  int? lastRecipe;
}

/// Plans batches on the available mixing tanks, aging tanks and freezers.
/// Rules: a mixing tank is busy during mixing + pasteurization + homogenization; an aging tank is busy
/// from the transfer until the freezing of that batch ends; a freezer is busy during freezing;
/// a different flavor on the same equipment needs a changeover (cleaning) gap.
class SchedulerService {
  /// Minutes for mixing, pasteurization, homogenization, aging, freezing, hardening, packing.
  static List<double> minutesFor(Recipe r) {
    final out = <double>[5, 1, 5, r.agingHours * 60, 8, 120, 30];
    final parts = (r.stageMins ?? '').split(',');
    for (var i = 0; i < 7 && i < parts.length; i++) {
      final v = double.tryParse(parts[i].trim());
      if (v != null && v > 0) out[i] = v;
    }
    if (out[3] <= 0) out[3] = 60;
    return out;
  }

  static List<SchedRow> plan({
    required DateTime start,
    required List<SchedRequest> requests,
    required List<Tank> mixTanks,
    required List<Tank> ageTanks,
    required List<Freezer> freezers,
    int changeoverMin = 15,
  }) {
    final co = Duration(minutes: changeoverMin);
    final mix = {for (final t in mixTanks) t.id: _Res(start)};
    final age = {for (final t in ageTanks) t.id: _Res(start)};
    final frz = {for (final f in freezers) f.id: _Res(start)};

    Duration mins(double m) => Duration(seconds: (m * 60).round());
    DateTime later(DateTime a, DateTime b) => a.isAfter(b) ? a : b;
    DateTime freeFor(_Res r, int recipeId) =>
        (r.lastRecipe != null && r.lastRecipe != recipeId) ? r.free.add(co) : r.free;

    final rows = <SchedRow>[];
    for (final rq in requests) {
      final r = rq.recipe;
      final liters = r.baseQty;
      final m = minutesFor(r);
      final d1 = mins(m[0] + m[1] + m[2]);
      final mixBefore = mins(m[0]);
      for (var b = 0; b < rq.batches; b++) {
        final mts = mixTanks.where((t) => t.capacityLiter >= liters).toList();
        final ats = ageTanks.where((t) => t.capacityLiter >= liters).toList();
        final fzs = freezers.where((f) => f.capacityLiter <= 0 || f.capacityLiter >= liters).toList();
        if (mts.isEmpty) {
          rows.add(SchedRow(recipe: r, liters: liters, problem: 'No mixing tank with capacity of ${liters.toStringAsFixed(0)} L or more'));
          continue;
        }
        if (ats.isEmpty) {
          rows.add(SchedRow(recipe: r, liters: liters, problem: 'No aging tank with capacity of ${liters.toStringAsFixed(0)} L or more'));
          continue;
        }
        Tank? bestM;
        Tank? bestA;
        DateTime? bestS;
        for (final mt in mts) {
          for (final at in ats) {
            final s = later(later(start, freeFor(mix[mt.id]!, r.id)), freeFor(age[at.id]!, r.id).subtract(mixBefore));
            final better = bestS == null ||
                s.isBefore(bestS) ||
                (s == bestS && mt.capacityLiter + at.capacityLiter < bestM!.capacityLiter + bestA!.capacityLiter);
            if (better) {
              bestS = s;
              bestM = mt;
              bestA = at;
            }
          }
        }
        final startAt = bestS!;
        final a0 = startAt.add(d1);
        final a1 = a0.add(mins(m[3]));

        Freezer? bestF;
        DateTime? f0;
        for (final f in fzs) {
          final t = later(a1, freeFor(frz[f.id]!, r.id));
          if (f0 == null || t.isBefore(f0)) {
            f0 = t;
            bestF = f;
          }
        }
        mix[bestM!.id]!
          ..free = a0
          ..lastRecipe = r.id;
        if (bestF == null || f0 == null) {
          age[bestA!.id]!
            ..free = a1
            ..lastRecipe = r.id;
          rows.add(SchedRow(
            recipe: r,
            liters: liters,
            mixTank: bestM,
            ageTank: bestA,
            mixStart: startAt,
            agingStart: a0,
            agingEnd: a1,
            problem: 'No freezer available for ${liters.toStringAsFixed(0)} L — add a freezer',
          ));
          continue;
        }
        final f1 = f0.add(mins(m[4]));
        age[bestA!.id]!
          ..free = f1
          ..lastRecipe = r.id;
        frz[bestF.id]!
          ..free = f1
          ..lastRecipe = r.id;
        rows.add(SchedRow(
          recipe: r,
          liters: liters,
          mixTank: bestM,
          ageTank: bestA,
          freezer: bestF,
          mixStart: startAt,
          agingStart: a0,
          agingEnd: a1,
          freezeStart: f0,
          freezeEnd: f1,
          finish: f1.add(mins(m[5] + m[6])),
        ));
      }
    }
    return rows;
  }
}
