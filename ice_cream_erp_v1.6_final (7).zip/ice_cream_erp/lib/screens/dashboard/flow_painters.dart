import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Light, illustrated "modern ice cream plant" equipment, one painter for all
/// 10 steps. Logical canvas is 160 x 120 and is scaled to the widget size.
///
/// kind: 0 receiving truck, 1 mixing tank, 2 HTST plate pasteuriser,
/// 3 homogeniser, 4 aging tank, 5 batch freezer, 6 hardening cabinet,
/// 7 packaging line, 8 quality control, 9 cold storage.
/// state: 0 waiting, 1 running, 2 done. progress: 0..1 of the running step.
class FlowPainter extends CustomPainter {
  FlowPainter(this.kind, this.anim, this.state, this.progress, this.temp) : super(repaint: anim);

  final int kind;
  final Animation<double> anim;
  final int state;
  final double progress;
  final String temp;

  double get t => anim.value;
  bool get run => state == 1;
  double get ang => run ? t * 2 * math.pi : 0.0;

  static const _ink = Color(0xFF55636F);
  static const _navy = Color(0xFF0B3D91);
  static const _blue = Color(0xFF1E6BE0);
  static const _milk = Color(0xFFFFF3D6);
  static const _cold = Color(0xFF8FD0FF);

  // ---------- paint helpers ----------
  Paint _line([double w = 1.2, Color c = _ink]) => Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..color = c;

  Paint _solid(Color c) => Paint()..color = c;

  Paint _metal(Rect r, {bool vert = false}) => Paint()
    ..shader = LinearGradient(
      begin: vert ? Alignment.topCenter : Alignment.centerLeft,
      end: vert ? Alignment.bottomCenter : Alignment.centerRight,
      colors: const [Color(0xFF8E9BA8), Color(0xFFE3E9EF), Color(0xFFFFFFFF), Color(0xFFC5CED7), Color(0xFF7F8C99)],
      stops: const [0.0, 0.28, 0.48, 0.78, 1.0],
    ).createShader(r);

  Paint _blueMetal(Rect r) => Paint()
    ..shader = LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: const [Color(0xFF0F3F9E), Color(0xFF2F7BEF), Color(0xFF0F3F9E)],
    ).createShader(r);

  double _cl(double v) => v < 0 ? 0.0 : (v > 1 ? 1.0 : v);

  void _text(Canvas c, String s, Offset o, double size, Color col) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: size, color: col, fontWeight: FontWeight.w800)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, Offset(o.dx - tp.width / 2, o.dy - tp.height / 2));
  }

  void _floor(Canvas c) {
    c.drawOval(const Rect.fromLTWH(12, 104, 136, 10), _solid(const Color(0x1F0B3D91)));
  }

  void _panel(Canvas c, Rect r, {String? label}) {
    final rr = RRect.fromRectAndRadius(r, const Radius.circular(3));
    c.drawRRect(rr, _solid(const Color(0xFFDDE3E9)));
    c.drawRRect(rr, _line(0.8));
    final s = Rect.fromLTWH(r.left + 2, r.top + 2, r.width - 4, r.height * 0.42);
    final screen = state == 2
        ? const Color(0xFF38C172)
        : run
            ? Color.lerp(const Color(0xFF2E86FF), const Color(0xFF7DB8FF), 0.5 + 0.5 * math.sin(t * 2 * math.pi))!
            : const Color(0xFF9FB4C8);
    c.drawRect(s, _solid(screen));
    if (label != null && label.isNotEmpty) {
      _text(c, label, s.center, math.min(7.0, r.width / 4.2), Colors.white);
    }
    for (var i = 0; i < 3; i++) {
      final col = i == 0 ? const Color(0xFF2EBD59) : (i == 1 ? const Color(0xFFFFB300) : const Color(0xFFE53935));
      c.drawCircle(Offset(r.left + 5 + i * ((r.width - 10) / 2), r.bottom - 5), 1.7, _solid(col));
    }
  }

  void _wheel(Canvas c, Offset o) {
    c.drawCircle(o, 9, _solid(const Color(0xFF263038)));
    c.drawCircle(o, 5, _solid(const Color(0xFFB9C3CC)));
    for (var i = 0; i < 3; i++) {
      final a = ang * 2 + i * math.pi / 1.5;
      c.drawLine(o, o + Offset(math.cos(a), math.sin(a)) * 4.5, _line(1, const Color(0xFF55636F)));
    }
    c.drawCircle(o, 1.6, _solid(const Color(0xFF263038)));
  }

  void _gauge(Canvas c, Offset o, double r, double v) {
    c.drawCircle(o, r + 2, _solid(const Color(0xFF7F8C99)));
    c.drawCircle(o, r, _solid(Colors.white));
    for (var i = 0; i <= 8; i++) {
      final a = math.pi * 0.75 + i * (math.pi * 1.5 / 8);
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(o + d * (r - 4), o + d * (r - 1), _line(0.8));
    }
    final a = math.pi * 0.75 + _cl(v) * math.pi * 1.5;
    c.drawLine(o, o + Offset(math.cos(a), math.sin(a)) * (r - 3), _line(1.4, const Color(0xFFD32F2F)));
    c.drawCircle(o, 1.8, _solid(const Color(0xFF333333)));
  }

  void _snow(Canvas c, Offset o, double r, double rot, Color col) {
    for (var i = 0; i < 6; i++) {
      final a = rot + i * math.pi / 3;
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(o, o + d * r, _line(1.3, col));
      final m = o + d * (r * 0.62);
      final b1 = a + 0.7;
      final b2 = a - 0.7;
      c.drawLine(m, m + Offset(math.cos(b1), math.sin(b1)) * (r * 0.3), _line(1, col));
      c.drawLine(m, m + Offset(math.cos(b2), math.sin(b2)) * (r * 0.3), _line(1, col));
    }
  }

  void _pipe(Canvas c, Offset a, Offset b, {Color col = const Color(0xFF9AA7B3)}) {
    c.drawLine(a, b, _line(5, const Color(0xFF6E7B87)));
    c.drawLine(a, b, _line(3.6, col));
    c.drawLine(a + const Offset(0, -1), b + const Offset(0, -1), _line(1, Colors.white.withAlpha(160)));
  }

  void _flowDots(Canvas c, Offset a, Offset b, Color col, {int n = 4, double r = 1.9}) {
    if (!run) return;
    for (var i = 0; i < n; i++) {
      final p = (t * 1.0 + i / n) % 1.0;
      c.drawCircle(Offset.lerp(a, b, p)!, r, _solid(col));
    }
  }

  void _motor(Canvas c, double cx, double top) {
    final r = Rect.fromLTWH(cx - 9, top, 18, 14);
    c.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(3)), _blueMetal(r));
    for (var i = 0; i < 4; i++) {
      c.drawLine(Offset(cx - 6 + i * 4, top + 2), Offset(cx - 6 + i * 4, top + 12), _line(0.7, Colors.white.withAlpha(120)));
    }
    c.drawRect(Rect.fromLTWH(cx - 3, top + 14, 6, 5), _solid(const Color(0xFF7F8C99)));
  }

  void _tank(Canvas c, double cx, double top, double w, double h,
      {required bool motor, required Color liquid, required double level, double spin = 1.0}) {
    final r = Rect.fromLTWH(cx - w / 2, top, w, h);
    final body = RRect.fromRectAndCorners(
      r,
      topLeft: Radius.circular(w * 0.18),
      topRight: Radius.circular(w * 0.18),
      bottomLeft: Radius.circular(w * 0.32),
      bottomRight: Radius.circular(w * 0.32),
    );
    // legs
    c.drawRect(Rect.fromLTWH(r.left + w * 0.14, r.bottom - 3, 4, 15), _solid(const Color(0xFF7F8C99)));
    c.drawRect(Rect.fromLTWH(r.right - w * 0.14 - 4, r.bottom - 3, 4, 15), _solid(const Color(0xFF7F8C99)));
    c.drawRRect(body, _metal(r));
    // liquid + agitator inside the shell
    c.save();
    c.clipRRect(body.deflate(3.5));
    final lvl = _cl(level);
    if (lvl > 0.01) {
      final y0 = r.bottom - h * lvl;
      final path = Path()..moveTo(r.left, r.bottom + 2);
      for (double x = r.left; x <= r.right; x += 2) {
        final y = y0 + (run ? 1.8 * math.sin(x / 7 + t * 2 * math.pi) : 0.0);
        path.lineTo(x, y);
      }
      path
        ..lineTo(r.right, r.bottom + 2)
        ..close();
      c.drawPath(path, _solid(liquid.withAlpha(215)));
      // shine on liquid
      c.drawRect(Rect.fromLTWH(r.left + w * 0.18, y0 + 3, 3, h * lvl * 0.5), _solid(Colors.white.withAlpha(70)));
    }
    final shaftTop = r.top + 2;
    c.drawLine(Offset(cx, shaftTop), Offset(cx, r.bottom - h * 0.16), _line(1.8, const Color(0xFF55636F)));
    final a = math.cos(ang * 2 * spin);
    final b = math.sin(ang * 2 * spin + 1.2);
    final bw = w * 0.34;
    c.drawLine(Offset(cx - bw * a, r.bottom - h * 0.22), Offset(cx + bw * a, r.bottom - h * 0.22), _line(2.6, const Color(0xFF55636F)));
    c.drawLine(Offset(cx - bw * 0.8 * b, r.bottom - h * 0.46), Offset(cx + bw * 0.8 * b, r.bottom - h * 0.46), _line(2.2, const Color(0xFF55636F)));
    c.restore();
    c.drawRRect(body, _line(1.1));
    // lid ellipse
    final lid = Rect.fromLTWH(r.left + 2, r.top - 4, w - 4, 9);
    c.drawOval(lid, _metal(lid));
    c.drawOval(lid, _line(0.9));
    if (motor) _motor(c, cx, r.top - 19);
    // manway
    c.drawCircle(Offset(cx + w * 0.22, r.top + h * 0.28), 3.2, _solid(const Color(0xFFCBD3DB)));
    c.drawCircle(Offset(cx + w * 0.22, r.top + h * 0.28), 3.2, _line(0.8));
  }

  // ---------- kinds ----------
  void _receiving(Canvas c) {
    _floor(c);
    final bob = run ? math.sin(t * 2 * math.pi * 3) * 0.8 : 0.0;
    c.save();
    c.translate(0, bob);
    final tank = Rect.fromLTWH(10, 34, 96, 48);
    final rr = RRect.fromRectAndRadius(tank, const Radius.circular(24));
    c.drawRRect(rr, _metal(tank, vert: true));
    c.drawRRect(rr, _line(1));
    for (final x in const [34.0, 58.0, 82.0]) {
      c.drawLine(Offset(x, 36), Offset(x, 80), _line(0.7, const Color(0xFFAAB5C0)));
    }
    final hatch = const Rect.fromLTWH(52, 29, 18, 7);
    c.drawOval(hatch, _solid(const Color(0xFFB8C2CC)));
    c.drawOval(hatch, _line(0.8));
    c.drawRect(const Rect.fromLTWH(8, 82, 138, 6), _solid(const Color(0xFF3B4650)));
    final cab = Path()
      ..moveTo(108, 46)
      ..lineTo(130, 46)
      ..lineTo(146, 66)
      ..lineTo(146, 88)
      ..lineTo(108, 88)
      ..close();
    c.drawPath(cab, _solid(const Color(0xFF1E5FD0)));
    c.drawPath(cab, _line(1, _navy));
    final win = Path()
      ..moveTo(114, 51)
      ..lineTo(128, 51)
      ..lineTo(139, 65)
      ..lineTo(114, 65)
      ..close();
    c.drawPath(win, _solid(const Color(0xFFCFE8FF)));
    c.drawRect(const Rect.fromLTWH(140, 78, 6, 4), _solid(const Color(0xFFFFE082)));
    for (final x in const [30.0, 52.0, 122.0]) {
      _wheel(c, Offset(x, 92));
    }
    c.restore();
    // outlet hose with falling milk
    c.drawLine(const Offset(10, 74), const Offset(5, 74), _line(3, const Color(0xFF3B4650)));
    if (run) {
      for (var i = 0; i < 3; i++) {
        final p = (t + i / 3) % 1.0;
        c.drawCircle(Offset(5, 76 + p * 26), 2.2, _solid(Colors.white));
        c.drawCircle(Offset(5, 76 + p * 26), 2.2, _line(0.6, _cold));
      }
    }
  }

  void _mixing(Canvas c) {
    _floor(c);
    final lvl = state == 0 ? 0.06 : (state == 2 ? 0.8 : 0.22 + 0.58 * progress);
    _pipe(c, const Offset(4, 70), const Offset(52, 70));
    _flowDots(c, const Offset(4, 70), const Offset(52, 70), _milk);
    _tank(c, 80, 34, 60, 62, motor: true, liquid: const Color(0xFFFFE9B8), level: lvl, spin: 1.0);
    _pipe(c, const Offset(108, 84), const Offset(156, 84));
    _panel(c, const Rect.fromLTWH(122, 38, 24, 30));
  }

  void _pasteuriser(Canvas c) {
    _floor(c);
    final frame = const Rect.fromLTWH(26, 26, 96, 68);
    c.drawRRect(RRect.fromRectAndRadius(frame, const Radius.circular(4)), _metal(frame, vert: true));
    c.drawRect(const Rect.fromLTWH(20, 20, 108, 7), _metal(const Rect.fromLTWH(20, 20, 108, 7), vert: true));
    c.drawRect(const Rect.fromLTWH(20, 20, 108, 7), _line(0.8));
    for (var i = 0; i < 13; i++) {
      final x = 32.0 + i * 6.6;
      c.drawRect(Rect.fromLTWH(x, 30, 3.6, 60), _solid(i.isEven ? const Color(0xFFC9D3DC) : const Color(0xFFEEF2F6)));
    }
    c.drawRect(const Rect.fromLTWH(26, 28, 5, 64), _solid(const Color(0xFF7F8C99)));
    c.drawRect(const Rect.fromLTWH(117, 28, 5, 64), _solid(const Color(0xFF7F8C99)));
    c.drawRRect(RRect.fromRectAndRadius(frame, const Radius.circular(4)), _line(1));
    // in (hot) / out (cold) pipes
    _pipe(c, const Offset(4, 36), const Offset(26, 36), col: const Color(0xFFFF8A65));
    _pipe(c, const Offset(122, 84), const Offset(156, 84), col: const Color(0xFF64B5F6));
    if (run) {
      for (var i = 0; i < 6; i++) {
        final p = (t + i / 6) % 1.0;
        final x = 34.0 + i * 12.5;
        final y = i.isEven ? 32 + p * 56 : 88 - p * 56;
        c.drawCircle(Offset(x, y), 2.1, _solid(i.isEven ? const Color(0xFFFF7043) : const Color(0xFF42A5F5)));
      }
      // steam
      for (var k = 0; k < 3; k++) {
        final p = (t + k / 3) % 1.0;
        c.drawCircle(Offset(44.0 + k * 22, 18 - p * 14), 2.6 + p * 2, _solid(Colors.white.withAlpha((200 * (1 - p)).round())));
      }
    }
    _panel(c, const Rect.fromLTWH(128, 28, 26, 34), label: temp);
  }

  void _homogeniser(Canvas c) {
    _floor(c);
    final body = const Rect.fromLTWH(16, 52, 108, 44);
    c.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(5)), _metal(body));
    c.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(5)), _line(1));
    final head = const Rect.fromLTWH(100, 40, 36, 56);
    c.drawRRect(RRect.fromRectAndRadius(head, const Radius.circular(4)), _metal(head, vert: true));
    c.drawRRect(RRect.fromRectAndRadius(head, const Radius.circular(4)), _line(1));
    for (var i = 0; i < 3; i++) {
      final dy = run ? math.sin(t * 2 * math.pi * 2 + i * 2.1) * 4 : 0.0;
      final x = 26.0 + i * 20;
      final cyl = Rect.fromLTWH(x, 38 + dy, 11, 16);
      c.drawRect(cyl, _metal(cyl));
      c.drawRect(cyl, _line(0.8));
      c.drawRect(Rect.fromLTWH(x + 3, 29 + dy, 5, 10), _solid(const Color(0xFF9AA7B3)));
    }
    final pv = run ? 0.58 + 0.07 * math.sin(t * 2 * math.pi * 3) : (state == 2 ? 0.6 : 0.0);
    _gauge(c, const Offset(118, 26), 14, pv);
    _panel(c, const Rect.fromLTWH(30, 62, 44, 28), label: temp);
    _pipe(c, const Offset(2, 80), const Offset(16, 80));
    _pipe(c, const Offset(136, 86), const Offset(158, 86));
    _flowDots(c, const Offset(2, 80), const Offset(16, 80), _milk, n: 2);
    _flowDots(c, const Offset(136, 86), const Offset(158, 86), _milk, n: 2);
  }

  void _aging(Canvas c) {
    _floor(c);
    final lvl = state == 0 ? 0.08 : (state == 2 ? 0.8 : 0.75);
    _pipe(c, const Offset(4, 84), const Offset(52, 84));
    _tank(c, 80, 34, 60, 62, motor: true, liquid: const Color(0xFFFFF0C9), level: lvl, spin: 0.35);
    _pipe(c, const Offset(108, 70), const Offset(140, 70));
    // cooling jacket frost + thermometer panel
    _panel(c, const Rect.fromLTWH(118, 30, 28, 30), label: temp);
    if (state != 0) {
      _snow(c, const Offset(80, 50), 6, run ? t * 1.2 : 0.0, _blue.withAlpha(180));
    }
  }

  void _freezer(Canvas c) {
    _floor(c);
    final body = const Rect.fromLTWH(50, 26, 56, 62);
    final rr = RRect.fromRectAndRadius(body, const Radius.circular(10));
    c.drawRRect(
      rr,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [Color(0xFFA9D5EE), Color(0xFFFFFFFF), Color(0xFFB7DDF2)],
        ).createShader(body),
    );
    c.save();
    c.clipRRect(rr.deflate(3));
    final lvl = state == 0 ? 0.1 : (state == 2 ? 0.85 : 0.2 + 0.65 * progress);
    final y0 = body.bottom - body.height * lvl;
    c.drawRect(Rect.fromLTRB(body.left, y0, body.right, body.bottom), _solid(_milk));
    final cx = body.center.dx;
    for (var k = 0; k < 3; k++) {
      final off = math.cos(ang * 3 + k * 2.09) * 17;
      c.drawLine(Offset(cx + off, body.top + 6), Offset(cx + off, body.bottom - 6), _line(2.6, const Color(0xFF7F8C99)));
    }
    c.drawLine(Offset(cx, body.top), Offset(cx, body.bottom), _line(2.2, const Color(0xFF55636F)));
    c.restore();
    c.drawRRect(rr, _line(1.1));
    _motor(c, body.center.dx, body.top - 18);
    // frost sparkles
    if (state != 0) {
      for (var i = 0; i < 6; i++) {
        final p = (t * 1.5 + i / 6) % 1.0;
        final a = 0.4 + 0.6 * math.sin(p * math.pi);
        c.drawCircle(Offset(body.left + 6 + (i * 9) % 44, body.top + 8 + (i * 13) % 50), 1.3, _solid(Colors.white.withAlpha((255 * a).round())));
      }
    }
    // air injection arrow
    final arrow = Path()
      ..moveTo(106, 46)
      ..lineTo(118, 46)
      ..moveTo(106, 46)
      ..lineTo(112, 42)
      ..moveTo(106, 46)
      ..lineTo(112, 50);
    c.drawPath(arrow, _line(1.6, _blue));
    _pipe(c, const Offset(158, 46), const Offset(118, 46), col: const Color(0xFFBFE3FF));
    if (run) {
      for (var i = 0; i < 4; i++) {
        final p = (t + i / 4) % 1.0;
        c.drawCircle(Offset(156 - p * 46, 46 + math.sin(p * 9) * 2), 1.7, _solid(Colors.white));
        c.drawCircle(Offset(156 - p * 46, 46 + math.sin(p * 9) * 2), 1.7, _line(0.6, _blue));
      }
    }
    _text(c, 'AIR', const Offset(138, 36), 6.5, _navy);
    _pipe(c, const Offset(106, 82), const Offset(158, 82), col: _milk);
    _flowDots(c, const Offset(106, 82), const Offset(158, 82), Colors.white);
    _panel(c, const Rect.fromLTWH(14, 38, 28, 34), label: temp);
  }

  void _hardening(Canvas c) {
    _floor(c);
    final body = const Rect.fromLTWH(10, 24, 140, 72);
    c.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(5)), _metal(body));
    c.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(5)), _line(1.1));
    for (var i = 0; i < 3; i++) {
      final d = Rect.fromLTWH(16.0 + i * 45, 30, 41, 62);
      c.drawRRect(RRect.fromRectAndRadius(d, const Radius.circular(3)), _metal(d, vert: true));
      c.drawRRect(RRect.fromRectAndRadius(d, const Radius.circular(3)), _line(0.9));
      c.drawRect(Rect.fromLTWH(d.right - 7, d.center.dy - 8, 2.6, 16), _solid(const Color(0xFF55636F)));
    }
    // door 1: snowflake
    c.drawCircle(const Offset(36, 52), 13, _solid(const Color(0xFFE6F4FF)));
    _snow(c, const Offset(36, 52), 10, run ? t * 1.5 : 0.0, _blue);
    // door 2: temperature display
    final scr = const Rect.fromLTWH(66, 40, 36, 16);
    c.drawRRect(RRect.fromRectAndRadius(scr, const Radius.circular(2)), _solid(const Color(0xFF0E2A47)));
    _text(c, temp, scr.center, 8, const Color(0xFF58E6FF));
    c.drawCircle(const Offset(84, 72), 3, _solid(run ? const Color(0xFF2EBD59) : const Color(0xFF9FB4C8)));
    // door 3: fan window
    c.drawCircle(const Offset(126, 58), 14, _solid(Colors.white));
    c.drawCircle(const Offset(126, 58), 14, _line(1.1));
    for (var i = 0; i < 4; i++) {
      final a = ang * 3 + i * math.pi / 2;
      final p1 = const Offset(126, 58) + Offset(math.cos(a), math.sin(a)) * 11;
      final p2 = const Offset(126, 58) + Offset(math.cos(a + 0.5), math.sin(a + 0.5)) * 6;
      final blade = Path()
        ..moveTo(126, 58)
        ..lineTo(p1.dx, p1.dy)
        ..lineTo(p2.dx, p2.dy)
        ..close();
      c.drawPath(blade, _solid(const Color(0xFF7FB6E8)));
    }
    c.drawCircle(const Offset(126, 58), 2, _solid(const Color(0xFF263038)));
    if (state != 0) {
      for (var i = 0; i < 5; i++) {
        final p = (t + i / 5) % 1.0;
        c.drawCircle(Offset(18.0 + i * 32, 100 + p * 4), 1.6, _solid(_cold.withAlpha((200 * (1 - p)).round())));
      }
    }
  }

  void _packaging(Canvas c) {
    _floor(c);
    final frame = const Rect.fromLTWH(34, 12, 58, 62);
    c.drawRRect(RRect.fromRectAndRadius(frame, const Radius.circular(5)), _metal(frame));
    c.drawRRect(RRect.fromRectAndRadius(frame, const Radius.circular(5)), _line(1));
    _panel(c, const Rect.fromLTWH(40, 20, 20, 24));
    // film roll
    final roll = const Offset(116, 30);
    c.drawCircle(roll, 15, _solid(const Color(0xFFF4E7C8)));
    c.drawCircle(roll, 15, _line(1.1));
    c.drawCircle(roll, 5, _solid(const Color(0xFF9AA7B3)));
    final ra = ang * 1.2;
    c.drawLine(roll, roll + Offset(math.cos(ra), math.sin(ra)) * 12, _line(1.1, const Color(0xFFC9B58A)));
    c.drawLine(const Offset(101, 30), const Offset(92, 40), _line(1.6, const Color(0xFFF4E7C8)));
    // nozzle
    c.drawRect(const Rect.fromLTWH(60, 74, 10, 8), _solid(const Color(0xFF7F8C99)));
    // conveyor
    final belt = const Rect.fromLTWH(6, 90, 148, 10);
    c.drawRRect(RRect.fromRectAndRadius(belt, const Radius.circular(5)), _solid(const Color(0xFF3B4650)));
    for (var i = 0; i < 12; i++) {
      final x = 12.0 + ((i * 12 + (run ? t * 12 : 0.0)) % 140);
      c.drawLine(Offset(x, 91), Offset(x, 99), _line(0.8, const Color(0xFF5A6772)));
    }
    c.drawCircle(const Offset(10, 95), 6, _solid(const Color(0xFF55636F)));
    c.drawCircle(const Offset(150, 95), 6, _solid(const Color(0xFF55636F)));
    // cups moving
    final shift = run ? t * 40 : 0.0;
    for (var i = 0; i < 5; i++) {
      final x = ((i * 40 + shift) % 160) - 10;
      final col = i.isEven ? const Color(0xFFFFFFFF) : const Color(0xFFFFC7DA);
      final cup = Path()
        ..moveTo(x - 8, 76)
        ..lineTo(x + 8, 76)
        ..lineTo(x + 6, 90)
        ..lineTo(x - 6, 90)
        ..close();
      c.drawPath(cup, _solid(col));
      c.drawPath(cup, _line(0.9, const Color(0xFF7F8C99)));
      c.drawRect(Rect.fromLTWH(x - 7, 76, 14, 3), _solid(_blue));
    }
    if (run) {
      final p = (t * 2) % 1.0;
      c.drawCircle(Offset(65, 83 + p * 6), 1.8, _solid(_milk));
    }
  }

  void _quality(Canvas c) {
    _floor(c);
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(6, 86, 148, 9), const Radius.circular(3)), _solid(const Color(0xFFD7C4A3)));
    // monitor
    final mon = const Rect.fromLTWH(46, 24, 60, 42);
    c.drawRRect(RRect.fromRectAndRadius(mon, const Radius.circular(3)), _solid(const Color(0xFF2F3A44)));
    final scr = const Rect.fromLTWH(50, 28, 52, 34);
    c.drawRect(scr, _solid(const Color(0xFFE8F5FF)));
    final path = Path();
    for (double x = 0; x <= 50; x += 2) {
      final y = 45 + math.sin(x / 6 + (run ? t * 2 * math.pi : 0.0)) * 7 * (x / 50 + 0.3);
      if (x == 0) {
        path.moveTo(51 + x, y);
      } else {
        path.lineTo(51 + x, y);
      }
    }
    c.drawPath(path, _line(1.4, _blue));
    c.drawRect(const Rect.fromLTWH(56, 66, 8, 8), _solid(const Color(0xFF55636F)));
    c.drawRect(const Rect.fromLTWH(60, 72, 28, 14), _solid(const Color(0xFF6E7B87)));
    c.drawRect(const Rect.fromLTWH(54, 84, 40, 3), _solid(const Color(0xFF55636F)));
    // clipboard
    final cb = const Rect.fromLTWH(10, 50, 26, 36);
    c.drawRRect(RRect.fromRectAndRadius(cb, const Radius.circular(2)), _solid(Colors.white));
    c.drawRRect(RRect.fromRectAndRadius(cb, const Radius.circular(2)), _line(0.9));
    c.drawRect(const Rect.fromLTWH(17, 47, 12, 5), _solid(const Color(0xFF7F8C99)));
    for (var i = 0; i < 4; i++) {
      c.drawLine(Offset(14, 58 + i * 6.0), Offset(32, 58 + i * 6.0), _line(0.7, const Color(0xFFB0BCC8)));
    }
    if (state == 2) {
      c.drawCircle(const Offset(23, 74), 6, _solid(const Color(0xFF2EBD59)));
      c.drawLine(const Offset(20, 74), const Offset(22.5, 77), _line(1.6, Colors.white));
      c.drawLine(const Offset(22.5, 77), const Offset(27, 71), _line(1.6, Colors.white));
    }
    // beaker with ice cream sample
    final bk = const Rect.fromLTWH(116, 56, 22, 30);
    c.drawRect(Rect.fromLTWH(bk.left + 1, bk.top + 12, bk.width - 2, bk.height - 13), _solid(const Color(0xFFFFC7DA)));
    c.drawRect(bk, _line(1.1, const Color(0xFF7F8C99)));
    c.drawCircle(Offset(bk.center.dx, bk.top + 11), 7, _solid(const Color(0xFFFFE9F1)));
    if (run) {
      for (var i = 0; i < 3; i++) {
        final p = (t + i / 3) % 1.0;
        c.drawCircle(Offset(bk.left + 5 + i * 6.0, bk.bottom - 3 - p * 18), 1.3, _solid(Colors.white.withAlpha((220 * (1 - p)).round())));
      }
    }
    // magnifier
    final ma = run ? math.sin(t * 2 * math.pi) * 3 : 0.0;
    c.drawCircle(Offset(112 + ma, 40), 8, _line(1.8, _navy));
    c.drawLine(Offset(118 + ma, 46), Offset(124 + ma, 53), _line(2.4, _navy));
  }

  void _coldStorage(Canvas c) {
    _floor(c);
    final bld = const Rect.fromLTWH(8, 22, 94, 76);
    c.drawRRect(
      RRect.fromRectAndRadius(bld, const Radius.circular(4)),
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFE6EEF5), Color(0xFFC3CFDA)],
        ).createShader(bld),
    );
    c.drawRRect(RRect.fromRectAndRadius(bld, const Radius.circular(4)), _line(1));
    c.drawRect(const Rect.fromLTWH(8, 22, 94, 7), _solid(_navy));
    final door = const Rect.fromLTWH(26, 46, 58, 52);
    c.drawRect(door, _metal(door, vert: true));
    for (var i = 1; i < 8; i++) {
      c.drawLine(Offset(door.left, door.top + i * 6.5), Offset(door.right, door.top + i * 6.5), _line(0.7, const Color(0xFF8E9BA8)));
    }
    c.drawRect(door, _line(1));
    final scr = const Rect.fromLTWH(38, 32, 34, 12);
    c.drawRRect(RRect.fromRectAndRadius(scr, const Radius.circular(2)), _solid(const Color(0xFF0E2A47)));
    _text(c, temp, scr.center, 8, const Color(0xFF58E6FF));
    _snow(c, const Offset(18, 38), 6, run ? t * 1.2 : 0.0, _blue);
    // delivery truck
    final dx = run ? math.sin(t * 2 * math.pi) * 3 : 0.0;
    c.save();
    c.translate(dx, 0);
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(108, 62, 32, 26), const Radius.circular(3)), _solid(Colors.white));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(108, 62, 32, 26), const Radius.circular(3)), _line(0.9, const Color(0xFF7F8C99)));
    final cab = Path()
      ..moveTo(140, 70)
      ..lineTo(150, 70)
      ..lineTo(156, 80)
      ..lineTo(156, 88)
      ..lineTo(140, 88)
      ..close();
    c.drawPath(cab, _solid(_blue));
    _snow(c, const Offset(124, 74), 5, 0.0, _blue);
    _wheel(c, const Offset(118, 90));
    _wheel(c, const Offset(146, 90));
    c.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (state == 0) {
      canvas.saveLayer(Offset.zero & size, Paint()..color = const Color(0x99FFFFFF));
    }
    canvas.save();
    canvas.scale(size.width / 160, size.height / 120);
    switch (kind) {
      case 0:
        _receiving(canvas);
        break;
      case 1:
        _mixing(canvas);
        break;
      case 2:
        _pasteuriser(canvas);
        break;
      case 3:
        _homogeniser(canvas);
        break;
      case 4:
        _aging(canvas);
        break;
      case 5:
        _freezer(canvas);
        break;
      case 6:
        _hardening(canvas);
        break;
      case 7:
        _packaging(canvas);
        break;
      case 8:
        _quality(canvas);
        break;
      default:
        _coldStorage(canvas);
    }
    canvas.restore();
    if (state == 0) canvas.restore();
  }

  @override
  bool shouldRepaint(covariant FlowPainter old) =>
      old.kind != kind || old.state != state || old.progress != progress || old.temp != temp;
}

/// Down arrow between two steps; chevrons travel while material is flowing.
class FlowArrowPainter extends CustomPainter {
  FlowArrowPainter(this.anim, this.flowing, this.done) : super(repaint: anim);
  final Animation<double> anim;
  final bool flowing;
  final bool done;

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final col = flowing
        ? const Color(0xFF1E6BE0)
        : done
            ? const Color(0xFF38C172)
            : const Color(0xFFB4C3D4);
    final p = Paint()
      ..color = col
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawLine(Offset(cx, 2), Offset(cx, size.height - 8), p);
    final head = Path()
      ..moveTo(cx - 7, size.height - 14)
      ..lineTo(cx, size.height - 4)
      ..lineTo(cx + 7, size.height - 14);
    canvas.drawPath(head, p);
    if (flowing) {
      for (var i = 0; i < 3; i++) {
        final q = (anim.value + i / 3) % 1.0;
        final y = 2 + q * (size.height - 12);
        canvas.drawCircle(Offset(cx, y), 3.2, Paint()..color = Colors.white);
        canvas.drawCircle(Offset(cx, y), 3.2, Paint()
          ..color = col
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4);
      }
    }
  }

  @override
  bool shouldRepaint(covariant FlowArrowPainter old) => old.flowing != flowing || old.done != done;
}
