import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../services/production_service.dart';
import '../../utils/ui.dart';
import 'package:drift/drift.dart' hide Batch, Column;

/// Quick entry: pick recipe + number of batches.
/// Today  -> order is created and raw materials are cut from stock now.
/// Plan   -> order is only planned (no stock cut) for a later day / shift.
class QuickBatchScreen extends ConsumerStatefulWidget {
  const QuickBatchScreen({super.key, required this.isPlan});
  final bool isPlan;

  @override
  ConsumerState<QuickBatchScreen> createState() => _QuickBatchScreenState();
}

class _QuickBatchScreenState extends ConsumerState<QuickBatchScreen> {
  final _batches = TextEditingController(text: '1');
  List<Recipe> _recipes = [];
  int? _recipeId;
  String _shift = 'সকাল';
  late DateTime _day;
  List<MaterialAvailability> _preview = [];
  String? _error;
  bool _saving = false;
  bool _loaded = false;
  List<Tank> _mixTanks = [];
  List<Tank> _ageTanks = [];
  Set<int> _busyMix = {};
  Set<int> _busyAge = {};
  int? _mixTankId;
  int? _ageTankId;

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    _day = DateTime(n.year, n.month, n.day).add(Duration(days: widget.isPlan ? 1 : 0));
    _load();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    _recipes = await (db.select(db.recipes)
          ..where((r) => r.isActive.equals(true) & r.approvalStatus.equals('Approved')))
        .get();
    final tanks = await db.select(db.tanks).get();
    _mixTanks = tanks.where((t) => t.tankType == 'Mixing').toList()..sort((a, b) => a.tankCode.compareTo(b.tankCode));
    _ageTanks = tanks.where((t) => t.tankType == 'Aging').toList()..sort((a, b) => a.tankCode.compareTo(b.tankCode));
    final active = await (db.select(db.productionOrders)..where((o) => o.status.isIn(['Mixing', 'Aging']))).get();
    _busyMix = {for (final o in active.where((o) => o.status == 'Mixing')) if (o.mixingTankId != null) o.mixingTankId!};
    _busyAge = {for (final o in active) if (o.agingTankId != null) o.agingTankId!};
    if (mounted) setState(() => _loaded = true);
  }

  bool _tankFree(Tank t, Set<int> busy) => t.status == 'Empty' && !busy.contains(t.id) && t.capacityLiter + 0.0001 >= _liters;

  String _tankLabel(Tank t, Set<int> busy) {
    final why = busy.contains(t.id)
        ? 'ব্যস্ত'
        : (t.status != 'Empty' ? t.status : (t.capacityLiter + 0.0001 < _liters ? 'ক্ষমতা কম' : 'ফাঁকা'));
    return '${t.tankCode} (${fmtQty(t.capacityLiter)}L) • $why';
  }

  void _autoPick() {
    final m = _mixTanks.where((t) => _tankFree(t, _busyMix)).toList()
      ..sort((a, b) => a.capacityLiter.compareTo(b.capacityLiter));
    final a = _ageTanks.where((t) => _tankFree(t, _busyAge)).toList()
      ..sort((a, b) => a.capacityLiter.compareTo(b.capacityLiter));
    if (_mixTankId == null || !_mixTanks.any((t) => t.id == _mixTankId && _tankFree(t, _busyMix))) {
      _mixTankId = m.isEmpty ? null : m.first.id;
    }
    if (_ageTankId == null || !_ageTanks.any((t) => t.id == _ageTankId && _tankFree(t, _busyAge))) {
      _ageTankId = a.isEmpty ? null : a.first.id;
    }
  }

  Recipe? get _recipe {
    for (final r in _recipes) {
      if (r.id == _recipeId) return r;
    }
    return null;
  }

  double get _n => parseNum(_batches.text) ?? 0;
  double get _liters => (_recipe?.baseQty ?? 0) * _n;
  double get _kg {
    final r = _recipe;
    if (r == null) return 0;
    return (r.batchKg ?? r.baseQty * r.density) * _n;
  }

  Future<void> _refresh() async {
    if (mounted) setState(_autoPick);
    if (_recipeId == null || _n <= 0) {
      setState(() { _preview = []; _error = null; });
      return;
    }
    try {
      final p = await ref.read(productionServiceProvider).previewMaterials(_recipeId!, _liters);
      if (mounted) setState(() { _preview = p; _error = null; });
    } catch (e) {
      if (mounted) setState(() { _preview = []; _error = friendlyError(e); });
    }
  }

  Future<void> _save() async {
    if (_recipeId == null || _n <= 0) { showSnack(context, 'রেসিপি ও ব্যাচ সংখ্যা দিন'); return; }
    final svc = ref.read(productionServiceProvider);
    setState(() => _saving = true);
    int? newId;
    final ok = await runGuarded(context, () async {
      final mixT = _mixTankId;
      final ageT = _ageTankId;
      if (!widget.isPlan && mixT == null) throw StateException('মিক্সিং ট্যাংক বেছে নিন');
      newId = await svc.createProductionOrder(
        recipeId: _recipeId!,
        targetMixQty: _liters,
        mixingTankId: mixT,
        agingTankId: ageT,
        plannedDate: _day,
        shift: _shift,
        notes: '${fmtQty(_n)} ব্যাচ = ${fmtQty(_kg)} কেজি = ${fmtQty(_liters)} লিটার',
      );
    });
    if (ok && !widget.isPlan && newId != null && mounted) {
      await runGuarded(context, () => svc.issueRecipeMaterials(newId!),
          success: 'ব্যাচ বসেছে, কাঁচামাল মিক্সিংয়ে গেছে ও স্টক কেটেছে');
    } else if (ok && mounted) {
      showSnack(context, 'প্ল্যানে রাখা হয়েছে (স্টক কাটেনি)');
    }
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final r = _recipe;
    final anyShort = _preview.any((m) => m.isShort);
    final blocked = !widget.isPlan && anyShort;
    return Scaffold(
      appBar: AppBar(title: Text(widget.isPlan ? 'প্ল্যানিং ব্যাচ' : 'আজকের ব্যাচ')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<int>(
            isExpanded: true,
            value: _recipeId,
            decoration: const InputDecoration(labelText: 'রেসিপি (যেমন ভ্যানিলা) *'),
            items: _recipes
                .map((x) => DropdownMenuItem(value: x.id, child: Text('${x.recipeCode} - ${x.recipeName}', overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) {
              setState(() => _recipeId = v);
              _refresh();
            },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _batches,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'কত ব্যাচ *', helperText: 'আধা ব্যাচ হলে 0.5'),
            onChanged: (_) {
              setState(() {});
              _refresh();
            },
          ),
          if (r != null && _n > 0)
            Card(
              child: ListTile(
                leading: const Icon(Icons.scale_rounded),
                title: Text('${fmtQty(_n)} ব্যাচ = ${fmtQty(_kg)} কেজি = ${fmtQty(_liters)} লিটার'),
                subtitle: Text('ঘনত্ব ${fmtQty(r.density)} kg/L • এই লিটারই এজিংয়ে যাবে'
                    '${r.batchKg == null ? '\n⚠ রেসিপিতে "১ ব্যাচ = কেজি" সেট নেই' : ''}'),
              ),
            ),
          const SizedBox(height: 8),
          DropdownButtonFormField<int?>(
            isExpanded: true,
            value: _mixTankId,
            decoration: const InputDecoration(labelText: 'মিক্সিং ট্যাংক নম্বর'),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('— বেছে নিন —')),
              for (final t in _mixTanks)
                DropdownMenuItem<int?>(
                  value: t.id,
                  enabled: _tankFree(t, _busyMix),
                  child: Text(_tankLabel(t, _busyMix), overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (v) => setState(() => _mixTankId = v),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int?>(
            isExpanded: true,
            value: _ageTankId,
            decoration: const InputDecoration(labelText: 'মিক্সিংয়ের পর এজিং ট্যাংক নম্বর'),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('— বেছে নিন —')),
              for (final t in _ageTanks)
                DropdownMenuItem<int?>(
                  value: t.id,
                  enabled: _tankFree(t, _busyAge),
                  child: Text(_tankLabel(t, _busyAge), overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (v) => setState(() => _ageTankId = v),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              for (final s in ['সকাল', 'বিকাল', 'রাত'])
                ChoiceChip(label: Text(s), selected: _shift == s, onSelected: (_) => setState(() => _shift = s)),
            ],
          ),
          if (widget.isPlan)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: Text('তারিখ: ${fmtDate(_day)}'),
              onTap: () async {
                final d = await showDatePicker(
                    context: context, initialDate: _day, firstDate: DateTime.now(), lastDate: DateTime(2100));
                if (d != null) setState(() => _day = d);
              },
            ),
          const SizedBox(height: 8),
          if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
          if (_preview.isNotEmpty) ...[
            const Text('মিক্সিংয়ে যা যা লাগবে', style: TextStyle(fontWeight: FontWeight.w800)),
            for (final m in _preview)
              Card(
                color: m.isShort ? Colors.red.withAlpha(35) : null,
                child: ListTile(
                  dense: true,
                  leading: Icon(m.isShort ? Icons.error : Icons.check_circle,
                      color: m.isShort ? Colors.red : Colors.green),
                  title: Text(m.material.item.itemName),
                  subtitle: Text(
                      'লাগবে ${fmtQty(m.material.requiredQty)} ${m.material.item.baseUnit} • আছে ${fmtQty(m.available)}'
                      '${m.isShort ? ' • ঘাটতি ${fmtQty(m.shortage)}' : ''}'),
                ),
              ),
            if (blocked)
              const Text('স্টক কম, আগে Purchase করুন বা প্ল্যানিং ব্যাচে রাখুন।', style: TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: (_recipeId == null || _n <= 0 || _saving || blocked) ? null : _save,
            icon: Icon(widget.isPlan ? Icons.event_available : Icons.play_arrow_rounded),
            label: Text(widget.isPlan ? 'প্ল্যানে রাখুন' : 'ব্যাচ বসান ও কাঁচামাল কাটুন'),
          ),
        ],
      ),
    );
  }
}
