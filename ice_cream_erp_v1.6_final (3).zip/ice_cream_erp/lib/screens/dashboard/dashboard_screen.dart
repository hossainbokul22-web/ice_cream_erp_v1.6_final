import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/alarm_service.dart';
import '../../services/settings_service.dart';
import '../../services/stage_service.dart';
import '../../utils/ui.dart';
import 'flow_painters.dart';
import 'unit_painters.dart';

class _Data {
  _Data({
    required this.orders,
    required this.recipes,
    required this.checks,
    required this.tanks,
    required this.freezers,
    required this.standards,
    required this.cartons,
    required this.kBatches,
    required this.kRunning,
    required this.kDone,
    required this.kAllPass,
    required this.selAllPass,
  });
  final List<ProductionOrder> orders;
  final Map<int, Recipe> recipes;
  final Map<String, StageCheck> checks; // selected order, by stage key
  final List<Tank> tanks;
  final List<Freezer> freezers;
  final List<StageStandard> standards;
  final double cartons;
  final int kBatches, kRunning, kDone, kAllPass;
  final bool selAllPass;
}

class _FS {
  const _FS(this.bn, this.en, this.param);
  final String bn;
  final String en;
  final String param;
}

const List<_FS> _flow = [
  _FS('কাঁচামাল গ্রহণ', 'Raw Materials Receiving', 'দুধ • ক্রিম • চিনি • স্টেবিলাইজার • ফ্লেভার'),
  _FS('মিক্সিং ও ব্লেন্ডিং', 'Mixing & Blending', 'সব উপাদান সমানভাবে মেশানো'),
  _FS('পাস্তুরাইজেশন (HTST)', 'Pasteurization', '72–85°C (১৫–৩০ সেকেন্ড)'),
  _FS('হোমোজেনাইজেশন', 'Homogenization', '১৫০–২৫০ bar'),
  _FS('এজিং', 'Aging', '২–৮°C (৪–১২ ঘণ্টা)'),
  _FS('ব্যাচ ফ্রিজিং', 'Batch Freezing (Overrun)', '-৪ থেকে -৭°C • ওভাররান ৩০–৮০%'),
  _FS('হার্ডেনিং', 'Hardening', '-২৫ থেকে -৪০°C'),
  _FS('প্যাকেজিং', 'Packaging', 'কাপ • কোন • স্টিক • ফ্যামিলি প্যাক'),
  _FS('কোয়ালিটি কন্ট্রোল', 'Quality Control', 'ফিজিক্যাল • কেমিক্যাল • মাইক্রোবায়োলজি'),
  _FS('কোল্ড স্টোরেজ ও ডিস্ট্রিবিউশন', 'Cold Storage & Distribution', '-১৮°C বা তার নিচে'),
];

/// Flow step -> stage-sheet key (for recorded values).
const Map<int, String> _keyOf = {
  1: 'Mixing',
  2: 'Pasteurization',
  3: 'Homogenization',
  4: 'Aging',
  5: 'Freezing',
  7: 'Packing',
};

/// Flow step -> standard-sheet key.
const Map<int, String> _stdKey = {
  1: 'Mixing',
  2: 'Pasteurization',
  3: 'Homogenization',
  4: 'Aging',
  5: 'Freezing',
  6: 'Hardening',
  7: 'Packing',
};

const _navy = Color(0xFF0B3D91);
const _blue = Color(0xFF1E6BE0);
const _green = Color(0xFF2EA86B);
const _red = Color(0xFFD94B4B);
const _amber = Color(0xFFE59A12);
const _grey = Color(0xFF7D8FA3);
const _line = Color(0xFFD5E2F0);

class _Run {
  _Run(this.state, this.prog, this.remain, this.mins, this.totalSec, this.remainSec, this.overall, this.started);
  /// Per step (10): 0 wait, 1 running, 2 done, 3 aging finished & waiting for a freezer.
  final List<int> state;
  final List<double> prog;
  final List<int> remain; // seconds left for the running timed step, else -1
  final List<double> mins; // planned minutes for the 7 timed steps
  final int totalSec;
  final int remainSec;
  final double overall;
  final bool started;

  bool get holding => state[4] == 3;

  int get timedDone {
    var n = 0;
    for (var i = 1; i <= 7; i++) {
      if (state[i] == 2 || state[i] == 3) n++;
    }
    return n;
  }
}

/// What one tank / freezer is doing right now.
class _Occ {
  _Occ(this.order, this.state, this.level, this.text);
  final ProductionOrder order;
  final int state; // 1 working, 3 waiting for operator
  final double level;
  final String text;
}

/// Control-room style dashboard: factory floor + live, time-driven flow of the selected batch.
class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _anim;
  final List<StreamSubscription<dynamic>> _subs = [];
  Timer? _debounce;
  Timer? _tick;
  _Data? _d;
  int? _sel;
  bool _busy = false;
  DateTime _now = DateTime.now();
  final Map<int, int> _lastDone = {};

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();
    final db = ref.read(databaseProvider);
    _subs.add(db.select(db.productionOrders).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.stageChecks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.tanks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.packingRuns).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.freezers).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.stageStandards).watch().listen((_) => _schedule()));
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _now = DateTime.now();
      _checkAlarms();
      setState(() {});
    });
    _schedule();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _tick?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _anim.dispose();
    super.dispose();
  }

  void _schedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 150), _load);
  }

  Future<void> _load() async {
    if (_busy || !mounted) return;
    _busy = true;
    try {
      final db = ref.read(databaseProvider);
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final end = start.add(const Duration(days: 1));
      final all = await (db.select(db.productionOrders)
            ..orderBy([(o) => OrderingTerm.desc(o.id)])
            ..limit(80))
          .get();
      bool isRunning(ProductionOrder o) => o.status == 'Mixing' || o.status == 'Aging' || o.status == 'Freezing';
      bool isToday(ProductionOrder o) {
        final d = o.plannedDate ?? o.createdAt;
        return !d.isBefore(start) && d.isBefore(end);
      }

      var list = all.where((o) => o.status != 'Cancelled' && (isRunning(o) || isToday(o))).toList();
      if (list.isEmpty) list = all.where((o) => o.status != 'Cancelled').take(3).toList();

      final recs = await db.select(db.recipes).get();
      final tanks = await (db.select(db.tanks)..orderBy([(t) => OrderingTerm.asc(t.tankCode)])).get();
      final freezers = await (db.select(db.freezers)
            ..where((f) => f.isActive.equals(true))
            ..orderBy([(f) => OrderingTerm.asc(f.freezerCode)]))
          .get();
      final standards = await db.select(db.stageStandards).get();

      int? sel = _sel;
      if (sel == null || !list.any((o) => o.id == sel)) {
        final run = list.where(isRunning).toList();
        sel = run.isNotEmpty ? run.first.id : (list.isNotEmpty ? list.first.id : null);
      }

      final ids = list.map((o) => o.id).toList();
      final allChecks = ids.isEmpty
          ? <StageCheck>[]
          : await (db.select(db.stageChecks)..where((c) => c.productionOrderId.isIn(ids))).get();
      var allPass = 0;
      var selPass = false;
      for (final id in ids) {
        final ok = StageService.isAllPass(allChecks.where((c) => c.productionOrderId == id).toList());
        if (ok) allPass++;
        if (id == sel) selPass = ok;
      }

      final checks = <String, StageCheck>{
        for (final c in allChecks.where((c) => c.productionOrderId == sel)) c.stage: c,
      };
      var cartons = 0.0;
      if (sel != null) {
        final runs = await (db.select(db.packingRuns)..where((r) => r.orderId.equals(sel!))).get();
        cartons = runs.fold<double>(0, (s, r) => s + r.cartons);
      }

      if (!mounted) return;
      setState(() {
        _sel = sel;
        _d = _Data(
          orders: list,
          recipes: {for (final r in recs) r.id: r},
          checks: checks,
          tanks: tanks,
          freezers: freezers,
          standards: standards,
          cartons: cartons,
          kBatches: list.where(isToday).length,
          kRunning: list.where(isRunning).length,
          kDone: list.where((o) => o.status == 'Completed').length,
          kAllPass: allPass,
          selAllPass: selPass,
        );
      });
    } finally {
      _busy = false;
    }
  }

  Future<void> _refresh() async {
    try {
      await _load();
    } catch (_) {}
  }

  // ---------- standards ----------
  StageStandard? _std(Recipe? r, int step) {
    final key = _stdKey[step];
    final d = _d;
    if (key == null || d == null) return null;
    StageStandard? def;
    for (final s in d.standards) {
      if (s.stage != key) continue;
      if (r != null && s.recipeId == r.id) return s;
      if (s.recipeId == null) def = s;
    }
    return def;
  }

  /// Planned minutes of the 7 timed steps: recipe sheet > default sheet > recipe fields > built-in.
  List<double> _mins(Recipe? r) {
    final def = <double>[5, 1, 5, (r?.agingHours ?? 4.0) * 60, 8, 120, 30];
    final parts = (r?.stageMins ?? '').split(',');
    final out = <double>[];
    for (var i = 0; i < 7; i++) {
      final fromStd = _std(r, i + 1)?.durationMin;
      final fromRecipe = i < parts.length ? double.tryParse(parts[i].trim()) : null;
      if (fromStd != null && fromStd > 0) {
        out.add(fromStd);
      } else if (fromRecipe != null && fromRecipe > 0) {
        out.add(fromRecipe);
      } else {
        out.add(def[i]);
      }
    }
    return out;
  }

  // ---------- timeline ----------
  /// Mixing -> pasteurization -> homogenization -> aging run from the batch start.
  /// After aging the batch WAITS until a freezer is chosen; freezing, hardening and
  /// packaging then run from that moment.
  _Run _timeline(ProductionOrder? o, Recipe? r, bool allPass) {
    final st = List<int>.filled(10, 0);
    final pr = List<double>.filled(10, 0.0);
    final rem = List<int>.filled(10, -1);
    final mins = _mins(r);
    final a = mins[0] + mins[1] + mins[2] + mins[3];
    final b = mins[4] + mins[5] + mins[6];
    final total = a + b;
    if (o == null) return _Run(st, pr, rem, mins, (total * 60).round(), (total * 60).round(), 0, false);

    final done = o.status == 'Completed';
    final fz = o.freezeStartedAt;
    final goneToFreezer = fz != null || done;
    var elA = o.startDate == null ? -1.0 : _now.difference(o.startDate!).inMilliseconds / 60000.0;
    if (done && o.startDate == null) elA = a + 1;
    final started = elA >= 0;
    if (started) {
      st[0] = 2;
      pr[0] = 1;
    }

    var acc = 0.0;
    for (var k = 0; k < 4; k++) {
      final idx = k + 1;
      final s = acc;
      final e = acc + mins[k];
      if (started) {
        if (goneToFreezer || elA >= e) {
          st[idx] = 2;
          pr[idx] = 1;
        } else if (elA >= s) {
          st[idx] = 1;
          pr[idx] = (elA - s) / (e - s);
          rem[idx] = ((e - elA) * 60).ceil();
        }
      }
      acc = e;
    }
    final holding = started && !goneToFreezer && elA >= a;
    if (holding) st[4] = 3;

    var elB = -1.0;
    if (fz != null) {
      elB = _now.difference(fz).inMilliseconds / 60000.0;
    } else if (done) {
      elB = b + 1;
    }
    if (goneToFreezer) {
      var acc2 = 0.0;
      for (var k = 4; k < 7; k++) {
        final idx = k + 1;
        final s = acc2;
        final e = acc2 + mins[k];
        if (elB >= e) {
          st[idx] = 2;
          pr[idx] = 1;
        } else if (elB >= s) {
          st[idx] = 1;
          pr[idx] = (elB - s) / (e - s);
          rem[idx] = ((e - elB) * 60).ceil();
        }
        acc2 = e;
      }
    }

    if (st[7] == 2) {
      final passed = allPass || o.qcStatus == 'Passed' || done;
      st[8] = passed ? 2 : 1;
      pr[8] = passed ? 1 : 0.5;
      if (passed) {
        st[9] = done ? 2 : 1;
        pr[9] = done ? 1 : 0.6;
      }
    }

    final aDone = !started ? 0.0 : (goneToFreezer ? a : (elA < a ? elA : a));
    final bDone = !goneToFreezer ? 0.0 : (elB < b ? (elB < 0 ? 0.0 : elB) : b);
    final overall = (aDone + bDone) / total;
    final totalSec = (total * 60).round();
    final remainSec = !started ? totalSec : ((total - aDone - bDone) * 60).ceil().clamp(0, totalSec * 2).toInt();
    return _Run(st, pr, rem, mins, totalSec, remainSec, overall.clamp(0.0, 1.0).toDouble(), started);
  }

  bool _live(ProductionOrder o) => o.startDate != null && o.status != 'Completed' && o.status != 'Cancelled';

  /// Which order sits in which tank / freezer right now (simulated from the timeline).
  ({Map<int, _Occ> mix, Map<int, _Occ> age, Map<int, _Occ> frz}) _occupancy(_Data d) {
    final mix = <int, _Occ>{};
    final age = <int, _Occ>{};
    final frz = <int, _Occ>{};
    for (final o in d.orders) {
      if (!_live(o)) continue;
      final r = d.recipes[o.recipeId];
      final tl = _timeline(o, r, false);
      final m = tl.mins;
      final s = tl.state;
      final p = tl.prog;
      final c23 = (((s[2] == 2 ? m[1] : p[2] * m[1]) + (s[3] == 2 ? m[2] : p[3] * m[2])) / (m[1] + m[2])).clamp(0.0, 1.0).toDouble();
      final mt = o.mixingTankId;
      if (mt != null) {
        if (s[1] == 1) {
          mix[mt] = _Occ(o, 1, 0.1 + 0.7 * p[1], 'মিক্সিং ${_clock(tl.remain[1])}');
        } else if (s[1] == 2 && s[3] != 2) {
          mix[mt] = _Occ(o, 1, 0.8 * (1 - c23), 'ট্রান্সফার');
        }
      }
      final at = o.agingTankId;
      if (at != null) {
        if (s[1] == 2 && s[3] != 2 && c23 > 0) {
          age[at] = _Occ(o, 1, 0.8 * c23, 'ভরছে');
        } else if (s[4] == 1) {
          age[at] = _Occ(o, 1, 0.8, 'এজিং ${_clock(tl.remain[4])}');
        } else if (s[4] == 3) {
          age[at] = _Occ(o, 3, 0.8, 'ফ্রিজার বাছুন');
        } else if (s[5] == 1) {
          age[at] = _Occ(o, 1, 0.8 * (1 - p[5]), 'ফ্রিজারে যাচ্ছে');
        }
      }
      final fid = o.freezerId;
      if (fid != null && s[5] == 1) {
        frz[fid] = _Occ(o, 1, 0.2 + 0.65 * p[5], 'ফ্রিজিং ${_clock(tl.remain[5])}');
      }
    }
    return (mix: mix, age: age, frz: frz);
  }

  bool get _alarmOn => ref.read(settingsMapProvider).valueOrNull?['dash_alarm'] != '0';

  void _checkAlarms() {
    final d = _d;
    if (d == null) return;
    for (final o in d.orders) {
      if (!_live(o)) continue;
      final tl = _timeline(o, d.recipes[o.recipeId], false);
      final n = tl.timedDone;
      final prev = _lastDone[o.id];
      _lastDone[o.id] = n;
      if (prev != null && n > prev) {
        var idx = 1;
        for (var i = 1; i <= 7; i++) {
          if (tl.state[i] == 2 || tl.state[i] == 3) idx = i;
        }
        final msg = tl.holding
            ? '🔔 ${o.orderNo}: এজিং শেষ — ড্যাসবোর্ডে ফ্রিজার বেছে শুরু করুন'
            : (n >= 7 ? '🔔 ${o.orderNo}: সব ধাপ শেষ' : '🔔 ${o.orderNo}: ${_flow[idx].bn} শেষ — পরের ধাপ শুরু');
        if (_alarmOn) AlarmService.ring();
        final m = ScaffoldMessenger.maybeOf(context);
        m?.hideCurrentSnackBar();
        m?.showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 8)));
      }
    }
  }

  Future<void> _toggleAlarm() async {
    final next = !_alarmOn;
    try {
      await ref.read(settingsServiceProvider).set('dash_alarm', next ? '1' : '0');
    } catch (_) {}
    if (next) AlarmService.ring();
  }

  // ---------- helpers ----------
  static String _clock(int sec) {
    final s = sec < 0 ? 0 : sec;
    String p(int v) => v.toString().padLeft(2, '0');
    final h = s ~/ 3600;
    final m = (s % 3600) ~/ 60;
    final x = s % 60;
    return h > 0 ? '$h:${p(m)}:${p(x)}' : '${p(m)}:${p(x)}';
  }

  static String _minLabel(double m) => m >= 60 ? '${fmtQty(m / 60)} ঘণ্টা' : '${fmtQty(m)} মিনিট';

  static String _hm(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  String _paramFor(int i, Recipe? r) {
    final s = _std(r, i);
    if (s == null) return _flow[i].param;
    final parts = <String>[];
    if (s.tempMin != null || s.tempMax != null) {
      final lo = s.tempMin;
      final hi = s.tempMax;
      parts.add(lo != null && hi != null && lo != hi
          ? '${fmtQty(lo)}–${fmtQty(hi)}°C'
          : '${fmtQty((lo ?? hi)!)}°C');
    }
    if (s.pressureMin != null || s.pressureMax != null) {
      final lo = s.pressureMin;
      final hi = s.pressureMax;
      parts.add(lo != null && hi != null && lo != hi
          ? '${fmtQty(lo)}–${fmtQty(hi)} bar'
          : '${fmtQty((lo ?? hi)!)} bar');
    }
    if (s.durationMin != null) parts.add(_minLabel(s.durationMin!));
    return parts.isEmpty ? _flow[i].param : parts.join(' • ');
  }

  String _tempFor(int i, Map<String, StageCheck> ch, Recipe? r) {
    final c = ch[_keyOf[i]];
    final s = _std(r, i);
    String mid(double? lo, double? hi) {
      if (lo == null && hi == null) return '';
      if (lo == null || hi == null) return fmtQty((lo ?? hi)!);
      return fmtQty((lo + hi) / 2);
    }

    switch (i) {
      case 2:
        if (c?.tempValue != null) return '${fmtQty(c!.tempValue!)}°C';
        final m = mid(s?.tempMin, s?.tempMax);
        return m.isEmpty ? '72°C' : '$m°C';
      case 3:
        if (c?.pressureBar != null) return '${fmtQty(c!.pressureBar!)} bar';
        final m = mid(s?.pressureMin, s?.pressureMax);
        return m.isEmpty ? '200 bar' : '$m bar';
      case 4:
        if (c?.tempValue != null) return '${fmtQty(c!.tempValue!)}°C';
        final m = mid(s?.tempMin, s?.tempMax);
        return m.isEmpty ? '4°C' : '$m°C';
      case 5:
        if (c?.tempValue != null) return '${fmtQty(c!.tempValue!)}°C';
        final m = mid(s?.tempMin, s?.tempMax);
        return m.isEmpty ? '-5°C' : '$m°C';
      case 6:
        final m = mid(s?.tempMin, s?.tempMax);
        return m.isEmpty ? '-30°C' : '$m°C';
      case 9:
        return '-18°C';
      default:
        return '';
    }
  }

  Widget _led(Color c, {bool pulse = false}) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        final glow = pulse ? 0.5 + 0.5 * (1 - (_anim.value * 2 - 1).abs()) : 0.6;
        return Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: c,
            boxShadow: [BoxShadow(color: c.withAlpha((200 * glow).round()), blurRadius: 7, spreadRadius: 1)],
          ),
        );
      },
    );
  }

  Widget _kpi(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.fromLTRB(9, 8, 6, 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: color)),
            Text(label, style: const TextStyle(fontSize: 9.5, color: _grey), maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _header(Company co) {
    final on = _alarmOn;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 12, 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0A3A8C), Color(0xFF1767DB)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: _navy.withAlpha(70), blurRadius: 14, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Modern Ice Cream Industry',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Colors.white)),
                  Text('Process Flow Diagram',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Color(0xFFFFE600))),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(mainAxisSize: MainAxisSize.min, children: [
                  _led(const Color(0xFF45E08A), pulse: true),
                  const SizedBox(width: 5),
                  const Text('LIVE',
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, color: Color(0xFF45E08A))),
                ]),
                const SizedBox(height: 3),
                Text('${_hm(_now)}:${_now.second.toString().padLeft(2, '0')}',
                    style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontFeatures: [FontFeature.tabularFigures()])),
              ],
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Text(co.shownName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600)),
            ),
            InkWell(
              onTap: _toggleAlarm,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: on ? Colors.white : Colors.white24,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(on ? Icons.notifications_active_rounded : Icons.notifications_off_rounded,
                      size: 16, color: on ? _navy : Colors.white70),
                  const SizedBox(width: 5),
                  Text(on ? 'এলার্ম অন' : 'এলার্ম অফ',
                      style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: on ? _navy : Colors.white70)),
                ]),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  // ---------- factory floor ----------
  Widget _section(String title, String sub) {
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 8),
      child: Row(children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: _navy))),
        Text(sub, style: const TextStyle(fontSize: 11, color: _grey, fontWeight: FontWeight.w700)),
      ]),
    );
  }

  Widget _unitCard({
    required int kind,
    required String code,
    required int state,
    required double level,
    required String text,
    VoidCallback? onTap,
  }) {
    final w = (MediaQuery.of(context).size.width - 32 - 3 * 8) / 4;
    final col = state == 3 ? _amber : (state == 1 ? _blue : (state == 4 ? const Color(0xFF3AA0E6) : _grey));
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: w,
        padding: const EdgeInsets.fromLTRB(4, 6, 4, 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: state == 0 ? _line : col, width: state == 0 ? 1 : 1.6),
          boxShadow: [BoxShadow(color: _navy.withAlpha(state == 0 ? 10 : 30), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Column(
          children: [
            RepaintBoundary(
              child: SizedBox(
                width: w - 8,
                height: (w - 8) * 96 / 80,
                child: CustomPaint(painter: UnitPainter(kind, _anim, state, level)),
              ),
            ),
            const SizedBox(height: 2),
            Text(code, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: _navy)),
            Text(text,
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: state == 0 ? _grey : col)),
          ],
        ),
      ),
    );
  }

  Widget _tankGrid(_Data d, String type, Map<int, _Occ> occ, int kind) {
    final tanks = d.tanks.where((t) => t.tankType == type).toList();
    if (tanks.isEmpty) {
      return Text('কোনো ${type == 'Mixing' ? 'মিক্সিং' : 'এজিং'} ট্যাংক নেই — Tanks থেকে যোগ করুন',
          style: const TextStyle(color: _grey, fontSize: 12));
    }
    return Wrap(spacing: 8, runSpacing: 8, children: [
      for (final t in tanks) _tankUnit(d, t, occ[t.id], kind),
    ]);
  }

  Widget _tankUnit(_Data d, Tank t, _Occ? o, int kind) {
    int state = 0;
    double level = 0;
    String text = 'ফাঁকা';
    if (o != null) {
      state = o.state;
      level = o.level;
      text = '${o.order.orderNo}\n${o.text}';
    } else if (t.status == 'Cleaning') {
      state = 4;
      text = 'CIP দরকার';
    } else if (t.status == 'InUse') {
      state = 1;
      level = t.capacityLiter > 0 ? (t.currentQty / t.capacityLiter).clamp(0.0, 1.0).toDouble() : 0.5;
      text = 'ব্যবহারে\n${fmtQty(t.currentQty)} L';
    }
    return _unitCard(
      kind: kind,
      code: t.tankCode,
      state: state,
      level: level,
      text: text,
      onTap: () => _tankTap(d, t, o, state),
    );
  }

  Future<void> _tankTap(_Data d, Tank t, _Occ? o, int state) async {
    if (o != null && o.state == 3) {
      await _sendSheet(orderId: o.order.id);
      return;
    }
    if (state == 4) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('${t.tankCode} পরিষ্কার (CIP) শেষ?'),
          content: const Text('শেষ হলে ট্যাংক “খালি” হয়ে আবার ব্যবহার করা যাবে।'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ, খালি করুন')),
          ],
        ),
      );
      if (ok == true && mounted) {
        await runGuarded(context, () => ref.read(productionServiceProvider).markTankClean(t.id));
        _load();
      }
      return;
    }
    if (!mounted) return;
    final msg = o != null
        ? '${t.tankCode} (${fmtQty(t.capacityLiter)} L): ${o.order.orderNo} • ${o.text}'
        : '${t.tankCode} (${fmtQty(t.capacityLiter)} L): ${state == 0 ? 'ফাঁকা' : t.status}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 3)));
  }

  Widget _freezerGrid(_Data d, Map<int, _Occ> occ) {
    if (d.freezers.isEmpty) {
      return Row(children: [
        const Expanded(child: Text('কোনো ফ্রিজার নেই — Home থেকে “Freezers” খুলে যোগ করুন', style: TextStyle(color: _grey, fontSize: 12))),
      ]);
    }
    return Wrap(spacing: 8, runSpacing: 8, children: [
      for (final f in d.freezers)
        _unitCard(
          kind: 2,
          code: f.freezerCode,
          state: occ[f.id] == null ? 0 : 1,
          level: occ[f.id]?.level ?? 0,
          text: occ[f.id] == null ? 'ফাঁকা' : '${occ[f.id]!.order.orderNo}\n${occ[f.id]!.text}',
          onTap: () => _freezerTap(d, f, occ[f.id]),
        ),
    ]);
  }

  Future<void> _freezerTap(_Data d, Freezer f, _Occ? o) async {
    if (o != null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${f.freezerCode}: ${o.order.orderNo} • ${o.text}'), duration: const Duration(seconds: 3)));
      return;
    }
    await _sendSheet(freezerId: f.id);
  }

  Widget _machineCard(int kind, String title, _Data d, int step) {
    // find the running order for this machine step
    ProductionOrder? run;
    _Run? rtl;
    for (final o in d.orders) {
      if (!_live(o)) continue;
      final tl = _timeline(o, d.recipes[o.recipeId], false);
      if (tl.state[step] == 1) {
        run = o;
        rtl = tl;
        break;
      }
    }
    final st = run == null ? 0 : 1;
    final w = (MediaQuery.of(context).size.width - 32 - 8 - 28) / 2;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: st == 1 ? _blue : _line, width: st == 1 ? 1.8 : 1),
        ),
        child: Column(children: [
          RepaintBoundary(
            child: SizedBox(
              width: w,
              height: w * 120 / 160,
              child: CustomPaint(
                  painter: FlowPainter(kind, _anim, st, rtl?.prog[step] ?? 0, kind == 2 ? '72°C' : '200 bar')),
            ),
          ),
          Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: _navy)),
          Text(run == null ? 'ফাঁকা' : '${run.orderNo} • ${_clock(rtl!.remain[step])}',
              style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: run == null ? _grey : _blue)),
        ]),
      ),
    );
  }

  Widget _floorArrow(bool flowing) => SizedBox(
        height: 26,
        width: double.infinity,
        child: CustomPaint(painter: FlowArrowPainter(_anim, flowing, false)),
      );

  Widget _plantFloor(_Data d) {
    final occ = _occupancy(d);
    final waiting = d.orders.where((o) => _live(o) && _timeline(o, d.recipes[o.recipeId], false).holding).length;
    final mixTotal = d.tanks.where((t) => t.tankType == 'Mixing').length;
    final ageTotal = d.tanks.where((t) => t.tankType == 'Aging').length;
    bool anyRun(int step) => d.orders.any((o) => _live(o) && _timeline(o, d.recipes[o.recipeId], false).state[step] == 1);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F8FE),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('ফ্যাক্টরি ফ্লোর — লাইভ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: _navy)),
          const SizedBox(height: 10),
          _section('মিক্সিং ট্যাংক', '$mixTotal টি • ব্যস্ত ${occ.mix.length}'),
          _tankGrid(d, 'Mixing', occ.mix, 0),
          _floorArrow(anyRun(1) || anyRun(2)),
          Row(children: [
            _machineCard(2, 'পাস্তুরাইজার (HTST)', d, 2),
            const SizedBox(width: 8),
            _machineCard(3, 'হোমোজেনাইজার', d, 3),
          ]),
          _floorArrow(anyRun(3)),
          _section('এজিং ট্যাংক', '$ageTotal টি • ব্যস্ত ${occ.age.length}${waiting > 0 ? ' • অপেক্ষায় $waiting' : ''}'),
          _tankGrid(d, 'Aging', occ.age, 1),
          if (waiting > 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: _amber),
                onPressed: () => _sendSheet(),
                icon: const Icon(Icons.ac_unit_rounded, size: 18),
                label: Text('$waiting টি ব্যাচ ফ্রিজারের অপেক্ষায় — ফ্রিজার বেছে শুরু করুন'),
              ),
            ),
          _floorArrow(occ.frz.isNotEmpty),
          _section('ফ্রিজার', '${d.freezers.length} টি • ব্যস্ত ${occ.frz.length}'),
          _freezerGrid(d, occ.frz),
        ],
      ),
    );
  }

  // ---------- send to freezer ----------
  Future<void> _sendSheet({int? orderId, int? freezerId}) async {
    final d = _d;
    if (d == null) return;
    final waiting = d.orders.where((o) => _live(o) && _timeline(o, d.recipes[o.recipeId], false).holding).toList();
    final occ = _occupancy(d);
    final free = d.freezers.where((f) => !occ.frz.containsKey(f.id)).toList();
    int? selOrder = orderId ?? (waiting.length == 1 ? waiting.first.id : null);
    int? selFrz = freezerId;
    if (waiting.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('এখন এজিং শেষ হওয়া কোনো ব্যাচ অপেক্ষায় নেই')));
      return;
    }
    if (d.freezers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('আগে ফ্রিজার যোগ করুন (Home → Freezers)')));
      return;
    }
    final go = await showModalBottomSheet<List<int>>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('ফ্রিজারে পাঠান', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                const Text('কোন ব্যাচ (এজিং ট্যাংক থেকে)?', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final o in waiting)
                    ChoiceChip(
                      label: Text(
                          '${o.orderNo} • ${d.recipes[o.recipeId]?.recipeName ?? ''}${_tankCode(d, o.agingTankId) == null ? '' : ' • ${_tankCode(d, o.agingTankId)}'}'),
                      selected: selOrder == o.id,
                      onSelected: (_) => setS(() => selOrder = o.id),
                    ),
                ]),
                const SizedBox(height: 14),
                const Text('কোন ফ্রিজারে চালাবেন?', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                if (free.isEmpty)
                  const Text('সব ফ্রিজার এখন ব্যস্ত', style: TextStyle(color: Colors.red))
                else
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final f in free)
                      ChoiceChip(
                        label: Text('${f.freezerCode}${f.capacityLiter > 0 ? ' (${fmtQty(f.capacityLiter)}L)' : ''}'),
                        selected: selFrz == f.id,
                        onSelected: (_) => setS(() => selFrz = f.id),
                      ),
                  ]),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: (selOrder == null || selFrz == null) ? null : () => Navigator.pop(ctx, [selOrder!, selFrz!]),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('ফ্রিজিং শুরু'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (go == null || !mounted) return;
    await runGuarded(context, () => ref.read(productionServiceProvider).sendToFreezer(go[0], go[1]),
        success: 'ফ্রিজিং শুরু হয়েছে');
    _load();
  }

  String? _tankCode(_Data d, int? id) {
    if (id == null) return null;
    for (final t in d.tanks) {
      if (t.id == id) return t.tankCode;
    }
    return null;
  }

  String? _freezerCode(_Data d, int? id) {
    if (id == null) return null;
    for (final f in d.freezers) {
      if (f.id == id) return f.freezerCode;
    }
    return null;
  }

  // ---------- selected batch ----------
  Widget _batchCard(ProductionOrder? o, _Data d, _Run tl) {
    if (o == null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: _line)),
        child: const Text('কোনো ব্যাচ নেই। Home থেকে “আজকের ব্যাচ” দিয়ে ব্যাচ শুরু করুন — তারপর এখানে লাইভ চলবে।',
            style: TextStyle(color: _grey, fontSize: 12.5)),
      );
    }
    final r = d.recipes[o.recipeId];
    final start = o.startDate;
    final mt = _tankCode(d, o.mixingTankId);
    final at = _tankCode(d, o.agingTankId);
    final fz = _freezerCode(d, o.freezerId);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _line),
        boxShadow: [BoxShadow(color: _navy.withAlpha(18), blurRadius: 8, offset: const Offset(0, 3))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text('${o.orderNo} • ${r?.recipeName ?? ''}',
                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: _navy)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _blue.withAlpha(24), borderRadius: BorderRadius.circular(10)),
              child: Text(o.status, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: _blue)),
            ),
          ]),
          const SizedBox(height: 3),
          Text(
            tl.started
                ? '${fmtQty(o.targetQty)} L • শুরু ${_hm(start!)} • বাকি ${_clock(tl.remainSec)}'
                : '${fmtQty(o.targetQty)} L • এখনো শুরু হয়নি (মোট ${_clock(tl.totalSec)})',
            style: const TextStyle(fontSize: 11, color: _grey),
          ),
          const SizedBox(height: 3),
          Text(
            'মিক্সিং: ${mt ?? '—'}  •  এজিং: ${at ?? '—'}  •  ফ্রিজার: ${fz ?? '—'}',
            style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: _navy),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: tl.overall,
              minHeight: 8,
              backgroundColor: const Color(0xFFE3ECF6),
              valueColor: AlwaysStoppedAnimation<Color>(tl.overall >= 1 ? _green : _blue),
            ),
          ),
          const SizedBox(height: 3),
          Text('${(tl.overall * 100).round()}% সম্পন্ন', style: const TextStyle(fontSize: 10.5, color: _grey)),
        ],
      ),
    );
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(color: c.withAlpha(28), borderRadius: BorderRadius.circular(8)),
        child: Text(t, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: c)),
      );

  Widget _stageCard(int i, ProductionOrder? o, _Data d, _Run tl) {
    final fs = _flow[i];
    final st = tl.state[i];
    final r = o == null ? null : d.recipes[o.recipeId];
    final accent = st == 2 ? _green : (st == 1 ? _blue : (st == 3 ? _amber : _grey));
    final chk = d.checks[_keyOf[i]];
    final timed = i >= 1 && i <= 7;
    final info = <Widget>[
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(color: const Color(0xFFE4F0FD), borderRadius: BorderRadius.circular(10)),
        child: Text(_paramFor(i, r), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _navy)),
      ),
      const SizedBox(height: 6),
    ];
    if (timed) {
      info.add(Text('নির্ধারিত: ${_minLabel(tl.mins[i - 1])}', style: const TextStyle(fontSize: 10.5, color: _grey)));
      info.add(const SizedBox(height: 4));
    }
    if (st == 1 && tl.remain[i] >= 0) {
      info.addAll([
        const Text('বাকি সময়', style: TextStyle(fontSize: 10, color: _grey)),
        Text(_clock(tl.remain[i]),
            style: const TextStyle(
                fontSize: 23, fontWeight: FontWeight.w900, color: _blue, fontFeatures: [FontFeature.tabularFigures()])),
        const SizedBox(height: 3),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: tl.prog[i],
            minHeight: 6,
            backgroundColor: const Color(0xFFE3ECF6),
            valueColor: const AlwaysStoppedAnimation<Color>(_blue),
          ),
        ),
      ]);
    } else if (st == 3) {
      info.addAll([
        const Text('এজিং শেষ ✔', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: _amber)),
        const Text('ফ্রিজার বেছে শুরু করুন', style: TextStyle(fontSize: 11, color: _grey)),
        const SizedBox(height: 6),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: _amber, visualDensity: VisualDensity.compact),
          onPressed: o == null ? null : () => _sendSheet(orderId: o.id),
          icon: const Icon(Icons.ac_unit_rounded, size: 16),
          label: const Text('ফ্রিজার বাছুন'),
        ),
      ]);
    } else if (st == 1) {
      info.add(Text(i == 8 ? 'পরীক্ষা চলছে… (ধাপ-সিটে সব পাস দিন)' : 'প্রক্রিয়া চলছে…',
          style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: _amber)));
    } else if (st == 2) {
      info.add(Row(children: const [
        Icon(Icons.check_circle_rounded, size: 17, color: _green),
        SizedBox(width: 5),
        Text('সম্পন্ন', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: _green)),
      ]));
    } else {
      info.add(Text(i >= 5 && i <= 7 && o != null && o.freezeStartedAt == null ? 'এজিং ও ফ্রিজার সিলেক্টের পর' : 'অপেক্ষায়',
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _grey)));
    }
    if (i == 5 && o?.freezerId != null) {
      info.add(const SizedBox(height: 4));
      info.add(_chip('ফ্রিজার ${_freezerCode(d, o!.freezerId) ?? ''}', _blue));
    }
    if (i == 7 && d.cartons > 0) {
      info.add(const SizedBox(height: 4));
      info.add(_chip('প্যাক: ${fmtQty(d.cartons)} কার্টন', _green));
    }
    if (chk != null) {
      info.add(const SizedBox(height: 5));
      info.add(Wrap(spacing: 4, runSpacing: 3, children: [
        _chip(chk.result == 'Pass' ? 'পাস' : (chk.result == 'Fail' ? 'ফেল' : 'স্কিপ'),
            chk.result == 'Pass' ? _green : (chk.result == 'Fail' ? _red : _grey)),
        if (chk.tempValue != null) _chip('${fmtQty(chk.tempValue!)}°C', _navy),
        if (chk.pressureBar != null) _chip('${fmtQty(chk.pressureBar!)} bar', _navy),
        if (chk.durationMin != null) _chip('${fmtQty(chk.durationMin!)} মি', _navy),
      ]));
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: st == 1 ? _blue : (st == 3 ? _amber : (st == 2 ? const Color(0xFFBFE8CF) : _line)),
          width: (st == 1 || st == 3) ? 2 : 1,
        ),
        boxShadow: [BoxShadow(color: (st == 1 ? _blue : _navy).withAlpha(st == 1 ? 55 : 20), blurRadius: st == 1 ? 16 : 8, offset: const Offset(0, 3))],
      ),
      child: Column(
        children: [
          Row(children: [
            Container(
              width: 30,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(shape: BoxShape.circle, color: st == 2 ? _green : _navy),
              child: st == 2
                  ? const Icon(Icons.check_rounded, size: 18, color: Colors.white)
                  : Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(fs.bn, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: _navy)),
                  Text(fs.en, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: _grey)),
                ],
              ),
            ),
            _chip(st == 2 ? 'সম্পন্ন' : (st == 1 ? 'চলছে' : (st == 3 ? 'অপেক্ষা: ফ্রিজার' : 'অপেক্ষা')), accent),
          ]),
          const SizedBox(height: 10),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 148,
              height: 111,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFEFF6FE), Color(0xFFD9E9F8)]),
                borderRadius: BorderRadius.circular(14),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: CustomPaint(painter: FlowPainter(i, _anim, st == 3 ? 2 : st, tl.prog[i], _tempFor(i, d.checks, r))),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: info)),
          ]),
        ],
      ),
    );
  }

  Widget _arrow(int i, _Run tl) {
    final flowing = tl.state[i] == 1 || (tl.state[i] == 2 && tl.state[i + 1] == 1);
    return SizedBox(
      height: 34,
      width: double.infinity,
      child: CustomPaint(painter: FlowArrowPainter(_anim, flowing, tl.state[i] == 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final co = ref.watch(companyProvider);
    ref.watch(settingsMapProvider); // rebuild when alarm toggle changes
    final d = _d;
    const bg = BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFE3EFFB), Color(0xFFF7FAFE)]),
    );
    if (d == null) {
      return const Scaffold(
        body: DecoratedBox(decoration: bg, child: Center(child: CircularProgressIndicator())),
      );
    }
    ProductionOrder? sel;
    for (final o in d.orders) {
      if (o.id == _sel) sel = o;
    }
    final tl = _timeline(sel, sel == null ? null : d.recipes[sel.recipeId], d.selAllPass);

    return Scaffold(
      backgroundColor: const Color(0xFFEFF5FC),
      body: DecoratedBox(
        decoration: bg,
        child: SafeArea(
          child: RefreshIndicator(
            color: _blue,
            backgroundColor: Colors.white,
            onRefresh: _refresh,
            child: ScrollConfiguration(
              behavior: ScrollConfiguration.of(context).copyWith(overscroll: false),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _header(co),
                    const SizedBox(height: 12),
                    Row(children: [
                      _kpi('আজকের ব্যাচ', '${d.kBatches}', _blue, Icons.layers_rounded),
                      _kpi('চলমান', '${d.kRunning}', _amber, Icons.sync_rounded),
                      _kpi('সম্পন্ন', '${d.kDone}', _green, Icons.check_circle_rounded),
                      _kpi('সব পাস', '${d.kAllPass}', const Color(0xFF7B5CE0), Icons.verified_rounded),
                    ]),
                    const SizedBox(height: 12),
                    _plantFloor(d),
                    const SizedBox(height: 16),
                    const Text('ব্যাচ ফ্লো (১০ ধাপ)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: _navy)),
                    const SizedBox(height: 8),
                    if (d.orders.length > 1)
                      SizedBox(
                        height: 38,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            for (final o in d.orders)
                              Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: ChoiceChip(
                                  label: Text(o.orderNo, style: const TextStyle(fontSize: 12)),
                                  selected: o.id == _sel,
                                  onSelected: (_) {
                                    setState(() => _sel = o.id);
                                    _load();
                                  },
                                ),
                              ),
                          ],
                        ),
                      ),
                    if (d.orders.length > 1) const SizedBox(height: 10),
                    _batchCard(sel, d, tl),
                    const SizedBox(height: 12),
                    for (var i = 0; i < _flow.length; i++) ...[
                      RepaintBoundary(child: _stageCard(i, sel, d, tl)),
                      if (i < _flow.length - 1) _arrow(i, tl),
                    ],
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
