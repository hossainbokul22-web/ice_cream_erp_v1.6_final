# Changelog

## v1.7 — Users, audit, temperature, VAT, allergens, versions, auto schedule
- PIN login with roles (Owner / Operator / Store), screens hidden by role; Audit Log screen.
- Temperature log with limits, alarm and Dashboard alert banner.
- VAT % and BIN in Settings; VAT on sale invoice, PDF and "VAT Payable" ledger.
- Allergen tags on items, allergen summary on recipe, recipe version history.
- Auto Schedule: suggests mixing tank, aging tank, freezer and times; creates planned batches.
- DB schema 16 (new tables: AppUsers, AuditLogs, TempLogs, RecipeVersions; invoice VAT columns).

## v1.6 — RM/Pack boss register + A4 PDF (2026-11-08)

- RM/Packaging daily: Opening, Receive, Use, Reject, Wastage, Return, Closing
- Day continuity: previous closing = next opening (ledger-based)
- A4 landscape PDF print/share (pdf + printing packages)
- Reject / Wastage / Return stock movement APIs

# Changelog

## v1.5 — Boss inventory reports (2026-11-08)

- **Daily Inventory Brief**: RM+FG value, today purchase/issue/FG/sales, low/near-expiry, CSV share
- **Monthly Stock Statement**: Opening, Purchase, Prod Issue, Prod In, Sales, Transfer, Adj, Closing — filter RM/FG — CSV share

# Changelog

## v1.4 — Remaining offline BatchMaster gaps (2026-11-08)

### Added
- **MPS 14-day calendar** — plannedDate + priority on orders; MpsScreen
- **Warehouse Transfer** — batch move between warehouses (WH-qualified batch no)
- **R&D / Lab samples** — trial create, status Testing/Approved/Rejected
- **Operators + e-sign roster** — Operator / QA / Supervisor
- **FSSAI/GMP compliance checklist** templates + ProductionComplianceLogs
- **Recipe nutrition targets** (kcal, fat, protein, carb, sugar)
- **Work instructions** on recipe, shown on production order
- **By-product qty/notes** on FG completion
- Second warehouse seed (Cold Store FG)

### Schema
- schemaVersion **6**

## v1.3 — Potency, Intermediate, HACCP, MRP
## v1.2 — EBR, QC, Genealogy, Versioning, Capacity, Demand
