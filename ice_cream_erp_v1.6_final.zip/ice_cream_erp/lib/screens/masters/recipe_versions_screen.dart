import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../utils/ui.dart';

/// History of one recipe: every saved version with what was added / removed.
class RecipeVersionsScreen extends ConsumerStatefulWidget {
  const RecipeVersionsScreen({super.key, required this.recipeId});
  final int recipeId;

  @override
  ConsumerState<RecipeVersionsScreen> createState() => _RecipeVersionsScreenState();
}

class _RecipeVersionsScreenState extends ConsumerState<RecipeVersionsScreen> {
  List<RecipeVersion> _rows = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    final rows = await (db.select(db.recipeVersions)
          ..where((v) => v.recipeId.equals(widget.recipeId))
          ..orderBy([(v) => OrderingTerm.desc(v.versionNo)]))
        .get();
    if (mounted) {
      setState(() {
        _rows = rows;
        _loaded = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Recipe version history')),
      body: _rows.isEmpty
          ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('No versions yet — a version is saved automatically whenever the recipe changes.', textAlign: TextAlign.center)))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _rows.length,
              itemBuilder: (ctx, i) {
                final v = _rows[i];
                final prev = i + 1 < _rows.length ? _rows[i + 1] : null;
                final cur = v.snapshot.split('\n');
                final old = prev == null ? <String>[] : prev.snapshot.split('\n');
                final added = prev == null ? <String>[] : cur.where((l) => !old.contains(l)).toList();
                final removed = prev == null ? <String>[] : old.where((l) => !cur.contains(l)).toList();
                return Card(
                  child: ExpansionTile(
                    initiallyExpanded: i == 0,
                    title: Text('Version ${v.versionNo}${i == 0 ? '  (current)' : ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${fmtDateTime(v.savedAt)}${v.userName.isEmpty ? '' : ' • ${v.userName}'} • ${v.reason}'),
                    childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                    expandedCrossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (prev != null) ...[
                        const Text('Changes from previous version', style: TextStyle(fontWeight: FontWeight.w700)),
                        if (added.isEmpty && removed.isEmpty) const Text('(no line changes)'),
                        for (final l in removed) Text('− $l', style: const TextStyle(color: Colors.red, fontSize: 12.5)),
                        for (final l in added) Text('+ $l', style: const TextStyle(color: Colors.green, fontSize: 12.5)),
                        const SizedBox(height: 8),
                      ],
                      const Text('Full recipe at this version', style: TextStyle(fontWeight: FontWeight.w700)),
                      Text(v.snapshot, style: const TextStyle(fontSize: 12.5, height: 1.35)),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
