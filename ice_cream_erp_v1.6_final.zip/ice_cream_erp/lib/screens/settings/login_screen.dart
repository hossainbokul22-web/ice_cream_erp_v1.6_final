import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/auth_provider.dart';
import '../../providers/database_provider.dart';
import '../../services/audit_service.dart';
import '../../services/settings_service.dart';

/// PIN login shown at start-up once at least one user exists.
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  int? _userId;
  final _pin = TextEditingController();
  String? _error;
  bool _remember = true;

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  Future<void> _login(List<AppUser> users) async {
    AppUser? u;
    for (final x in users) {
      if (x.id == _userId) u = x;
    }
    if (u == null) {
      setState(() => _error = 'Select your name');
      return;
    }
    if (u.pinHash != hashPin(_pin.text.trim())) {
      setState(() => _error = 'Wrong PIN');
      _pin.clear();
      return;
    }
    final db = ref.read(databaseProvider);
    try {
      final st = SettingsService(db);
      if (_remember) {
        await st.set('remember_user', u.id.toString());
      } else {
        await st.remove('remember_user');
      }
    } catch (_) {}
    await Audit.write(db, 'Login', u.userName);
    setSession(ref, u);
  }

  @override
  Widget build(BuildContext context) {
    final users = (ref.watch(usersProvider).valueOrNull ?? <AppUser>[]).where((u) => u.isActive).toList();
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 380),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.lock_rounded, size: 56),
                  const SizedBox(height: 12),
                  const Text('Ice Cream ERP', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  const Text('Login with your PIN', textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  DropdownButtonFormField<int>(
                    value: _userId,
                    decoration: const InputDecoration(labelText: 'User'),
                    items: [
                      for (final u in users) DropdownMenuItem(value: u.id, child: Text('${u.userName}  (${u.role})')),
                    ],
                    onChanged: (v) => setState(() {
                      _userId = v;
                      _error = null;
                    }),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _pin,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: 'PIN', errorText: _error),
                    onSubmitted: (_) => _login(users),
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: _remember,
                    onChanged: (v) => setState(() => _remember = v ?? false),
                    title: const Text('Keep me logged in on this phone'),
                    subtitle: const Text('No PIN needed next time. Use Logout in Settings to switch user.'),
                  ),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: () => _login(users),
                    icon: const Icon(Icons.login_rounded),
                    label: const Text('Login'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
