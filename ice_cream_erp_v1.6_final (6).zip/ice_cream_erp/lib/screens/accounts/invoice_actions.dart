import 'dart:typed_data';
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../../database/app_database.dart';
import '../../services/invoice_pdf_service.dart';
import '../../services/settings_service.dart';
import '../../services/voucher_pdf_service.dart';

Future<List<int>> _bytes(AppDatabase db, int invoiceId) async {
  final inv = await (db.select(db.saleInvoices)..where((i) => i.id.equals(invoiceId))).getSingle();
  final lines = await (db.select(db.saleInvoiceLines)..where((l) => l.invoiceId.equals(invoiceId))).get();
  Party? party;
  if (inv.partyId != null) {
    party = await (db.select(db.parties)..where((p) => p.id.equals(inv.partyId!))).getSingleOrNull();
  }
  return InvoicePdfService.build(invoice: inv, lines: lines, party: party, company: await SettingsService(db).company());
}

Future<void> printInvoice(AppDatabase db, int invoiceId) async {
  final b = await _bytes(db, invoiceId);
  await Printing.layoutPdf(onLayout: (_) async => Uint8List.fromList(b));
}

Future<void> shareInvoice(AppDatabase db, int invoiceId, String invoiceNo) async {
  final b = await _bytes(db, invoiceId);
  await Printing.sharePdf(bytes: Uint8List.fromList(b), filename: '$invoiceNo.pdf');
}

/// Print / share chooser for one invoice.
Future<void> invoiceSheet(BuildContext context, AppDatabase db, int invoiceId, String invoiceNo) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(title: Text(invoiceNo, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          ListTile(
            leading: const Icon(Icons.print),
            title: const Text('প্রিন্ট করুন'),
            onTap: () async {
              Navigator.pop(ctx);
              await printInvoice(db, invoiceId);
            },
          ),
          ListTile(
            leading: const Icon(Icons.share),
            title: const Text('PDF শেয়ার (WhatsApp ইত্যাদি)'),
            onTap: () async {
              Navigator.pop(ctx);
              await shareInvoice(db, invoiceId, invoiceNo);
            },
          ),
        ],
      ),
    ),
  );
}


Future<Uint8List> _voucherBytes(AppDatabase db, int voucherId) async {
  final v = await (db.select(db.vouchers)..where((x) => x.id.equals(voucherId))).getSingle();
  final lines = await (db.select(db.voucherLines)..where((l) => l.voucherId.equals(voucherId))).get();
  Party? party;
  if (v.partyId != null) {
    party = await (db.select(db.parties)..where((p) => p.id.equals(v.partyId!))).getSingleOrNull();
  }
  return VoucherPdfService.build(voucher: v, lines: lines, party: party, company: await SettingsService(db).company());
}

Future<void> printVoucher(AppDatabase db, int voucherId) async {
  final b = await _voucherBytes(db, voucherId);
  await Printing.layoutPdf(onLayout: (_) async => b);
}

Future<void> shareVoucher(AppDatabase db, int voucherId, String voucherNo) async {
  final b = await _voucherBytes(db, voucherId);
  await Printing.sharePdf(bytes: b, filename: '$voucherNo.pdf');
}

/// Print / share chooser for one accounting voucher.
Future<void> voucherSheet(BuildContext context, AppDatabase db, int voucherId, String voucherNo) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(title: Text(voucherNo, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          ListTile(
            leading: const Icon(Icons.print),
            title: const Text('ভাউচার প্রিন্ট করুন'),
            onTap: () async {
              Navigator.pop(ctx);
              await printVoucher(db, voucherId);
            },
          ),
          ListTile(
            leading: const Icon(Icons.share),
            title: const Text('PDF শেয়ার'),
            onTap: () async {
              Navigator.pop(ctx);
              await shareVoucher(db, voucherId, voucherNo);
            },
          ),
        ],
      ),
    ),
  );
}
