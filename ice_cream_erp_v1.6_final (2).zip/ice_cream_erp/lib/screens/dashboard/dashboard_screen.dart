import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/alarm_service.dart';
import '../../services/settings_service.dart';
import '../../services/stage_service.dart';
import '../../utils/ui.dart';
import 'flow_painters.dart';

class _Data {
  _Data({
    required this.orders,
    required this.recipes,
    required this.checks,
    required this.tanks,
    required this.cartons,
    required this.kBatches,
    required this.kRunning,
    required this.kDone,
    required this.kAllPass,
    required this.selAllPass,
  });
  final List<ProductionOrder> orders;
  final Map<int, Recipe> recipes;
  final Map<String, StageCheck> checks; // selected order, by stage key
  final List<Tank> tanks;
  final double cartons;
  final int kBatches, kRunning, kDone, kAllPass;
  final bool selAllPass;
}

class _FS {
  const _FS(this.bn, this.en, this.param);
  final String bn;
  final String en;
  final String param;
}

const List<_FS> _flow = [
  _FS('কাঁচামাল গ্রহণ', 'Raw Materials Receiving', 'দুধ • ক্রিম • চিনি • স্টেবিলাইজার • ফ্লেভার'),
  _FS('মিক্সিং ও ব্লেন্ডিং', 'Mixing & Blending', 'সব উপাদান সমানভাবে মেশানো'),
  _FS('পাস্তুরাইজেশন (HTST)', 'Pasteurization', '72–85°C (১৫–৩০ সেকেন্ড)'),
  _FS('হোমোজেনাইজেশন', 'Homogenization', '১৫০–২৫০ bar'),
  _FS('এজিং', 'Aging', '২–৮°C (৪–১২ ঘণ্টা)'),
  _FS('ব্যাচ ফ্রিজিং', 'Batch Freezing (Overrun)', '-৪ থেকে -৭°C • ওভাররান ৩০–৮০%'),
  _FS('হার্ডেনিং', 'Hardening', '-২৫ থেকে -৪০°C'),
  _FS('প্যাকেজিং', 'Packaging', 'কাপ • কোন • স্টিক • ফ্যামিলি প্যাক'),
  _FS('কোয়ালিটি কন্ট্রোল', 'Quality Control', 'ফিজিক্যাল • কেমিক্যাল • মাইক্রোবায়োলজি'),
  _FS('কোল্ড স্টোরেজ ও ডিস্ট্রিবিউশন', 'Cold Storage & Distribution', '-১৮°C বা তার নিচে'),
];

/// Flow step -> stage-sheet key (for recorded values).
const Map<int, String> _keyOf = {
  1: 'Mixing',
  2: 'Pasteurization',
  3: 'Homogenization',
  4: 'Aging',
  5: 'Freezing',
  7: 'Packing',
};

const _navy = Color(0xFF0B3D91);
const _blue = Color(0xFF1E6BE0);
const _green = Color(0xFF2EA86B);
const _red = Color(0xFFD94B4B);
const _amber = Color(0xFFE59A12);
const _grey = Color(0xFF7D8FA3);

class _Run {
  _Run(this.state, this.prog, this.remain, this.mins, this.totalSec, this.remainSec, this.overall, this.started);
  final List<int> state; // 0 wait, 1 running, 2 done  (10 steps)
  final List<double> prog;
  final List<int> remain; // seconds left for the running timed step, else -1
  final List<double> mins; // planned minutes for the 7 timed steps
  final int totalSec;
  final int remainSec;
  final double overall;
  final bool started;

  int get timedDone {
    var n = 0;
    for (var i = 1; i <= 7; i++) {
      if (state[i] == 2) n++;
    }
    return n;
  }
}

/// Control-room style dashboard: live, time-driven flow of the selected batch.
class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _anim;
  final List<StreamSubscription<dynamic>> _subs = [];
  Timer? _debounce;
  Timer? _tick;
  _Data? _d;
  int? _sel;
  bool _busy = false;
  DateTime _now = DateTime.now();
  final Map<int, int> _lastDone = {};

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();
    final db = ref.read(databaseProvider);
    _subs.add(db.select(db.productionOrders).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.stageChecks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.tanks).watch().listen((_) => _schedule()));
    _subs.add(db.select(db.packingRuns).watch().listen((_) => _schedule()));
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _now = DateTime.now();
      _checkAlarms();
      setState(() {});
    });
    _schedule();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _tick?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _anim.dispose();
    super.dispose();
  }

  void _schedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 150), _load);
  }

  Future<void> _load() async {
    if (_busy || !mounted) return;
    _busy = true;
    try {
      final db = ref.read(databaseProvider);
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final end = start.add(const Duration(days: 1));
      final all = await (db.select(db.productionOrders)
            ..orderBy([(o) => OrderingTerm.desc(o.id)])
            ..limit(80))
          .get();
      bool isRunning(ProductionOrder o) => o.status == 'Mixing' || o.status == 'Aging' || o.status == 'Freezing';
      bool isToday(ProductionOrder o) {
        final d = o.plannedDate ?? o.createdAt;
        return !d.isBefore(start) && d.isBefore(end);
      }

      var list = all.where((o) => o.status != 'Cancelled' && (isRunning(o) || isToday(o))).toList();
      if (list.isEmpty) list = all.where((o) => o.status != 'Cancelled').take(3).toList();

      final recs = await db.select(db.recipes).get();
      final tanks = await (db.select(db.tanks)..orderBy([(t) => OrderingTerm.asc(t.tankCode)])).get();

      int? sel = _sel;
      if (sel == null || !list.any((o) => o.id == sel)) {
        final run = list.where(isRunning).toList();
        sel = run.isNotEmpty ? run.first.id : (list.isNotEmpty ? list.first.id : null);
      }

      final ids = list.map((o) => o.id).toList();
      final allChecks = ids.isEmpty
          ? <StageCheck>[]
          : await (db.select(db.stageChecks)..where((c) => c.productionOrderId.isIn(ids))).get();
      var allPass = 0;
      var selPass = false;
      for (final id in ids) {
        final ok = StageService.isAllPass(allChecks.where((c) => c.productionOrderId == id).toList());
        if (ok) allPass++;
        if (id == sel) selPass = ok;
      }

      final checks = <String, StageCheck>{
        for (final c in allChecks.where((c) => c.productionOrderId == sel)) c.stage: c,
      };
      var cartons = 0.0;
      if (sel != null) {
        final runs = await (db.select(db.packingRuns)..where((r) => r.orderId.equals(sel!))).get();
        cartons = runs.fold<double>(0, (s, r) => s + r.cartons);
      }

      if (!mounted) return;
      setState(() {
        _sel = sel;
        _d = _Data(
          orders: list,
          recipes: {for (final r in recs) r.id: r},
          checks: checks,
          tanks: tanks,
          cartons: cartons,
          kBatches: list.where(isToday).length,
          kRunning: list.where(isRunning).length,
          kDone: list.where((o) => o.status == 'Completed').length,
          kAllPass: allPass,
          selAllPass: selPass,
        );
      });
    } finally {
      _busy = false;
    }
  }

  Future<void> _refresh() async {
    try {
      await _load();
    } catch (_) {}
  }

  // ---------- timeline ----------
  static List<double> _mins(Recipe? r) {
    final def = <double>[5, 1, 5, (r?.agingHours ?? 4.0) * 60, 8, 120, 30];
    final parts = (r?.stageMins ?? '').split(',');
    final out = <double>[];
    for (var i = 0; i < 7; i++) {
      final v = i < parts.length ? double.tryParse(parts[i].trim()) : null;
      out.add(v != null && v > 0 ? v : def[i]);
    }
    return out;
  }

  _Run _timeline(ProductionOrder? o, Recipe? r, bool allPass) {
    final st = List<int>.filled(10, 0);
    final pr = List<double>.filled(10, 0.0);
    final rem = List<int>.filled(10, -1);
    final mins = _mins(r);
    final total = mins.fold<double>(0, (a, b) => a + b);
    if (o == null) return _Run(st, pr, rem, mins, (total * 60).round(), (total * 60).round(), 0, false);
    final done = o.status == 'Completed';
    final start = o.startDate;
    var elapsed = start == null ? -1.0 : _now.difference(start).inMilliseconds / 60000.0;
    if (done) elapsed = total + 1;
    final started = elapsed >= 0;
    if (started) {
      st[0] = 2;
      pr[0] = 1;
    }
    var acc = 0.0;
    for (var k = 0; k < 7; k++) {
      final idx = k + 1;
      final s = acc;
      final e = acc + mins[k];
      if (started) {
        if (elapsed >= e) {
          st[idx] = 2;
          pr[idx] = 1;
        } else if (elapsed >= s) {
          st[idx] = 1;
          pr[idx] = (elapsed - s) / (e - s);
          rem[idx] = ((e - elapsed) * 60).ceil();
        }
      }
      acc = e;
    }
    if (st[7] == 2) {
      final passed = allPass || o.qcStatus == 'Passed' || done;
      st[8] = passed ? 2 : 1;
      pr[8] = passed ? 1 : 0.5;
      if (passed) {
        st[9] = done ? 2 : 1;
        pr[9] = done ? 1 : 0.6;
      }
    }
    final overall = !started ? 0.0 : (elapsed / total).clamp(0.0, 1.0).toDouble();
    final totalSec = (total * 60).round();
    final remainSec = !started ? totalSec : ((total - elapsed) * 60).ceil().clamp(0, totalSec * 2).toInt();
    return _Run(st, pr, rem, mins, totalSec, remainSec, overall, started);
  }

  bool get _alarmOn => ref.read(settingsMapProvider).valueOrNull?['dash_alarm'] != '0';

  void _checkAlarms() {
    final d = _d;
    if (d == null) return;
    for (final o in d.orders) {
      if (o.startDate == null || o.status == 'Completed' || o.status == 'Cancelled') continue;
      final tl = _timeline(o, d.recipes[o.recipeId], false);
      final n = tl.timedDone;
      final prev = _lastDone[o.id];
      _lastDone[o.id] = n;
      if (prev != null && n > prev) {
        var idx = 1;
        for (var i = 1; i <= 7; i++) {
          if (tl.state[i] == 2) idx = i;
        }
        final msg = n >= 7
            ? '🔔 ${o.orderNo}: সব ধাপ শেষ'
            : '🔔 ${o.orderNo}: ${_flow[idx].bn} শেষ — পরের ধাপ শুরু';
        if (_alarmOn) AlarmService.ring();
        final m = ScaffoldMessenger.maybeOf(context);
        m?.hideCurrentSnackBar();
        m?.showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 6)));
      }
    }
  }

  Future<void> _toggleAlarm() async {
    final next = !_alarmOn;
    try {
      await ref.read(settingsServiceProvider).set('dash_alarm', next ? '1' : '0');
    } catch (_) {}
    if (next) AlarmService.ring();
  }

  // ---------- helpers ----------
  static String _clock(int sec) {
    final s = sec < 0 ? 0 : sec;
    String p(int v) => v.toString().padLeft(2, '0');
    final h = s ~/ 3600;
    final m = (s % 3600) ~/ 60;
    final x = s % 60;
    return h > 0 ? '$h:${p(m)}:${p(x)}' : '${p(m)}:${p(x)}';
  }

  static String _minLabel(double m) => m >= 60 ? '${fmtQty(m / 60)} ঘণ্টা' : '${fmtQty(m)} মিনিট';

  static String _hm(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  String _tempFor(int i, Map<String, StageCheck> ch) {
    final c = ch[_keyOf[i]];
    switch (i) {
      case 2:
        return c?.tempValue != null ? '${fmtQty(c!.tempValue!)}°C' : '72°C';
      case 3:
        return c?.pressureBar != null ? '${fmtQty(c!.pressureBar!)} bar' : '200 bar';
      case 4:
        return c?.tempValue != null ? '${fmtQty(c!.tempValue!)}°C' : '4°C';
      case 5:
        return c?.tempValue != null ? '${fmtQty(c!.tempValue!)}°C' : '-5°C';
      case 6:
        return '-30°C';
      case 9:
        return '-18°C';
      default:
        return '';
    }
  }

  Widget _led(Color c, {bool pulse = false}) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        final glow = pulse ? 0.5 + 0.5 * (1 - (_anim.value * 2 - 1).abs()) : 0.6;
        return Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: c,
            boxShadow: [BoxShadow(color: c.withAlpha((200 * glow).round()), blurRadius: 7, spreadRadius: 1)],
          ),
        );
      },
    );
  }

  Widget _kpi(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.fromLTRB(9, 8, 6, 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFD5E2F0)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: color)),
            Text(label, style: const TextStyle(fontSize: 9.5, color: _grey), maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _header(Company co) {
    final on = _alarmOn;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 12, 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0A3A8C), Color(0xFF1767DB)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: _navy.withAlpha(70), blurRadius: 14, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Modern Ice Cream Industry',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Colors.white)),
                  Text('Process Flow Diagram',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Color(0xFFFFE600))),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(mainAxisSize: MainAxisSize.min, children: [
                  _led(const Color(0xFF45E08A), pulse: true),
                  const SizedBox(width: 5),
                  const Text('LIVE',
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, color: Color(0xFF45E08A))),
                ]),
                const SizedBox(height: 3),
                Text('${_hm(_now)}:${_now.second.toString().padLeft(2, '0')}',
                    style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontFeatures: [FontFeature.tabularFigures()])),
              ],
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Text(co.shownName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600)),
            ),
            InkWell(
              onTap: _toggleAlarm,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: on ? Colors.white : Colors.white24,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(on ? Icons.notifications_active_rounded : Icons.notifications_off_rounded,
                      size: 16, color: on ? _navy : Colors.white70),
                  const SizedBox(width: 5),
                  Text(on ? 'এলার্ম অন' : 'এলার্ম অফ',
                      style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: on ? _navy : Colors.white70)),
                ]),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _batchCard(ProductionOrder? o, _Data d, _Run tl) {
    if (o == null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFD5E2F0))),
        child: const Text('কোনো ব্যাচ নেই। Home থেকে “আজকের ব্যাচ” দিয়ে ব্যাচ শুরু করুন — তারপর এখানে লাইভ চলবে।',
            style: TextStyle(color: _grey, fontSize: 12.5)),
      );
    }
    final r = d.recipes[o.recipeId];
    final start = o.startDate;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD5E2F0)),
        boxShadow: [BoxShadow(color: _navy.withAlpha(18), blurRadius: 8, offset: const Offset(0, 3))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text('${o.orderNo} • ${r?.recipeName ?? ''}',
                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: _navy)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _blue.withAlpha(24), borderRadius: BorderRadius.circular(10)),
              child: Text(o.status, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: _blue)),
            ),
          ]),
          const SizedBox(height: 3),
          Text(
            tl.started
                ? '${fmtQty(o.targetQty)} L • শুরু ${_hm(start!)} • মোট ${_clock(tl.totalSec)} • বাকি ${_clock(tl.remainSec)}'
                : '${fmtQty(o.targetQty)} L • এখনো শুরু হয়নি (মোট ${_clock(tl.totalSec)})',
            style: const TextStyle(fontSize: 11, color: _grey),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: tl.overall,
              minHeight: 8,
              backgroundColor: const Color(0xFFE3ECF6),
              valueColor: AlwaysStoppedAnimation<Color>(tl.overall >= 1 ? _green : _blue),
            ),
          ),
          const SizedBox(height: 3),
          Text('${(tl.overall * 100).round()}% সম্পন্ন', style: const TextStyle(fontSize: 10.5, color: _grey)),
        ],
      ),
    );
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(color: c.withAlpha(28), borderRadius: BorderRadius.circular(8)),
        child: Text(t, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: c)),
      );

  Widget _stageCard(int i, _Data d, _Run tl) {
    final fs = _flow[i];
    final st = tl.state[i];
    final accent = st == 2 ? _green : (st == 1 ? _blue : _grey);
    final chk = d.checks[_keyOf[i]];
    final timed = i >= 1 && i <= 7;
    final info = <Widget>[
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(color: const Color(0xFFE4F0FD), borderRadius: BorderRadius.circular(10)),
        child: Text(fs.param, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _navy)),
      ),
      const SizedBox(height: 6),
    ];
    if (timed) {
      info.add(Text('নির্ধারিত: ${_minLabel(tl.mins[i - 1])}', style: const TextStyle(fontSize: 10.5, color: _grey)));
      info.add(const SizedBox(height: 4));
    }
    if (st == 1 && tl.remain[i] >= 0) {
      info.addAll([
        const Text('বাকি সময়', style: TextStyle(fontSize: 10, color: _grey)),
        Text(_clock(tl.remain[i]),
            style: const TextStyle(
                fontSize: 23, fontWeight: FontWeight.w900, color: _blue, fontFeatures: [FontFeature.tabularFigures()])),
        const SizedBox(height: 3),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: tl.prog[i],
            minHeight: 6,
            backgroundColor: const Color(0xFFE3ECF6),
            valueColor: const AlwaysStoppedAnimation<Color>(_blue),
          ),
        ),
      ]);
    } else if (st == 1) {
      info.add(Text(i == 8 ? 'পরীক্ষা চলছে… (ধাপ-সিটে সব পাস দিন)' : 'প্রক্রিয়া চলছে…',
          style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: _amber)));
    } else if (st == 2) {
      info.add(Row(children: const [
        Icon(Icons.check_circle_rounded, size: 17, color: _green),
        SizedBox(width: 5),
        Text('সম্পন্ন', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: _green)),
      ]));
    } else {
      info.add(const Text('অপেক্ষায়', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _grey)));
    }
    if (i == 7 && d.cartons > 0) {
      info.add(const SizedBox(height: 4));
      info.add(_chip('প্যাক: ${fmtQty(d.cartons)} কার্টন', _green));
    }
    if (chk != null) {
      info.add(const SizedBox(height: 5));
      info.add(Wrap(spacing: 4, runSpacing: 3, children: [
        _chip(chk.result == 'Pass' ? 'পাস' : (chk.result == 'Fail' ? 'ফেল' : 'স্কিপ'),
            chk.result == 'Pass' ? _green : (chk.result == 'Fail' ? _red : _grey)),
        if (chk.tempValue != null) _chip('${fmtQty(chk.tempValue!)}°C', _navy),
        if (chk.pressureBar != null) _chip('${fmtQty(chk.pressureBar!)} bar', _navy),
        if (chk.durationMin != null) _chip('${fmtQty(chk.durationMin!)} মি', _navy),
      ]));
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: st == 1 ? _blue : (st == 2 ? const Color(0xFFBFE8CF) : const Color(0xFFD5E2F0)),
          width: st == 1 ? 2 : 1,
        ),
        boxShadow: [BoxShadow(color: (st == 1 ? _blue : _navy).withAlpha(st == 1 ? 55 : 20), blurRadius: st == 1 ? 16 : 8, offset: const Offset(0, 3))],
      ),
      child: Column(
        children: [
          Row(children: [
            Container(
              width: 30,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(shape: BoxShape.circle, color: st == 2 ? _green : _navy),
              child: st == 2
                  ? const Icon(Icons.check_rounded, size: 18, color: Colors.white)
                  : Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(fs.bn, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: _navy)),
                  Text(fs.en, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: _grey)),
                ],
              ),
            ),
            _chip(st == 2 ? 'সম্পন্ন' : (st == 1 ? 'চলছে' : 'অপেক্ষা'), accent),
          ]),
          const SizedBox(height: 10),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 148,
              height: 111,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFEFF6FE), Color(0xFFD9E9F8)]),
                borderRadius: BorderRadius.circular(14),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: CustomPaint(painter: FlowPainter(i, _anim, st, tl.prog[i], _tempFor(i, d.checks))),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: info)),
          ]),
        ],
      ),
    );
  }

  Widget _arrow(int i, _Run tl) {
    final flowing = tl.state[i] == 1 || (tl.state[i] == 2 && tl.state[i + 1] == 1);
    return SizedBox(
      height: 34,
      width: double.infinity,
      child: CustomPaint(painter: FlowArrowPainter(_anim, flowing, tl.state[i] == 2)),
    );
  }

  Widget _tankCard(Tank t) {
    final pct = t.capacityLiter > 0 ? (t.currentQty / t.capacityLiter).clamp(0.0, 1.0).toDouble() : 0.0;
    final col = t.tankType == 'Aging' ? _blue : (t.tankType == 'Mixing' ? const Color(0xFF14A7C9) : _green);
    final led = t.status == 'InUse' ? _amber : (t.status == 'Cleaning' ? _blue : _green);
    final w = (MediaQuery.of(context).size.width - 16 * 2 - 8) / 2;
    return Container(
      width: w,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFD5E2F0))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(child: Text(t.tankCode, style: const TextStyle(fontWeight: FontWeight.w800, color: _navy, fontSize: 13))),
            _led(led, pulse: t.status == 'InUse'),
          ]),
          Text('${t.tankType} • ${t.status}', style: const TextStyle(fontSize: 10, color: _grey)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(value: pct, minHeight: 10, backgroundColor: const Color(0xFFE3ECF6), valueColor: AlwaysStoppedAnimation<Color>(col)),
          ),
          const SizedBox(height: 4),
          Text('${fmtQty(t.currentQty)} / ${fmtQty(t.capacityLiter)} L • ${(pct * 100).round()}%',
              style: const TextStyle(fontSize: 10.5, color: _grey)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final co = ref.watch(companyProvider);
    ref.watch(settingsMapProvider); // rebuild when alarm toggle changes
    final d = _d;
    const bg = BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFE3EFFB), Color(0xFFF7FAFE)]),
    );
    if (d == null) {
      return const Scaffold(
        body: DecoratedBox(decoration: bg, child: Center(child: CircularProgressIndicator())),
      );
    }
    ProductionOrder? sel;
    for (final o in d.orders) {
      if (o.id == _sel) sel = o;
    }
    final tl = _timeline(sel, sel == null ? null : d.recipes[sel.recipeId], d.selAllPass);

    return Scaffold(
      backgroundColor: const Color(0xFFEFF5FC),
      body: DecoratedBox(
        decoration: bg,
        child: SafeArea(
          child: RefreshIndicator(
            color: _blue,
            backgroundColor: Colors.white,
            onRefresh: _refresh,
            child: ScrollConfiguration(
              behavior: ScrollConfiguration.of(context).copyWith(overscroll: false),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _header(co),
                    const SizedBox(height: 12),
                    Row(children: [
                      _kpi('আজকের ব্যাচ', '${d.kBatches}', _blue, Icons.layers_rounded),
                      _kpi('চলমান', '${d.kRunning}', _amber, Icons.sync_rounded),
                      _kpi('সম্পন্ন', '${d.kDone}', _green, Icons.check_circle_rounded),
                      _kpi('সব পাস', '${d.kAllPass}', const Color(0xFF7B5CE0), Icons.verified_rounded),
                    ]),
                    const SizedBox(height: 12),
                    if (d.orders.length > 1)
                      SizedBox(
                        height: 38,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            for (final o in d.orders)
                              Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: ChoiceChip(
                                  label: Text(o.orderNo, style: const TextStyle(fontSize: 12)),
                                  selected: o.id == _sel,
                                  onSelected: (_) {
                                    setState(() => _sel = o.id);
                                    _load();
                                  },
                                ),
                              ),
                          ],
                        ),
                      ),
                    if (d.orders.length > 1) const SizedBox(height: 10),
                    _batchCard(sel, d, tl),
                    const SizedBox(height: 12),
                    for (var i = 0; i < _flow.length; i++) ...[
                      RepaintBoundary(child: _stageCard(i, d, tl)),
                      if (i < _flow.length - 1) _arrow(i, tl),
                    ],
                    const SizedBox(height: 18),
                    const Text('ট্যাংক লেভেল', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: _navy)),
                    const SizedBox(height: 8),
                    if (d.tanks.isEmpty)
                      const Text('কোনো ট্যাংক নেই', style: TextStyle(color: _grey))
                    else
                      Wrap(spacing: 8, runSpacing: 8, children: [for (final t in d.tanks) _tankCard(t)]),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
