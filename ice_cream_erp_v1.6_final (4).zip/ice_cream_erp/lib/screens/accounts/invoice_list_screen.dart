import 'package:drift/drift.dart' hide Batch, Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../database/app_database.dart';
import '../../providers/database_provider.dart';
import '../../utils/ui.dart';
import 'invoice_actions.dart';

class InvoiceListScreen extends ConsumerWidget {
  const InvoiceListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Invoices')),
      body: StreamBuilder<List<SaleInvoice>>(
        stream: (db.select(db.saleInvoices)..orderBy([(i) => OrderingTerm.desc(i.id)])).watch(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('এখনো কোনো ইনভয়েস নেই'));
          return ListView.builder(
            padding: const EdgeInsets.all(10),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final inv = list[i];
              return Card(
                child: ListTile(
                  title: Text(inv.invoiceNo, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${fmtDate(inv.invoiceDate)} • ${inv.receivedNow ? 'পরিশোধিত' : 'বাকি'}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(fmtMoney(inv.total), style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(width: 6),
                      const Icon(Icons.print),
                    ],
                  ),
                  onTap: () => invoiceSheet(context, db, inv.id, inv.invoiceNo),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
