import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/settings_service.dart';
import 'database_provider.dart';

final settingsServiceProvider = Provider<SettingsService>((ref) => SettingsService(ref.watch(databaseProvider)));
final backupServiceProvider = Provider<BackupService>((ref) => BackupService(ref.watch(databaseProvider)));

/// Live map of all settings (company, tab names, backup flags).
final settingsMapProvider = StreamProvider<Map<String, String>>((ref) => ref.watch(settingsServiceProvider).watch());

final companyProvider = Provider<Company>((ref) => Company.from(ref.watch(settingsMapProvider).valueOrNull));
