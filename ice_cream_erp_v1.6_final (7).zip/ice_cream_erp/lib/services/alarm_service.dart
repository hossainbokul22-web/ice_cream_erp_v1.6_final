import 'dart:math' as math;
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

/// Short bell-like alarm, generated in code (no asset file needed).
class AlarmService {
  static final AudioPlayer _player = AudioPlayer();
  static Uint8List? _bytes;

  static Uint8List _wav() {
    const rate = 16000;
    final samples = <int>[];
    void tone(double f, double sec) {
      final n = (rate * sec).round();
      final fade = rate * 0.015;
      for (var i = 0; i < n; i++) {
        final env = math.min(1.0, math.min(i, n - i) / fade);
        final v = math.sin(2 * math.pi * f * i / rate) * 0.7 * env;
        samples.add((v * 32767).round());
      }
    }

    void gap(double sec) => samples.addAll(List<int>.filled((rate * sec).round(), 0));

    tone(880, 0.22);
    gap(0.08);
    tone(1175, 0.22);
    gap(0.08);
    tone(880, 0.22);
    gap(0.08);
    tone(1175, 0.45);

    final dataLen = samples.length * 2;
    final b = ByteData(44 + dataLen);
    void ascii(int off, String s) {
      for (var i = 0; i < s.length; i++) {
        b.setUint8(off + i, s.codeUnitAt(i));
      }
    }

    ascii(0, 'RIFF');
    b.setUint32(4, 36 + dataLen, Endian.little);
    ascii(8, 'WAVE');
    ascii(12, 'fmt ');
    b.setUint32(16, 16, Endian.little);
    b.setUint16(20, 1, Endian.little);
    b.setUint16(22, 1, Endian.little);
    b.setUint32(24, rate, Endian.little);
    b.setUint32(28, rate * 2, Endian.little);
    b.setUint16(32, 2, Endian.little);
    b.setUint16(34, 16, Endian.little);
    ascii(36, 'data');
    b.setUint32(40, dataLen, Endian.little);
    for (var i = 0; i < samples.length; i++) {
      b.setInt16(44 + i * 2, samples[i], Endian.little);
    }
    return b.buffer.asUint8List();
  }

  static Future<void> ring() async {
    try {
      HapticFeedback.heavyImpact();
    } catch (_) {}
    try {
      _bytes ??= _wav();
      await _player.stop();
      await _player.play(BytesSource(_bytes!));
    } catch (_) {
      // Sound is best-effort; the on-screen banner still shows.
    }
  }
}
