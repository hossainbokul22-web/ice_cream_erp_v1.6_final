import 'dart:math' as math;
import 'package:flutter/material.dart';

/// One plant unit (tank or freezer) on the factory-floor map.
/// kind: 0 mixing tank, 1 aging tank, 2 freezer.
/// state: 0 idle, 1 working, 3 waiting for the operator, 4 cleaning.
/// level: liquid fill 0..1.
class UnitPainter extends CustomPainter {
  UnitPainter(this.kind, this.anim, this.state, this.level) : super(repaint: anim);

  final int kind;
  final Animation<double> anim;
  final int state;
  final double level;

  double get t => anim.value;
  bool get work => state == 1;
  double get ang => work ? t * 2 * math.pi : 0.0;

  Paint _line([double w = 1.1, Color c = const Color(0xFF55636F)]) => Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..color = c;

  Paint _solid(Color c) => Paint()..color = c;

  Paint _metal(Rect r, {bool ice = false}) => Paint()
    ..shader = LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: ice
          ? const [Color(0xFF9CC3E0), Color(0xFFE9F5FF), Color(0xFFFFFFFF), Color(0xFFBBD9EE), Color(0xFF86AFCD)]
          : const [Color(0xFF8E9BA8), Color(0xFFE3E9EF), Color(0xFFFFFFFF), Color(0xFFC5CED7), Color(0xFF7F8C99)],
      stops: const [0.0, 0.28, 0.48, 0.78, 1.0],
    ).createShader(r);

  void _motor(Canvas c, double cx, double top) {
    final r = Rect.fromLTWH(cx - 7, top, 14, 11);
    c.drawRRect(
      RRect.fromRectAndRadius(r, const Radius.circular(2.5)),
      Paint()
        ..shader = const LinearGradient(colors: [Color(0xFF0F3F9E), Color(0xFF2F7BEF), Color(0xFF0F3F9E)]).createShader(r),
    );
    c.drawRect(Rect.fromLTWH(cx - 2.5, top + 11, 5, 4), _solid(const Color(0xFF7F8C99)));
  }

  void _tank(Canvas c, {required bool ice}) {
    const r = Rect.fromLTWH(18, 26, 44, 52);
    final body = RRect.fromRectAndCorners(
      r,
      topLeft: const Radius.circular(8),
      topRight: const Radius.circular(8),
      bottomLeft: const Radius.circular(15),
      bottomRight: const Radius.circular(15),
    );
    c.drawRect(const Rect.fromLTWH(24, 75, 4, 12), _solid(const Color(0xFF7F8C99)));
    c.drawRect(const Rect.fromLTWH(52, 75, 4, 12), _solid(const Color(0xFF7F8C99)));
    c.drawRRect(body, _metal(r, ice: ice));
    c.save();
    c.clipRRect(body.deflate(3));
    final lvl = level < 0 ? 0.0 : (level > 1 ? 1.0 : level);
    if (lvl > 0.01) {
      final y0 = r.bottom - r.height * lvl;
      final path = Path()..moveTo(r.left, r.bottom + 2);
      for (double x = r.left; x <= r.right; x += 2) {
        path.lineTo(x, y0 + (work ? 1.4 * math.sin(x / 6 + t * 2 * math.pi) : 0.0));
      }
      path
        ..lineTo(r.right, r.bottom + 2)
        ..close();
      c.drawPath(path, _solid(ice ? const Color(0xFFFFF0C9) : const Color(0xFFFFE9B8)));
    }
    final spin = ice ? 0.35 : 1.0;
    c.drawLine(const Offset(40, 28), const Offset(40, 70), _line(1.5));
    final a = math.cos(ang * 2 * spin);
    c.drawLine(Offset(40 - 15 * a, 64), Offset(40 + 15 * a, 64), _line(2.2));
    c.drawLine(Offset(40 - 11 * math.sin(ang * 2 * spin + 1.2), 50), Offset(40 + 11 * math.sin(ang * 2 * spin + 1.2), 50), _line(1.8));
    c.restore();
    c.drawRRect(body, _line());
    const lid = Rect.fromLTWH(20, 23, 40, 7);
    c.drawOval(lid, _metal(lid, ice: ice));
    c.drawOval(lid, _line(0.8));
    _motor(c, 40, 9);
    if (ice) {
      // cooling jacket bands + snow
      for (var i = 0; i < 3; i++) {
        c.drawLine(Offset(20, 40.0 + i * 12), Offset(60, 40.0 + i * 12), _line(0.8, const Color(0xFF6FA6D2)));
      }
      if (state != 0) {
        for (var i = 0; i < 6; i++) {
          final a2 = (work ? t * 1.2 : 0.0) + i * math.pi / 3;
          c.drawLine(const Offset(40, 48), Offset(40 + 5 * math.cos(a2), 48 + 5 * math.sin(a2)), _line(1, const Color(0xFF1E6BE0)));
        }
      }
    }
  }

  void _freezer(Canvas c) {
    const r = Rect.fromLTWH(20, 28, 40, 50);
    final rr = RRect.fromRectAndRadius(r, const Radius.circular(8));
    c.drawRect(const Rect.fromLTWH(24, 76, 4, 11), _solid(const Color(0xFF7F8C99)));
    c.drawRect(const Rect.fromLTWH(52, 76, 4, 11), _solid(const Color(0xFF7F8C99)));
    c.drawRRect(
      rr,
      Paint()
        ..shader = const LinearGradient(colors: [Color(0xFFA9D5EE), Color(0xFFFFFFFF), Color(0xFFB7DDF2)]).createShader(r),
    );
    c.save();
    c.clipRRect(rr.deflate(3));
    final lvl = level < 0 ? 0.0 : (level > 1 ? 1.0 : level);
    if (lvl > 0.01) {
      c.drawRect(Rect.fromLTRB(r.left, r.bottom - r.height * lvl, r.right, r.bottom), _solid(const Color(0xFFFFF3D6)));
    }
    for (var k = 0; k < 3; k++) {
      final off = math.cos(ang * 3 + k * 2.09) * 13;
      c.drawLine(Offset(40 + off, 32), Offset(40 + off, 74), _line(2, const Color(0xFF7F8C99)));
    }
    c.drawLine(const Offset(40, 28), const Offset(40, 78), _line(1.8));
    c.restore();
    c.drawRRect(rr, _line());
    _motor(c, 40, 11);
    if (state != 0) {
      for (var i = 0; i < 5; i++) {
        final p = (t * 1.5 + i / 5) % 1.0;
        c.drawCircle(Offset(24.0 + (i * 8) % 34, 34.0 + (i * 11) % 38), 1.1, _solid(Colors.white.withAlpha((255 * math.sin(p * math.pi)).round())));
      }
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 80, size.height / 96);
    // floor shadow
    canvas.drawOval(const Rect.fromLTWH(10, 88, 60, 6), _solid(const Color(0x1F0B3D91)));
    // waiting: pulsing amber glow behind
    if (state == 3) {
      final g = 0.5 + 0.5 * math.sin(t * 2 * math.pi * 2);
      canvas.drawCircle(const Offset(40, 52), 36, _solid(const Color(0xFFFFB300).withAlpha((70 * g + 20).round())));
    }
    if (kind == 2) {
      _freezer(canvas);
    } else {
      _tank(canvas, ice: kind == 1);
    }
    if (state == 4) {
      // cleaning droplets
      for (var i = 0; i < 4; i++) {
        final p = (t + i / 4) % 1.0;
        canvas.drawCircle(Offset(26.0 + i * 9, 36 + p * 40), 1.8, _solid(const Color(0xFF5AB0F5).withAlpha((220 * (1 - p)).round())));
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant UnitPainter old) => old.kind != kind || old.state != state || old.level != level;
}
