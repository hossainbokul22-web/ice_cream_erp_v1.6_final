import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../database/app_database.dart';
import 'settings_service.dart';

/// Printable A4 accounting voucher (Payment / Receipt / Purchase / Sales / Journal).
/// Latin text only; non-Latin names fall back to codes / are skipped.
class VoucherPdfService {
  static final _date = DateFormat('dd-MMM-yyyy');
  static final _num = NumberFormat('#,##0.00');

  static String _a(String? s, [String fallback = '']) {
    if (s == null || s.trim().isEmpty) return fallback;
    return s.runes.every((r) => r < 128) ? s : fallback;
  }

  static String _title(String type) {
    switch (type) {
      case 'Payment':
        return 'PAYMENT VOUCHER';
      case 'Receipt':
        return 'RECEIPT VOUCHER';
      case 'Purchase':
        return 'PURCHASE VOUCHER';
      case 'Sales':
        return 'SALES VOUCHER';
      default:
        return 'JOURNAL VOUCHER';
    }
  }

  static Future<Uint8List> build({
    required Voucher voucher,
    required List<VoucherLine> lines,
    Party? party,
    Company? company,
  }) async {
    final co = company ?? Company();
    final doc = pw.Document();
    final bold = pw.TextStyle(fontWeight: pw.FontWeight.bold);
    final dr = lines.fold<double>(0, (s, l) => s + l.debit);
    final cr = lines.fold<double>(0, (s, l) => s + l.credit);
    pw.Widget sign(String t) => pw.Column(children: [
          pw.Container(width: 110, height: 1, color: PdfColors.grey700),
          pw.SizedBox(height: 4),
          pw.Text(t, style: const pw.TextStyle(fontSize: 9)),
        ]);

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.center, crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
          if (co.logo != null)
            pw.Padding(
              padding: const pw.EdgeInsets.only(right: 10),
              child: pw.Image(pw.MemoryImage(co.logo!), width: 48, height: 48, fit: pw.BoxFit.contain),
            ),
          pw.Column(children: [
            pw.Text(co.printName, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
            if (co.printAddress.isNotEmpty) pw.Text(co.printAddress, style: const pw.TextStyle(fontSize: 9)),
            if (co.printPhone.isNotEmpty) pw.Text('Phone: ${co.printPhone}', style: const pw.TextStyle(fontSize: 9)),
          ]),
        ]),
        pw.SizedBox(height: 2),
        pw.Center(child: pw.Text(_title(voucher.voucherType), style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: PdfColors.blueGrey800))),
        pw.Divider(),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Voucher No: ${voucher.voucherNo}', style: bold),
            pw.Text('Date: ${_date.format(voucher.voucherDate)}'),
          ],
        ),
        if (party != null) pw.Padding(padding: const pw.EdgeInsets.only(top: 4), child: pw.Text('Party: ${_a(party.partyName, party.partyCode)}')),
        pw.SizedBox(height: 12),
        pw.TableHelper.fromTextArray(
          headers: ['SL', 'Account / Ledger', 'Debit (Tk)', 'Credit (Tk)'],
          headerStyle: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
          cellStyle: const pw.TextStyle(fontSize: 10),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
          cellAlignments: {
            0: pw.Alignment.center,
            1: pw.Alignment.centerLeft,
            2: pw.Alignment.centerRight,
            3: pw.Alignment.centerRight,
          },
          data: [
            for (var i = 0; i < lines.length; i++)
              [
                '${i + 1}',
                _a(lines[i].ledgerName, 'Ledger'),
                lines[i].debit > 0 ? _num.format(lines[i].debit) : '',
                lines[i].credit > 0 ? _num.format(lines[i].credit) : '',
              ],
            ['', 'Total', _num.format(dr), _num.format(cr)],
          ],
        ),
        pw.SizedBox(height: 12),
        pw.Container(
          padding: const pw.EdgeInsets.all(8),
          decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600)),
          child: pw.Text('Amount: ${_num.format(voucher.totalAmount)} Tk', style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
        ),
        if (_a(voucher.narration).isNotEmpty)
          pw.Padding(padding: const pw.EdgeInsets.only(top: 8), child: pw.Text('Narration: ${_a(voucher.narration)}')),
        pw.SizedBox(height: 60),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [sign('Prepared by'), sign('Checked by'), sign('Approved by'), sign('Received by')],
        ),
      ],
    ));
    return doc.save();
  }
}
