import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:drift/drift.dart' hide Batch, Column;
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';

class Company {
  Company({this.name = '', this.nameEn = '', this.address = '', this.addressEn = '', this.phone = '', this.logo, this.bin = ''});
  final String bin;
  final String name;
  final String nameEn;
  final String address;
  final String addressEn;
  final String phone;
  final Uint8List? logo;

  String get shownName => name.trim().isEmpty ? 'Ice Cream ERP' : name.trim();

  /// For PDFs (Latin only): English name, else the name if it is Latin, else a default.
  String get printName {
    if (nameEn.trim().isNotEmpty) return nameEn.trim();
    final n = name.trim();
    if (n.isNotEmpty && n.runes.every((r) => r < 128)) return n;
    return 'Ice Cream Factory';
  }

  String get printAddress {
    if (addressEn.trim().isNotEmpty) return addressEn.trim();
    final a = address.trim();
    return a.runes.every((r) => r < 128) ? a : '';
  }

  String get printPhone => phone.trim().runes.every((r) => r < 128) ? phone.trim() : '';

  factory Company.from(Map<String, String>? m) {
    final x = m ?? const <String, String>{};
    Uint8List? logo;
    final b = x['logo'];
    if (b != null && b.isNotEmpty) {
      try {
        logo = base64Decode(b);
      } catch (_) {}
    }
    return Company(
      name: x['company_name'] ?? '',
      nameEn: x['company_name_en'] ?? '',
      address: x['company_address'] ?? '',
      addressEn: x['company_address_en'] ?? '',
      phone: x['company_phone'] ?? '',
      bin: x['company_bin'] ?? '',
      logo: logo,
    );
  }
}

String labelOf(Map<String, String>? m, String key, String def) {
  final v = m?['label_$key'];
  return (v == null || v.trim().isEmpty) ? def : v.trim();
}

/// Editable tab names: group title -> [key, default label].
const List<(String, List<(String, String)>)> kLabelGroups = [
  ('নিচের মেনু', [
    ('nav_dashboard', 'Dashboard'),
    ('nav_home', 'Home'),
    ('nav_production', 'Production'),
    ('nav_stock', 'Stock'),
    ('nav_vouchers', 'Vouchers'),
    ('nav_reports', 'Reports'),
  ]),
  ('Production ট্যাব', [
    ('prod_today', 'আজ'),
    ('prod_plan', 'আগামীকাল / প্ল্যান'),
    ('prod_done', 'শেষ'),
  ]),
  ('Stock ট্যাব', [
    ('stock_raw', 'কাঁচামাল'),
    ('stock_pack', 'প্যাকেজিং'),
    ('stock_mix', 'মিক্স'),
    ('stock_fin', 'ফিনিশ'),
  ]),
  ('Item Master ট্যাব', [
    ('item_all', 'সব'),
    ('item_raw', 'কাঁচামাল'),
    ('item_pack', 'প্যাকেজিং'),
    ('item_mix', 'মিক্স/সেমি'),
    ('item_fin', 'ফিনিশ'),
  ]),
  ('Tank ট্যাব', [
    ('tank_mixing', 'মিক্সিং ট্যাংক'),
    ('tank_aging', 'এজিং ট্যাংক'),
    ('tank_storage', 'স্টোরেজ'),
  ]),
];

class SettingsService {
  SettingsService(this.db);
  final AppDatabase db;

  Stream<Map<String, String>> watch() => db.select(db.appSettings).watch().map(
        (rows) => {for (final r in rows) r.settingKey: r.settingValue},
      );

  Future<Map<String, String>> all() async {
    final rows = await db.select(db.appSettings).get();
    return {for (final r in rows) r.settingKey: r.settingValue};
  }

  Future<void> set(String key, String value) => db.into(db.appSettings).insertOnConflictUpdate(
        AppSettingsCompanion.insert(settingKey: key, settingValue: value),
      );

  Future<void> setMany(Map<String, String> kv) async {
    await db.transaction(() async {
      for (final e in kv.entries) {
        await set(e.key, e.value);
      }
    });
  }

  Future<void> remove(String key) =>
      (db.delete(db.appSettings)..where((r) => r.settingKey.equals(key))).go();

  Future<Company> company() async => Company.from(await all());
}

/// Daily automatic backup (consistent SQLite copy) kept inside the app, last 7 days.
class BackupService {
  BackupService(this.db);
  final AppDatabase db;
  static const keepDays = 7;

  Future<Directory> _dir() async {
    final docs = await getApplicationDocumentsDirectory();
    final d = Directory(p.join(docs.path, 'backups'));
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<File> backupNow() async {
    final dir = await _dir();
    final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
    final path = p.join(dir.path, 'ice_cream_erp_$stamp.sqlite');
    final f = File(path);
    if (await f.exists()) await f.delete();
    await db.customStatement("VACUUM INTO '${path.replaceAll("'", "''")}'");
    await _prune(dir);
    await SettingsService(db).set('last_backup', DateTime.now().toIso8601String());
    return File(path);
  }

  Future<List<File>> list() async {
    final dir = await _dir();
    final files = (await dir.list().toList()).whereType<File>().where((f) => f.path.endsWith('.sqlite')).toList()
      ..sort((a, b) => b.path.compareTo(a.path));
    return files;
  }

  Future<void> _prune(Directory dir) async {
    final files = await list();
    for (var i = keepDays; i < files.length; i++) {
      try {
        await files[i].delete();
      } catch (_) {}
    }
  }

  /// Called at app start: backs up once per day when switched on.
  Future<void> autoIfDue() async {
    final s = await SettingsService(db).all();
    if (s['auto_backup'] != '1') return;
    final last = DateTime.tryParse(s['last_backup'] ?? '');
    final now = DateTime.now();
    if (last != null && last.year == now.year && last.month == now.month && last.day == now.day) return;
    await backupNow();
  }
}
