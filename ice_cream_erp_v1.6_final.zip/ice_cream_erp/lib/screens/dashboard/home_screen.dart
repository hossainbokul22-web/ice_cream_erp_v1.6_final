import 'dart:async';
import 'package:flutter/material.dart' hide Text;
import '../../utils/i18n.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/database_provider.dart';
import '../../services/audit_service.dart';
import '../../providers/settings_provider.dart';
import '../../services/stock_service.dart';
import '../../utils/palette.dart';
import '../../utils/ui.dart';

/// Home: today's numbers (one highlight at a time, every 3 s) + shortcut tiles.
/// Light = soft neumorphic, Dark = warm bronze glass.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _Shortcut {
  const _Shortcut(this.icon, this.title, this.sub, this.path, this.top, this.bottom);
  final IconData icon;
  final String title;
  final String sub;
  final String path;
  final Color top;
  final Color bottom;
}

const List<_Shortcut> _shortcuts = [
  _Shortcut(Icons.bolt_rounded, 'আজকের ব্যাচ', 'রেসিপি + ব্যাচ', '/quick-batch', Color(0xFFFFC27A), Color(0xFFE8792E)),
  _Shortcut(Icons.event_note_rounded, 'প্ল্যানিং ব্যাচ', 'কাল / পরের শিফট', '/quick-plan', Color(0xFF9D8CFF), Color(0xFF5B4DF0)),
  _Shortcut(Icons.inventory_2_rounded, 'ফিনিশ কার্টুন', 'প্যাকেজিং কাটা', '/packing', Color(0xFFC3B0FF), Color(0xFF7C5CE0)),
  _Shortcut(Icons.category_rounded, 'Items', 'আইটেম মাস্টার', '/items', Color(0xFF9D8CFF), Color(0xFF5B4DF0)),
  _Shortcut(Icons.menu_book_rounded, 'Recipes', 'রেসিপি / BOM', '/recipes', Color(0xFFFFA2B8), Color(0xFFE8567A)),
  _Shortcut(Icons.propane_tank_rounded, 'Tanks', 'ট্যাংক', '/tanks', Color(0xFF8FE3C4), Color(0xFF2FB58A)),
  _Shortcut(Icons.ac_unit_rounded, 'Freezers', 'ফ্রিজার তালিকা', '/freezers', Color(0xFF9FD8FF), Color(0xFF2E86E8)),
  _Shortcut(Icons.fact_check_rounded, 'স্ট্যান্ডার্ড সিট', 'তাপ • প্রেশার • সময়', '/standards', Color(0xFFFFD08A), Color(0xFFE0861F)),
  _Shortcut(Icons.groups_rounded, 'Parties', 'সাপ্লায়ার / কাস্টমার', '/parties', Color(0xFFFFD27A), Color(0xFFE59A2E)),
  _Shortcut(Icons.shopping_cart_rounded, 'Purchase', 'মাল গ্রহণ', '/purchase', Color(0xFF8CCBFF), Color(0xFF3A86E0)),
  _Shortcut(Icons.point_of_sale_rounded, 'Sale', 'বিক্রয়', '/sale', Color(0xFF9BE8A8), Color(0xFF3DB45A)),
  _Shortcut(Icons.delete_sweep_rounded, 'Reject / Wastage', 'ক্ষতি ও ফেরত', '/movement', Color(0xFFFFAE9C), Color(0xFFE5584D)),
  _Shortcut(Icons.thermostat_rounded, 'Temp Log', 'তাপমাত্রা লগ', '/templog', Color(0xFF9FD8FF), Color(0xFF2E86E8)),
  _Shortcut(Icons.auto_awesome_rounded, 'Auto Schedule', 'ট্যাংক • ফ্রিজার প্ল্যান', '/schedule', Color(0xFFC3B0FF), Color(0xFF7C5CE0)),
];

class _Highlight {
  const _Highlight(this.icon, this.title, this.sub, this.value, this.unit, this.color, this.path);
  final IconData icon;
  final String title;
  final String sub;
  final String value;
  final String unit;
  final Color color;
  final String path;
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  late Future<DailyInventoryBrief> _future;
  Timer? _timer;
  int _idx = 0;

  @override
  void initState() {
    super.initState();
    _future = ref.read(stockServiceProvider).dailyInventoryBrief();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted) setState(() => _idx = (_idx + 1) % 3);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _reload() {
    setState(() => _future = ref.read(stockServiceProvider).dailyInventoryBrief());
  }

  List<_Highlight> _highlights(DailyInventoryBrief b, Pal pal) => [
        _Highlight(Icons.precision_manufacturing_rounded, 'উৎপাদন', 'আজকের ফিনিশ প্রোডাক্ট',
            fmtQty(b.finishedProducedToday), 'আজ', pal.accent, '/production'),
        _Highlight(Icons.warning_amber_rounded, 'লো স্টক', 'কম স্টকের আইটেম', '${b.lowStockCount}', 'আইটেম',
            pal.warn, '/stock'),
        _Highlight(Icons.hourglass_bottom_rounded, 'নিয়ার এক্সপায়ার', 'মেয়াদ শেষ হতে চলেছে',
            '${b.nearExpiryCount}', 'ব্যাচ', pal.bad, '/stock'),
      ];

  Widget _ticker(DailyInventoryBrief b, Pal pal) {
    final hs = _highlights(b, pal);
    final h = hs[_idx];
    return Column(
      children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 550),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeIn,
          transitionBuilder: (child, anim) => FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(begin: const Offset(0, 0.35), end: Offset.zero).animate(anim),
              child: child,
            ),
          ),
          child: GestureDetector(
            key: ValueKey(_idx),
            onTap: () => context.go(h.path),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 14, 16, 14),
              decoration: pal.box(r: 22, color: pal.cardHi),
              child: Row(
                children: [
                  Container(width: 5, height: 52, decoration: BoxDecoration(color: h.color, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: h.color.withAlpha(36), borderRadius: BorderRadius.circular(14)),
                    child: Icon(h.icon, color: h.color, size: 26),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(h.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: pal.ink)),
                        const SizedBox(height: 2),
                        Text(h.sub, style: TextStyle(fontSize: 12, color: pal.muted)),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(h.value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: h.color)),
                      Text(h.unit, style: TextStyle(fontSize: 11, color: pal.muted)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < hs.length; i++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: i == _idx ? 22 : 7,
                height: 7,
                decoration: BoxDecoration(
                  color: i == _idx ? hs[i].color : pal.muted.withAlpha(90),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _pill(Pal pal, String label, String value) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: pal.box(r: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(fontSize: 11, color: pal.muted)),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: pal.ink)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header(Pal pal) {
    final mode = ref.watch(themeModeProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(color: pal.accent, borderRadius: BorderRadius.circular(14)),
              child: Icon(Icons.icecream_rounded, color: pal.onAccent, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(ref.watch(companyProvider).shownName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: pal.ink)),
                  Text('আজকের সারসংক্ষেপ', style: TextStyle(fontSize: 12, color: pal.muted)),
                ],
              ),
            ),
            IconButton(
              tooltip: tr(pal.dark ? 'আলো মোড' : 'ডার্ক মোড'),
              onPressed: () => ref.read(themeModeProvider.notifier).state =
                  pal.dark ? ThemeMode.light : ThemeMode.dark,
              icon: Icon(pal.dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded, color: pal.ink),
            ),
            IconButton(onPressed: _reload, icon: Icon(Icons.refresh_rounded, color: pal.ink)),
            if (can(ref.watch(roleProvider), 'settings'))
              IconButton(
                tooltip: 'Settings',
                onPressed: () => context.push('/settings'),
                icon: Icon(Icons.settings_rounded, color: pal.ink),
              ),
          ],
        ),
        const SizedBox(height: 14),
        FutureBuilder<DailyInventoryBrief>(
          future: _future,
          builder: (context, snap) {
            if (snap.hasError) return Text(friendlyError(snap.error!), style: TextStyle(color: pal.bad));
            if (!snap.hasData) {
              return const Padding(padding: EdgeInsets.symmetric(vertical: 24), child: Center(child: CircularProgressIndicator()));
            }
            final b = snap.data!;
            return Column(
              children: [
                _ticker(b, pal),
                const SizedBox(height: 12),
                Row(children: [
                  _pill(pal, 'RM স্টক মূল্য', fmtMoney(b.rawValue)),
                  _pill(pal, 'FG স্টক মূল্য', fmtMoney(b.finishedValue)),
                ]),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _tile(BuildContext context, Pal pal, _Shortcut s) {
    return GestureDetector(
      onTap: () => context.push(s.path),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: pal.box(r: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [s.top, s.bottom],
                ),
                boxShadow: [BoxShadow(color: s.bottom.withAlpha(pal.dark ? 60 : 80), blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: Icon(s.icon, color: Colors.white, size: 24),
            ),
            const SizedBox(height: 8),
            Text(s.title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: pal.ink)),
            Text(s.sub,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10.5, color: pal.muted)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pal = Pal.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _header(pal),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 10),
              child: Text('দ্রুত কাজ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: pal.ink)),
            ),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              childAspectRatio: 0.92,
              children: [
                for (final s in _shortcuts)
                  if (can(ref.watch(roleProvider), featureForPath(s.path) ?? ''))
                    _tile(context, pal, s)
              ],
            ),
          ],
        ),
      ),
    );
  }
}
